
/* JavaScript content from design/assets/js/main.js in folder common */
/**** dashboard-page ****/
$(function ($) {
    if ($("#dashboard").length != 0) {

        $(".knob").knob({
            thickness: 0.42,
            fgColor: "#b4d103",
            class: 'mon-groupe-canvas',
            change: function (value) {
                //console.log("change : " + value);
            },
            release: function (value) {
                //console.log(this.$.attr('value'));
                console.log("release : " + value);
            },
            cancel: function () {
                console.log("cancel : ", this);
            },
            /*format : function (value) {
                return value + '%';
            },*/
            draw: function () {

                $("#percentage-value-1").text(this.i.data("value"));
                // "tron" case
                if (this.$.data('skin') == 'tron') {

                    this.cursorExt = 0.3;

                    var a = this.arc(this.cv) // Arc
                        ,
                        pa // Previous arc
                        , r = 1;

                    this.g.lineWidth = 150;
                    //change stroke width here

                    if (this.o.displayPrevious) {
                        pa = this.arc(this.v);
                        this.g.beginPath();
                        this.g.strokeStyle = this.pColor;
                        this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                        this.g.stroke();
                    }

                    this.g.beginPath();
                    this.g.strokeStyle = r ? this.o.fgColor : this.fgColor;
                    this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                    this.g.stroke();

                    this.g.lineWidth = 2;
                    this.g.beginPath();
                    this.g.strokeStyle = this.o.fgColor;
                    this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                    this.g.stroke();

                    return false;
                }
            }
        });

        var percentage = parseInt($(".knob-2").data("value")),
            retinaMultiplier = window.devicePixelRatio;
        $(".knob-2").knob({
            thickness: 1,
            //change width here
            class: 'ma-progression-canvas',
            draw: function () {
                var c = this.g, // context
                    a = this.arc(this.cv), // Arc
                    pa, // Previous arc
                    r = 1;
                $("#percentage-value-2").text(this.i.data("value"));
                c.lineWidth = this.lineWidth;
                c.beginPath();
                c.strokeStyle = this.o.bgColor;
                c.arc(this.xy, this.xy, this.radius, this.endAngle, this.startAngle, true);
                c.stroke();

                draw(c, r, this.radius, this.xy, percentage);

                // Drawing point
                c.beginPath();
                c.arc(this.w2 * retinaMultiplier, this.w2 * retinaMultiplier, this.h / 2 * 0.73 * retinaMultiplier, 0, 2 * Math.PI, false);
                c.fillStyle = this.o.bgColor;
                c.fill();
                c.closePath();

                return false;
            }
        });

        function drawGradientArc(ctx, r, radius, xAxis, startAngle, endAngle, lineWidth, quardAngle) {

            var sweep = endAngle - startAngle;
            var xStart = xAxis + Math.cos(startAngle) * radius;
            var xEnd = xAxis + Math.cos(startAngle + sweep) * radius;
            var yStart = xAxis + Math.sin(startAngle) * radius;
            var yEnd = xAxis + Math.sin(startAngle + sweep) * radius;
            var xQuardEnd = xAxis + Math.cos(quardAngle) * radius;
            var yQuardEnd = xAxis + Math.sin(quardAngle) * radius;

            var gradient = ctx.createLinearGradient(xStart, yStart, xQuardEnd, yQuardEnd);
            gradient.addColorStop(0.0, "#b02601");
            gradient.addColorStop(1.0, "#ee5f1f");

            // Drawing circle part
            ctx.beginPath();
            ctx.arc(xAxis, xAxis, radius, startAngle, startAngle + sweep);
            ctx.strokeStyle = gradient;
            ctx.stroke();
            ctx.closePath();
        }

        function draw(ctx, r, radius, xAxis, percentage, lineWidth) {
            //console.log(radius);
            var quardValue = (2 * Math.PI) / 8;
            var value = (percentage / 100) * (2 * Math.PI);
            var d = value;
            var noofChapter = Math.floor(value / quardValue);
            noofChapter = noofChapter ? noofChapter : 1;
            var lastPoint = 0;

            for (var i = 0; i <= noofChapter; i++) {
                if (value > quardValue) {
                    drawGradientArc(ctx, r, radius, xAxis, lastPoint, lastPoint + quardValue, lineWidth, lastPoint + quardValue);
                    lastPoint = lastPoint + quardValue;
                    value = value - quardValue;
                } else {
                    drawGradientArc(ctx, r, radius, xAxis, lastPoint, d, lineWidth, lastPoint + quardValue);

                }
            }
            $(".pie-dot-0").css({
                "opacity": 1
            });
            var noOfDots = Math.floor(percentage / 12.5);
            for (var j = 0; j < noOfDots; j++) {
                $(".pie-dot-" + (j + 1)).css({
                    "opacity": 1
                });
                console.log($(".pie-dot-" + j + 1));
            }
        };
        // Example of infinite knob, iPod click wheel
        var v, up = 0,
            down = 0,
            i = 0,
            $idir = $("div.idir"),
            $ival = $("div.ival"),
            incr = function () {
                i++;
                $idir.show().html("+").fadeOut();
                $ival.html(i);
            },
            decr = function () {
                i--;
                $idir.show().html("-").fadeOut();
                $ival.html(i);
            };
        $("input.infinite").knob({
            min: 0,
            max: 20,
            stopper: false,
            change: function () {
                if (v > this.cv) {
                    if (up) {
                        decr();
                        up = 0;
                    } else {
                        up = 1;
                        down = 0;
                    }
                } else {
                    if (v < this.cv) {
                        if (down) {
                            incr();
                            down = 0;
                        } else {
                            down = 1;
                            up = 0;
                        }
                    }
                }
                v = this.cv;
            }
        });
    }
});
/**** dashboard-page-end ****/

/**** votre-profile-page ****/
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('.img-file-upload')
                    .attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    /**** votre-profile-page-end ****/
    /**** outils and mon-planning page js ****/
$('a.inactive-state').click(function () {
    return false;
});
/**** outils and mon-planning page end ***/
/**** agenda-etapes-page ****/
$('a.game-locked,a.locked').click(function () {
    return false;
});

/**** agenda-etapes-page-end ****/

/**** etapes-page ****/
$("#progress-value-6").html($("#progress-bar-6").attr('aria-valuenow') + '%');
$('a.game-locked').click(function () {
    return false;
});
/**** etapes-page-end ****/

/**** mon-equipe-page ****/
$(function ($) {
    if ((screen.width == 1024) && (screen.height == 768)) {
        $(".equipe-knob").attr("data-angleOffset", 258);
    }
    if ($("#mon-equipe").length != 0) {
        $("#user-1").knob({
            'min': 0,
            'max': 100,
            width: 50,
            height: 50,
            fgColor: "#c1de16",
            bgColor: "#ffffff",
            thickness: 0.18,
            change: function (value) {
                //console.log("change : " + value);
            },
            release: function (value) {
                //console.log(this.$.attr('value'));
                console.log("release : " + value);
            },
            cancel: function () {
                console.log("cancel : ", this);
            },
            format: function (value) {
                return $(".user-1").text().trim();
            }
        });
        $("#user-2").knob({
            'min': 0,
            'max': 100,
            width: 50,
            height: 50,
            fgColor: "#c1de16",
            bgColor: "#ffffff",
            thickness: 0.18,
            change: function (value) {
                //console.log("change : " + value);
            },
            release: function (value) {
                //console.log(this.$.attr('value'));
                console.log("release : " + value);
            },
            cancel: function () {
                console.log("cancel : ", this);
            },
            format: function (value) {
                return $(".user-2").text().trim();
            }
        });
        $("#user-3").knob({
            'min': 0,
            'max': 100,
            width: 50,
            height: 50,
            fgColor: "#c1de16",
            bgColor: "#ffffff",
            thickness: 0.18,
            change: function (value) {
                //console.log("change : " + value);
            },
            release: function (value) {
                //console.log(this.$.attr('value'));
                console.log("release : " + value);
            },
            cancel: function () {
                console.log("cancel : ", this);
            },
            format: function (value) {
                return $(".user-3").text().trim();
            }
        });
        $("#user-4").knob({
            'min': 0,
            'max': 100,
            width: 50,
            height: 50,
            fgColor: "#10a3e0",
            bgColor: "#ffffff",
            thickness: 0.18,
            change: function (value) {
                //console.log("change : " + value);
            },
            release: function (value) {
                //console.log(this.$.attr('value'));
                console.log("release : " + value);
            },
            cancel: function () {
                console.log("cancel : ", this);
            },
            format: function (value) {
                return $(".user-4").text().trim();
            }
        });
    }
});
/**** mon-equipe-page-end ****/
/**** mon-barometre-start ****/
$(function () {
    if ($("#mon-barometre").length != 0) {
        $("#slide-1").slider({
            disabled: true,
            range: "min",
            value: 100,
            min: 1,
            max: 100,
        });
        $("#slide-2").slider({
            disabled: true,
            range: "min",
            value: 75,
            min: 1,
            max: 100,
        });
        $("#slide-3").slider({
            disabled: true,
            range: "min",
            value: 45,
            min: 1,
            max: 100,
        });
        $("#slide-4").slider({
            disabled: true,
            range: "min",
            value: 55,
            min: 1,
            max: 100,
        });
        $("#slide-5").slider({
            disabled: true,
            range: "min",
            value: 95,
            min: 1,
            max: 100,
        });
    }
});
/**** mon-barometre-end ****/
/**** biblio page-start ****/
$('#biblio-modal,#biblio-modal-2').modal('show');
/**** biblio page-end ****/
/**** leader-exemple-page-start ****/
$('#admire-exemple-leader-modal').modal('show');
/**** leader-exemple-page-end ****/
/**** leadership-et-stereotypes-3-start ****/
$(function () {
    if ($("#leadership-et-stereotypes-3").length != 0) {
        $("#leadership-et-stereotypes-3-slider").slider({
            disabled: true,
            range: "min",
            value: 75,
            min: 1,
            max: 100,
        });
    }
});
/**** leadership-et-stereotypes-3-end ****/
/**** moi-et-le-start ****/
$(function () {
    if ($(".moietle").length != 0) {
        var moi_et_le_header_text = document.getElementById("moi-et-le-header-text");
        $clamp(moi_et_le_header_text, {
            clamp: 3.5,
            useNativeClamp: false
        });
    }
});
/**** moi-et-le-end ****/
/**** stereotypes-start ****/
$(function () {
    if ($("#stereotype").length != 0) {
        var stereotypes_header_text = document.getElementById("stereotypes-header-text");

        $clamp(stereotypes_header_text, {
            clamp: 3.5,
            useNativeClamp: false
        });
    }
});
/****  stereotypes-end ****/
/**** mon-profil-barometre-start ****/
$(function () {
    if ($("#mon-profil-mon-barometre").length != 0) {
        $("#mon-profil-slide-1").slider({
            disabled: true,
            range: "min",
            value: 100,
            min: 1,
            max: 100,
        });
        $("#mon-profil-slide-2").slider({
            disabled: true,
            range: "min",
            value: 75,
            min: 1,
            max: 100,
        });
        $("#mon-profil-slide-3").slider({
            disabled: true,
            range: "min",
            value: 45,
            min: 1,
            max: 100,
        });
        $("#mon-profil-slide-4").slider({
            disabled: true,
            range: "min",
            value: 55,
            min: 1,
            max: 100,
        });
        $("#mon-profil-slide-5").slider({
            disabled: true,
            range: "min",
            value: 95,
            min: 1,
            max: 100,
        });
    }
});
/**** mon-profil-barometre-end ****/
/**** je-dis-je-start ****/
$(document).ready(function () {
    //set default value here
    $total_value = parseInt($('#count-on-number').html());
    $total_value2 = parseInt($('#count-je-number').html());


    //Assign the div here
    $display_element = $('#count-on-number');
    $display_element2 = $('#count-je-number');

    //Calculate 1 Gray Number

    $('#addition').on('click', function () {
        $total_value = compute('addition', $total_value);
        $display_element.html($total_value);
    });

    $('#subtraction').on('click', function () {
        $total_value = compute('subtraction', $total_value);
        $display_element.html($total_value);
    });

    // Calculator 2 Blue Number

    $('#addition2').on('click', function () {
        $total_value2 = compute('addition', $total_value2);
        $display_element2.html($total_value2);
    });

    $('#subtraction2').on('click', function () {
        $total_value2 = compute('subtraction', $total_value2);
        $display_element2.html($total_value2);
    });


    function compute($operation, $curent_value) {

        var computed_value = 0;

        if ($operation == "addition") {
            if ($curent_value <= 98) {
                computed_value = $curent_value + 1;
            } else {
                computed_value = $curent_value;
            }
        } else if ($operation == "subtraction") {
            if ($curent_value != 0) {
                computed_value = $curent_value - 1;
            }
        }
        return computed_value;
    }


});
/**** je-dis-je-end ****/
/**** les-5-attitudes-leader-anim-start ****/
$(function () {
    if ($("#les-5-attitudes-leader-anim").length != 0) {
        $("#les-5-attitudes-leader-anim-slider").slider({
            disabled: true,
            range: "min",
            value: 50,
            min: -6,
            max: 109,
        });
    }
});
/**** les-5-attitudes-leader-anim-end ****/
/**** mon-cahier-tendance-pinterest ****/
$(".mon-cahier-tendance-pinterest-input").keydown(function (event) {
    console.log(this.selectionStart);
    console.log(event);
    if (event.keyCode == 8) {
        this.selectionStart--;
    }
    if (this.selectionStart < 26) {
        this.selectionStart = 26;
        console.log(this.selectionStart);
        event.preventDefault();
    }
});
$(".mon-cahier-tendance-pinterest-input").keyup(function (event) {
    console.log(this.selectionStart);
    if (this.selectionStart < 26) {
        this.selectionStart = 26;
        console.log(this.selectionStart);
        event.preventDefault();
    }
});
/**** mon-cahier-tendance-pinterest-end ****/
/**** keyboard-fix-for-input-fields-start ****/
if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
    $(function () {
        $("input, textarea").focus(function (e) {
            $("body, html, #main-content").css({
                "height": "170%",
                "overflow-y": "auto"
            });
            $('html, body').animate({
                scrollTop: $("input").offset().top
            }, 200);
        });
        $("input, textarea").blur(function (e) {
            $("body, html, #main-content").css({
                "height": "",
                "overflow-y": ""
            });
        });
    });
}
/**** keyboard-fix-for-input-fields-end ****/
/**** les-voix-des-autres ****/
$active_element = "";

$(document).ready(function () {
    $("#les-voix-edit-btn-1").on('click', function () {
        $active_element = '#elles-vous-limitent-image-1';
        $("#fileImage").trigger("click");
    });

    $("#les-voix-edit-btn-2").on('click', function () {
        $active_element = '#elles-vous-limitent-image-2';
        $("#fileImage").trigger("click");
    });

    $("#les-voix-edit-btn-3").on('click', function () {
        $active_element = '#elles-vous-encouragent-image-1';
        $("#fileImage").trigger("click");
    });

    $("#les-voix-edit-btn-4").on('click', function () {
        $active_element = '#elles-vous-encouragent-image-2';
        $("#fileImage").trigger("click");
    });

});

// override the previous functionality of the function
function changeImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {

                $($active_element)
                    .attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    /**** les-voix-des-autres-end ****/