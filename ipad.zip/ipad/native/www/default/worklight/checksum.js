var WL_CHECKSUM = {"date":1452003173122,"machine":"MacBook-Pro-de-Remy.local","checksum":1580903958};
/* Date: Tue Jan 05 15:12:53 CET 2016 */