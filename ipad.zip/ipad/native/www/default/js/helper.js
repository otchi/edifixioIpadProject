
/* JavaScript content from js/helper.js in folder common */
function loadJsFile(jsFileSrc) {
	console.log('loadJsFile entering with file url = ' + jsFileSrc);
	var fileref = document.createElement('script');
	fileref.setAttribute("type", "text/javascript");
	fileref.setAttribute("src", jsFileSrc);
	document.getElementsByTagName("head")[0].appendChild(fileref);
}

function dateToUTC(date) {
	console.log('dateToUTC entering');
	var date_utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date
			.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date
			.getUTCSeconds());

	console.log('utc = ' + date_utc);

	return date_utc;
}

function utcToDate(utc) {
	var date = new Date(utc);
	return date;
}

function displayDate(date, frenchFormat) {
	var separator = '/';

	var monthValue = date.getMonth() + 1;

	if (frenchFormat) {
		var stringDate = date.getDate() + separator + monthValue.toString()
				+ separator + date.getFullYear();
		return stringDate;
	} else {
		var stringDate = monthValue.toString() + separator + date.getDate()
				+ separator + date.getFullYear();
		return stringDate;
	}
}

function htmlEncode(value) {
	if (value) {
		var encodedString = jQuery('<div />').text(value).html();
		return encodedString.replace(/"/g, "&quot;");
	} else {
		return '';
	}
}

function htmlDecode(value) {
	if (value) {
		var decodedString = $('<div />').html(value).text();
		console.log('htmlDecode : will return '
				+ decodedString.replace("&quot;", "\""));
		return decodedString.replace("&quot;/g", "\"");
	} else {
		return '';
	}
}

function criteria(number, value, updateDate) {
	this.number = number;
	this.value = value;
	this.updateDate = updateDate;
};

function isBlank(str) {
	return (!str || $.trim(str) === "");
}

function toggleEnabling(selector, disableValue) {
	if (typeof selector == "string") {
		$(selector).attr('disabled', disableValue);
	} else if (typeof selector == "object") {
		selector.attr('disabled', disableValue);
	} else {
		console.log('toggleEnabling - Don\'t know what to do with this type');
	}

}

function toggleVisibility(selector, showValue) {
	if (showValue) {
		$(selector).show();
	} else {
		$(selector).hide();
	}
}

function encodeToBase64(file, callback) {
	console.log("encodeToBase64 entering");

	var fileReader = new FileReader();

	fileReader.onload = function(e) {
		callback(e.target.result);
	};

	fileReader.readAsDataURL(file);
}

function hasImageExtension(fileName) {
	console.log('Entering hasImageExtension with :' + fileName);

	if (!isBlank(fileName)) {

		var regExp = /^.+\.(jpg|jpeg|gif|png|bmp|tif)$/i;

		if (regExp.test(fileName)) {
			return true;
		}
	}

	return false;

	// TO BE ENHANCED
	// return false;
}

function hasVideoExtension(fileName) {
	console.log('Entering hasVideoExtension with :' + fileName);

	if (!isBlank(fileName)) {

		var regExp = /^.+\.(mp4|dvd|avi|wmv)$/i;

		if (regExp.test(fileName)) {
			return true;
		}
	}

	return true;

	// TO BE ENHANCED
	// return false;
}


function getRandomInt(min, max) {
	console.log('getRandomInt entering with (' + min + ',' + max + ')');
	return Math.floor(Math.random() * (max - min + 1) + min);
}

function translatePage(page) {
	$("#"+page+" [data-type ='bundle']").each(function() {
		var key = $(this).attr("data-key");
		if (key && key != '') {
			var value = $.i18n.prop(key);
			if (value) {
				$(this).html(value);
			}
		}
	});
}

Array.prototype.contains = function(elem){
   for (var i in this)
   {
       if (this[i] == elem) return true;
   }
   return false;
};

function returnTypeConnection(){
	
	var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN]  = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI]     = 'WiFi connection';
    states[Connection.CELL_2G]  = 'Cell 2G connection';
    states[Connection.CELL_3G]  = 'Cell 3G connection';
    states[Connection.CELL_4G]  = 'Cell 4G connection';
    states[Connection.CELL]     = 'Cell generic connection';
    states[Connection.NONE]     = 'No network connection';
    return states[networkState];

}