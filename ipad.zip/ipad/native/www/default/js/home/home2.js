
/* JavaScript content from js/home/home2.js in folder common */
$("#linkToHome1").attr('href', '#' + home1Page.id);
$("#linkToBaremeterInit").on("click", function(e) {
	addLockedPage(home1Page.id, function() {
		addLockedPage(home2Page.id, function() {
			$.mobile.changePage('#' + barometerInitPage.id);
		});
	});
});