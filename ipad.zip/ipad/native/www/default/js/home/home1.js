
/* JavaScript content from js/home/home1.js in folder common */
$("#linkToHome2").attr('href', '#' + home2Page.id);
