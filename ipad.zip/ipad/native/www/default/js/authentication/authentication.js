
/* JavaScript content from js/authentication/authentication.js in folder common */
// on page show

$(document).on("pagebeforeshow", "#" + authentication.id, function(event) {
	$('#'+authentication.id +' [data-id=login]').val("");
	$('#'+authentication.id +' [data-id=password]').val("");
	$('#'+authentication.id +' [data-id=textLogin]').css("visibility","hidden");
	$('#'+authentication.id +' [data-id=textPassword]').css("visibility","hidden");
	$('#'+authentication.id +' [data-id=wrongLogin]').css("visibility","hidden");
	$('#'+authentication.id +' [data-id=wrongPassword]').css("visibility","hidden");
	toggleEnabling('#'+authentication.id +' [data-id=submit]',true);
	
});

//Add click event on button
$('#'+authentication.id +' [data-id=submit]').on("click", function(e) {
//	if (returnTypeConnection()=="No network connection") alert('veuillez vous connectez a internet');
//	else getLoginClient();
	getLoginClient();
	//$.mobile.changePage('#' + homeCoachPage.id);	
});

$('#'+authentication.id +' input').on("keyup", function(e) {
	$('#'+authentication.id +' [data-id=wrongLogin]').css("visibility","hidden");
	$('#'+authentication.id +' [data-id=wrongPassword]').css("visibility","hidden");
	if(($('#'+authentication.id +' [data-id=login]').val().length>0) && ($('#'+authentication.id +' [data-id=password]').val().length>0))	
		toggleEnabling('#'+authentication.id +' [data-id=submit]',false);
	else toggleEnabling('#'+authentication.id +' [data-id=submit]',true);
});

$('#'+authentication.id +' [data-id=login]').on("keyup", function(e) {
	if($('#'+authentication.id +' [data-id=login]').val().length == 0) $('#'+authentication.id +' [data-id=textLogin]').css("visibility","visible"); 
	else $('#'+authentication.id +' [data-id=textLogin]').css("visibility","hidden");
});

$('#'+authentication.id +' [data-id=password]').on("keyup", function(e) {	
	if($('#'+authentication.id +' [data-id=password]').val().length == 0) $('#'+authentication.id +' [data-id=textPassword]').css("visibility","visible"); 
	else $('#'+authentication.id +' [data-id=textPassword]').css("visibility","hidden");
});
	
function getLoginClient(){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getLoginBdd',
			parameters : []
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccess,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccess(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		verifLogin(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}

function loadFeedsFailure(jsonBdd){
	WL.Logger.error("Feed retrieve failure");
	$('#'+authentication.id +' [data-id=submit]').click();
//	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
//			[{
//				text : 'Reload',
//				handler : WL.Client.reloadApp 
//			},
//			{
//				text: 'Close',
//				handler : function() {}
//			}]
//		);
}

function verifLogin(listUser){
	
	var loginCurrent = $('#'+authentication.id +' [data-id=login]').val();
	var passCurrent = $('#'+authentication.id +' [data-id=password]').val();
	var findUser = false;
	var presentBdd = "no";
	var introProfile = "no";
	for(var i=0;i<listUser.length;i++){
		if((listUser[i].login == loginCurrent )&&(listUser[i].password == passCurrent)) {
			findUser = true;
			presentBdd = listUser[i].present;
			introProfile = listUser[i].intro;
		}
	}
	
	// si le user est trouvé 
	if(findUser){
		setUserName(loginCurrent);
			if(presentBdd == "yes"){
				//si present == yes
				// recuperer toutes les données de l'utilisateur depuis la base du serveur
				getInformationClient(loginCurrent);
				
			}else if(presentBdd == "no"){
				// si present == no 
				// la base de donnée de l'utilisateur est vide
				//l'utilisateur s'est deja connectée une fois
				setGetConnection("yes", function(){
					if(introProfile == 'yes')  $.mobile.changePage('#' + dashBoardPage.id);
					else if(introProfile == 'no')  $.mobile.changePage('#' + introHelloPage.id);	
				});
				//$.mobile.changePage('#' + introProfilePage.id);
				//$.mobile.changePage('#' + dashBoardPage.id);
			}
	}else{
		//si le user n'est pas trouvé coté utilisateur on cherche coté coach
		getLoginCoach();
	}	
}

// appel a la fonction du serveur pour importer les données dans la base locale
function getInformationClient(login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getInfoBdd',
			parameters : [login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessInfo1,
		onFailure : loadFeedsFailureInfo1
	});
}

function loadFeedsSuccessInfo1(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) showInfoBdd(result.invocationResult.resultSet); 
	else loadFeedsFailureInfo1();
}

function loadFeedsFailureInfo1(jsonBdd){
	WL.Logger.error("Feed retrieve failure");
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}

function showInfoBdd(resultInfo){
	// insertion des données dans la base de données locale
	for(var i =0;i<resultInfo.length;i++){
			var contenuTable = JSON.parse(resultInfo[i].table_bdd);
			var nameTable = resultInfo[i].nameTable;
			
			for (var j=0; j < contenuTable.length; j++) {
				var values = new Array();
				for (rowContent in contenuTable[j]) {
					values.push(contenuTable[j][rowContent]);	
				}
				
				if(nameTable =="T_ACTIVITIES_STATUS") setActivityStatus(values[0],values[1]);
				if(nameTable =="T_ACTIVITIES_STATUS") setActivityStatus(values[0],values[1]);
				if(nameTable =="T_ANNOTATIONS") setAnnotation(values[0], values[1]);
				if(nameTable =="T_BAROMETER") addBarometerValue(values[0], values[1]);
				if(nameTable =="T_BAROMETER_INIT") addBarometerInitValue(values[0], values[1]);
				if(nameTable =="T_COMPASS_ACTIONS") addActionProLife(values[0], values[1]);		
				if(nameTable =="T_COMPASS_ARRAY_VALUES") addValueRadioArray(values[0], values[1], values[2], values[3], values[4]);									
				if(nameTable =="T_COMPASS_IMPORTANT_CRITERIA") addImportantCriteria(values[0], values[1], values[2]);									
				if(nameTable =="T_COMPASS_MARK") addMark(values[0]);									
				if(nameTable =="T_COMPASS_MYMISSION_ACTIONS") addActionMyMissionProLife(values[0], values[1]);	
				if(nameTable =="T_COMPASS_MYMISSION_MARK") addMarkProLife(values[0]);										
				if(nameTable =="T_COMPASS_VALUES") addValueIRecognize(values[0]);									
				if(nameTable =="T_COMPASS_VISION") addValueTableWithKey(values[0], values[1], 'T_COMPASS_VISION');		
				if(nameTable =="T_COMPASS_VISION_IMAGES") addVisionImage(values[0], values[1]);		
				if(nameTable =="T_COMPASS_VISION_MISSION_VERBS") addVerbMyMission(values[0]);										
				if(nameTable =="T_COMPASS_VISION_TITLE_IMAGES") compass_myVision_setTitleImage(values[0], values[1]);	
				if(nameTable =="T_LEADERSHIP_ATTITUDE_KEY") leadership_attitude_setKey(values[0], values[1]);	
				if(nameTable =="T_LEADERSHIP_CHOOSEQUALITY_KEY") leadership_chooseQualities_setKey(values[0], values[1],values[2]);
				if(nameTable =="T_LEADERSHIP_DEVELOPMENT_KEY") leadership_development_setKey(values[0], values[1],values[2]);
				if(nameTable =="T_LEADERSHIP_FIVELEADERS_KEY") leadership_fiveLeaders_setKey(values[0], values[1],values[2]);
				if(nameTable =="T_LEADERSHIP_FIVELEADERS_STATE_LEADER") leadership_fiveLeaders_setState_leader(values[0], values[1]);
				if(nameTable =="T_LEADERSHIP_QUESTIONS_KEY") leadership_questions_setKey(values[0], values[1]);	
				if(nameTable =="T_LEADERSHIP_STEREOTYPE_KEY") leadership_stereotype_setKey(values[0], values[1]);	
			    if(nameTable =="T_PROJECTMYSELF_CARDSROUTES_KEY") addInprojectMyselfCardRoutesKey(values[0],values[1]);	
				if(nameTable =="T_PROJECTMYSELF_INFIVEYEARS_KEY") addInprojectMyselfKey(values[0],values[1]);
				if(nameTable =="T_PROJECTMYSELF_INFIVEYEARS_VERBS") addInFiveYearsImage(values[0],values[1],values[2]);
				if(nameTable =="T_SAYI_ISAYI_DATA") addValueTableWithKey(values[0], values[1], "T_SAYI_ISAYI_DATA");
				if(nameTable =="T_SAYI_MORNINGPAGES_DATA") addValueTableWithKey(values[0], values[1], "T_SAYI_MORNINGPAGES_DATA");
				if(nameTable =="T_SAYI_MYBELIEFS_ANSWERS") sayiMyBeliefs_addAnswer(values[0], values[1]);
				if(nameTable =="T_SAYI_MYLITTLEME_DATA") sayI_MyLittleMe_setProfileImage(values[1]);										
				if(nameTable =="T_SAYI_MYLITTLEME_IMAGES") sayI_MyLittleMe_addImage(values[0], values[1]);
				if(nameTable =="T_SAYI_MYLITTLEME_SENTENCES") sayI_MyLittleMe_addSentence(values[0], values[1]);
				if(nameTable =="T_SAYI_OTHERVOICES_DESCRIPTIONS") sayI_otherVoices_SetDescription(values[0], values[1]);
				if(nameTable =="T_SAYI_OTHERVOICES_IMAGES") sayI_otherVoices_addImage(values[0], values[1]);
				if(nameTable =="T_SAYI_PASSION_STEPFOUR_KEY") sayI_passion_setPassion_step4_key(values[0], values[1]);
				if(nameTable =="T_SAYI_PASSION_STEPONE") sayI_passion_setPassion_step1(values[0], values[1]);
				if(nameTable =="T_SAYI_PASSION_STEPONE_KEY") sayI_passion_setPassion_step1_key(values[0], values[1]);
				if(nameTable =="T_SAYI_PASSION_STEPTWO_KEY") sayI_passion_setPassion_step2_key(values[0], values[1]);
				if(nameTable =="T_SAYI_PASSION_STEPTWO_PICTURES") sayI_passion_setPassion_step2_pictures(values[0], values[1]);
				if(nameTable =="T_SEEN_PAGES") insertSeenPageId(values[0]);
				if(nameTable =="T_TALENTS_CHILDHOOD") addTalentChildhood(values[0]);
				if(nameTable =="T_TALENTS_CHILDHOOD_ANSWERS") addTalentChildhoodAnswer(values[0],values[1]);
				if(nameTable =="T_TALENTS_CHILDHOOD_IMAGES") addTalentChildhoodImage(values[0],values[1]);
				if(nameTable =="T_TALENTS_I_ENHANCE") addTalentNoteIEnhance(values[0],values[1]);
				if(nameTable =="T_TALENTS_I_ENHANCE_DATA") addValueTableWithKey(values[0], values[1], "T_TALENTS_I_ENHANCE_DATA");
				if(nameTable =="T_TALENTS_I_ENHANCE_STAGE") addValuesTableWithKey(values[0], values[1],values[2], "T_TALENTS_I_ENHANCE_STAGE");
				if(nameTable =="T_TALENTS_I_PLAY") addTalentImageIPlay(values[0], values[1]);
				if(nameTable =="T_TALENTS_I_RECOGNIZE") addTalentIRecognize(values[0]);
				if(nameTable =="T_TALENTS_I_SPOT") addTalentISpot(values[0]);
				if(nameTable =="T_TALENTS_MANIFESTE") addTalentManifeste(values[0], values[1], values[2]);
				if(nameTable =="T_TALENTS_MANIFESTE_RESULTS") addTalentManifestResult(values[0]);
				if(nameTable =="T_TALENTS_OTHER_RECOGNIZE_IMAGES") addTalentOtherRecognizeImage(values[0],values[1]);
				if(nameTable =="T_TALENTS_OTHER_RECOGNIZE_RESULTS") addTalentOtherRecognizeResult(values[0]);
				if(nameTable =="T_USER_DATA") addLastSeenPageId(values[0],values[1],"T_USER_DATA");
				if(nameTable =="T_TALENTS_OTHER_RECOGNIZE") addTalentOtherRecognize(values[0],values[1],values[2]);
				if(nameTable =="T_COMPASS_ACTIONS_TEMP")compass_actions_setValue(values[0],values[1]);
				if(nameTable =="T__STATUS_PREGRESSION")set_Status_Progression(values[0],values[1]);
				if(nameTable =="T_LOCKED_PAGES") addLockedPage(values[0]);
		}
	}
	setGetConnection("yes", function(){
		$.mobile.changePage('#' + dashBoardPage.id);
	});
}

// quand le user s'agit d'un coach
function getLoginCoach(){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getLoginBddCoch',
			parameters : []
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessLoginCoach,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessLoginCoach(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		verifLoginCoach(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}

function verifLoginCoach(result){
	
	var loginCurrent = $('#'+authentication.id +' [data-id=login]').val();
	var passCurrent = $('#'+authentication.id +' [data-id=password]').val();
	var findUser = false;
	for(var i=0;i<result.length;i++){
		if(result[i].loginCoach == loginCurrent ) if(result[i].passwordCaoch == passCurrent) {findUser = true;}
	}
	if(findUser){
		setUserName(loginCurrent);
		$.mobile.changePage('#' + homeCoachPage.id);	
	}else{
		// ecrire a l'utilisateur que le login ou mot de passe est incorrecte
		$('#'+authentication.id +' [data-id=wrongLogin]').css("visibility","visible");
		$('#'+authentication.id +' [data-id=wrongPassword]').css("visibility","visible");
	}
	
}
