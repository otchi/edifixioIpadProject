
/* JavaScript content from js/visibility/tellYou.js in folder common */
$(document).on("pagebeforeshow", "#" + visibilityTellYou.id, function(event) {
	visibility_tellYou_getAllResponse(key, function(listeResponse){
		for( var value in listeResponse ){
			$("#" + visibilityTellYou.id+ ' textarea[data-id='+listeResponse[value][0]+']').val(listeResponse[value][1]);
			}
		visibility_tellYou_verifInformation();
	}, function(){
		console.log('reponses are not setted yet');
	});
});


// add click event on counter validation button
$( '#'+visibilityTellYou.id + " button[data-class = validate]").on("click", function(e) {
	setActivityStatus(visibilityTellYou.id,SCREEN_STATUS_FINISHED, function(){
		setActivityStatus(visibilityTellWhatYouOffer.id, SCREEN_STATUS_ACCESSIBLE, function(){
			$.mobile.changePage('#' + visibilityTellWhatYouOffer.id);
		});
	});
});

//add click event on counter validation button
$( '#'+visibilityTellYou.id + " button[data-class = next]").on("click", function(e) {
	$.mobile.changePage('#' + visibilityTellWhatYouOffer.id);
});

$("#" + visibilityTellYou.id+' textarea[data-id]').on("keyup", function(e) {
	
	var value = $(this).val().trim();
	var key = $(this).attr('data-id');
	setActivityStatus(visibilityTellYou.id, SCREEN_STATUS_IN_PROGRESS, function(){
		if((value)||(value.length == 0))
			if(value.length == 0){
				visibility_tellYou_deleteKey(key, function(){
					visibility_tellYou_verifInformation();
				});
			}
			else {
				visibility_tellYou_setKey(key,value,function(){
					visibility_tellYou_verifInformation();
				});
			}
	});
});

function visibility_tellYou_verifInformation(){
	var responseEmpty = true;
	$( "#" + visibilityTellYou.id+' textarea[data-id]' ).each(function() {
		if($(this).val().trim().length == 0) responseEmpty = false;
	});
	if(responseEmpty)toggleVisibility("#" + visibilityTellYou.id+' [data-class=validate]',true);
	else toggleVisibility("#" + visibilityTellYou.id+' [data-class=validate]',false);
}