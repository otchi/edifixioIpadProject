
/* JavaScript content from js/compass/myVisionMyMissionDescription.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassmyVisionMyMissionDescriptionPage.id, function(event) {
	toggleEnabling('#'+compassmyVisionMyMissionDescriptionPage.id+' button',true);
	getAllTitleImage(function(TitleImageMap) {			
		for(var i =1;i<4;i++){
			$('#contributeD'+i).val(TitleImageMap[i]);		
			}
	});
	
	getAllVerbsMyMission(function(verbsIds) {	
	for(var i=0;i<verbsIds.length;i++){
			$('#verb'+(i+1)).val($.i18n.prop('compass.myVision.myMission.verbs.'+verbsIds[i]));
		}
	});	
	
	getAllVisionImages(function(imagesMap) {

		for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
			$('#myValuemyMissionimage_' + imageId).empty();
			document.getElementById('myValuemyMissionimage_' + imageId).appendChild(image);
		}
		$('#'+compassmyVisionMyMissionDescriptionPage.id+' img').css("width","200px");
		$('#'+compassmyVisionMyMissionDescriptionPage.id+' img').css("height","200px");
		$('#'+compassmyVisionMyMissionDescriptionPage.id+' textarea').attr("placeholder",$.i18n.prop('compass.myVision.myMission.description'));
	});
	
	getCompassVisionMission(function(mission){
		
		$("#" + compassmyVisionMyMissionDescriptionPage.id +' textarea').val(mission);
		if(mission.length>0) toggleEnabling('#'+compassmyVisionMyMissionDescriptionPage.id+' button',false);
		else toggleEnabling('#'+compassmyVisionMyMissionDescriptionPage.id+' button',true);	
	});
});

$("#" + compassmyVisionMyMissionDescriptionPage.id +' textarea').on("keyup", function(e) {
	var mission = $(this).val();
	compass_vision_setMission($(this).val(), function() {		
		if(mission.length>0) toggleEnabling('#'+compassmyVisionMyMissionDescriptionPage.id+' button',false);
		else toggleEnabling('#'+compassmyVisionMyMissionDescriptionPage.id+' button',true);	
	}); 
});


// Add click event on button
$('#'+compassmyVisionMyMissionDescriptionPage.id+' button').on("click", function(e) {
	setActivityStatus(compassmyVisionMyMissionDescriptionPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log('activity in progress');	 	
	 	$.mobile.changePage("#" + compassSummaryPage.id);
	});
});