
/* JavaScript content from js/compass/myValuesProLifeActionDescription.js in folder common */


var cpt = 0;

//sauvgarde quand on appuie sur le input
$('[data-id="compass_compass_myValue_textarea"]').on("keyup", function(e) {
	compass_actions_setResponse($(this).attr("data-pos"),$(this).val(), function() {
		toggleEnabling('#compass_actionsDescriptionValidation',true);
		if(($('#action1 input').val().length > 0)&&($('#action1 textarea').val().length>0)){
			if(cpt==1){toggleEnabling('#compass_actionsDescriptionValidation',false);}
			if(($('#action2 input').val().length > 0)&&($('#action2 textarea').val().length>0)){
				if(cpt==2){toggleEnabling('#compass_actionsDescriptionValidation',false);}
				if(($('#action3 input').val().length > 0)&&($('#action3 textarea').val().length>0)){
					if(cpt==3){toggleEnabling('#compass_actionsDescriptionValidation',false);}
				}
			}
		}
	});  	
});

//Open datebox on text field click
$('#compass_myValue_actionDate1').on("click", function(e) {
	$('#compass_myValue_actionDate1').datebox('open');
});
$('#compass_myValue_actionDate2').on("click", function(e) {
	$('#compass_myValue_actionDate2').datebox('open');
});
$('#compass_myValue_actionDate3').on("click", function(e) {
	$('#compass_myValue_actionDate3').datebox('open');
});

$(document).on("pagebeforeshow", "#" + compassMyValuesProLifeActionDescriptionPage.id, function(event) {
	
	 toggleEnabling('#compass_actionsDescriptionValidation',true);
	 cpt = 0;
	 $('#action2').hide();
	 $('#action3').hide();
	 
	 getImportantCriteria(function(arrayImportantCriteria) {	
			console.log('return importants Values ');
		 	$('.importantValues_Action').html($.i18n.prop('compass.Myvalue.proLifeImportantValues'));		 
			$('.value1_Action').html(arrayImportantCriteria[0]);
			$('.value2_Action').html(arrayImportantCriteria[1]);
			$('.value3_Action').html(arrayImportantCriteria[2]);
	});	

	 getCompassProLifeAction(function(infoArray) {
		 
		 	for( var id in infoArray){			
		    	$( "#actionDescription"+id ).html(infoArray[id]);
		    	if(infoArray[id].length > 0) $('#action'+id).show(); 
		    	if((infoArray[3]) && (infoArray[3].length > 0))cpt = 3;
		    	else {if((infoArray[2]) && (infoArray[2].length > 0))cpt=2;else cpt = 1;}
			}	    				 
		 });	
		 
	 getCompassProLifeDate("1",function(date) {
			$("#compass_myValue_actionDate1").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date is not setted');
		});
	 getCompassProLifeDate("2",function(date) {
			$("#compass_myValue_actionDate2").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date2 is not setted');
		});
	 getCompassProLifeDate("3",function(date) {
			$("#compass_myValue_actionDate3").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date3 is not setted');
		});	 
	 getCompassProLifeResponse("1",function(text) {
		 $('#action1 textarea').val(text);	
		 getCompassProLifeResponse("2",function(text) {
			 $('#action2 textarea').val(text);
			 getCompassProLifeResponse("3",function(text) {
				 $('#action3 textarea').val(text);
				 if(($('#action1 input').val().length > 0)&&($('#action1 textarea').val().length>0)){
						if(cpt==1){toggleEnabling('#compass_actionsDescriptionValidation',false);}
						if(($('#action2 input').val().length > 0)&&($('#action2 textarea').val().length>0)){
							if(cpt==2){toggleEnabling('#compass_actionsDescriptionValidation',false);}
							if(($('#action3 input').val().length > 0)&&($('#action3 textarea').val().length>0)){
								if(cpt==3)toggleEnabling('#compass_actionsDescriptionValidation',false);{}
							}
						}
					}
			 });
		 });
	 });
	 getProLifeMark (function(mark){
		 $('#ProLifeMarkDescription').html($.i18n.prop('compass.Myvalue.proLifeButton.'+mark));
	 });
	 getActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, function(status){
		if(status == SCREEN_STATUS_FINISHED){
			$('#'+compassMyValuesProLifeActionDescriptionPage.id+' input').attr('disabled','disabled');
			$('#'+compassMyValuesProLifeActionDescriptionPage.id+' textarea').attr('disabled','disabled');
			$('#'+compassMyValuesProLifeActionDescriptionPage.id+' [data-class = next]').css('display','block');
			$('#'+compassMyValuesProLifeActionDescriptionPage.id+' #compass_actionsDescriptionValidation').css('display','none');
		} 
	 });
	
});

//When a date is selected in the datebox, insert it in db
$('[data-id="compass_compass_myValue_date"]').bind('datebox', function(e, p) {
	if (p.method === 'close') {
		var dateString = $(this).val();
		// set current screen in progress "a mettre plus tard"
		setActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log(compassMyValuesProLifeActionDescriptionPage.id + " is now in progress");
		});
		if (!isBlank(dateString)) {
			var selectedDate = $(this).datebox('getTheDate');
			var datePosition = $(this).attr("data-pos");
			setCalendarDate(compassMyValuesProLifeActionDescriptionPage.id + datePosition, selectedDate, "date"+ compassMyValuesProLifeActionDescriptionPage.id +" number  "+datePosition, function(){

	 			compass_actions_setDate(datePosition,selectedDate, function() {
	 				//sayI_morningPages_SetScreenState();
	 				toggleEnabling('#compass_actionsDescriptionValidation',true);
	 				if(($('#action1 input').val().length > 0)&&($('#action1 textarea').val().length>0)){
						if(cpt==1){toggleEnabling('#compass_actionsDescriptionValidation',false);}
						if(($('#action2 input').val().length > 0)&&($('#action2 textarea').val().length>0)){
							if(cpt==2){toggleEnabling('#compass_actionsDescriptionValidation',false);}
							if(($('#action3 input').val().length > 0)&&($('#action3 textarea').val().length>0)){
								if(cpt==3)toggleEnabling('#compass_actionsDescriptionValidation',false);{}
							}
						}
					}
	 			});	 
			});
		}	 		
	}
});	

$("#compass_actionsDescriptionValidation").on("click", function(e) {
	setActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, SCREEN_STATUS_FINISHED, function() {
	 	console.log('Step 3 finished');
	 	setActivityStatus(compassMyValuesProLifeActionResultPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
	 		$.mobile.changePage("#" + compassMyValuesProLifeActionResultPage.id);  
	 	});
	});
});
$("#" + compassMyValuesProLifeActionDescriptionPage.id +" [data-class = next]").on("click", function(e) {
	$.mobile.changePage("#" + compassMyValuesProLifeActionResultPage.id); 
});
