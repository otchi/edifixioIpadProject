
/* JavaScript content from js/compass/myVisionVerbs.js in folder common */
$fieldSet = $("#fieldset_Verbs");
createVerbsMap(); 

for ( var key in verbsMap) {
	
	var valueLabel = getVerbsLocalizedLabel(key);
	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<label for="compass_checkbox_' + key + '">' + valueLabel + '</label>';
	htmlCode += '<input name="compass_checkbox_' + key + '" id="compass_checkbox_' + key + '" type="checkbox" data-mini="true" value="' + key + '"/>';
	htmlCode += '</div>';
	$fieldSet.append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else 
	if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}
	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassmyVisionVerbsPage.id, function(event) {
	toggleEnabling('#'+compassmyVisionVerbsPage.id+' button',true);
	getAllTitleImage(function(TitleImageMap) {			
		for(var i =1;i<4;i++){
			$('#contribute'+i).val(TitleImageMap[i]);		
			}
	});
	
	getAllVerbsMyMission(function(verbsIds) {	
		
		$("#" + compassmyVisionVerbsPage.id + " [type='checkbox']").each(function(i) {
			var verb = parseInt($(this).attr("value"));
			if ($.inArray(verb, verbsIds) != -1) {
				$(this).attr('checked', true);
			} else {
				$(this).attr('checked', false);
			}
			$(this).checkboxradio("refresh");
		});
		var selectedVerbsNumber = $("#" + compassmyVisionVerbsPage.id + " [type='checkbox']:checked ").length;
		toggleEnabling('#'+compassmyVisionVerbsPage.id+' button', selectedVerbsNumber != 3);
	});	
	
	getAllVisionImages(function(imagesMap) {

		for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
			$('#myValuemyMissionverb_' + imageId).empty();
			document.getElementById('myValuemyMissionverb_' + imageId).appendChild(image);
		}
		$('#'+compassmyVisionVerbsPage.id+' img').css("width","200px");
	});
});

//Add click event on each checkbox
$("#" + compassmyVisionVerbsPage.id + " [type='checkbox']").on("click", function(e) {
	
	var verbId = parseInt($(this).attr("value"));
	var isSelected = $(this).is(':checked');

	if (isSelected) {
		addVerbMyMission(verbId, function() {
			setActivityStatus(compassmyVisionVerbsPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				console.log('verb added');
			});
		});
	} else if (!isSelected) {
		removeVerbMyMission(verbId, function() {
			setActivityStatus(compassmyVisionVerbsPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				console.log('verb removed');
			});
		});
	}

	var selectedVerbsNumber = $("#" + compassmyVisionVerbsPage.id + " [type='checkbox']:checked ").length;
	toggleEnabling('#'+compassmyVisionVerbsPage.id+' button', selectedVerbsNumber != 3);
});


// Add click event on button
$('#'+compassmyVisionVerbsPage.id+' button').on("click", function(e) {
	setActivityStatus(compassmyVisionVerbsPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log('activity in progress');	 	
	 	$.mobile.changePage("#" + compassmyVisionMyMissionDescriptionPage.id);
	});
});