
/* JavaScript content from js/compass/compass.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyMissionProLifeActionBoussole.id, function(event) {
	
	getCompassVisionMission(function(mission){
		 $("#markMission").html(mission);	 
	 });
	getAllVisionImages(function(imagesMap) {
    	for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
			$('#markPassion' + imageId).empty();
			document.getElementById('markPassion' + imageId).appendChild(image);
		}
		$('#'+compassMyMissionProLifeActionBoussole.id+' img').css("width","200px");
	});
});

//Add click event on button
$('#'+compassMyMissionProLifeActionBoussole.id +' [data-id=submit]').on("click", function(e) {
	
	$.mobile.changePage("#" + compassSummaryPage.id);
		
});

