
/* JavaScript content from js/compass/MyMissionProLife.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyMissionProLife.id, function(event) {
	
	getAllVisionImages(function(imagesMap) {
    	for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src","data:image/jpeg;base64,"+ imagesMap[imageId]);
			$('#MyMissionProLifeimage_' + imageId).empty();
			document.getElementById('MyMissionProLifeimage_' + imageId).appendChild(image);
		}
		$('#'+compassMyMissionProLife.id+' img').css("width","200px");
	});
	
	getCompassVisionMission(function(mission){
		$("#" + compassMyMissionProLife.id +' textarea').val(mission);
	});
});

//Add click event on button
$('#'+compassMyMissionProLife.id +' button').on("click", function(e) {
		var mark = $(this).attr("data-value");
		console.log('activity 1 in progress choose actions : ');
		removeMarkProLife(function() {
			addMarkProLife(mark, function() {			
					setActivityStatus(compassMyMissionProLife.id, SCREEN_STATUS_IN_PROGRESS, function() {
					console.log('value added');
					if(mark >2)$.mobile.changePage("#" + compassSummaryPage.id);
					else $.mobile.changePage("#" + compassMyMissionProLifeAction.id);
				});
			});
		});	 	
});