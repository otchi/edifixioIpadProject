
/* JavaScript content from js/compass/summary.js in folder common */



$(document).on("pagebeforeshow", "#" + compassSummaryPage.id, function(event) {
	
	getActivityStatus(compassMyValuesPage.id, function(activityStatus) {
		getActivityStatus(compassMyValuesProLifePage.id, function(activityStatusStep1) {
			getActivityStatus(compassMyValuesProLifeActionPage.id, function(activityStatusStep2) {	
				getActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, function(activityStatusStep3) {
					getActivityStatus(compassMyValuesProLifeActionResultPage.id, function(activityStatusStep4) {
						if(activityStatusStep4){
							$("#compass_1_status").html(activityStatusStep4);
						}else{
							if(activityStatusStep3){
								$("#compass_1_status").html(activityStatusStep3);
							}else{
								if(activityStatusStep2){
									$("#compass_2_status").html(activityStatusStep2);
								}else{
									if(activityStatusStep1){
										$("#compass_1_status").html(activityStatusStep1);
									}else{
										if(activityStatus ){
											$("#compass_1_status").html(activityStatus);
										}else{
											$("#compass_1_status").html(SCREEN_STATUS_LOCKED);
										}
									}
								}
							}
						}
					});
				});
			});
		});
	});
	
	getActivityStatus(sayImorningPagesPage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#compass_2_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#compass_2_status").html(activityStatus);

		}
	});
	
	getActivityStatus(compassMyMissionProLife.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#compass_3_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#compass_3_status").html(activityStatus);

		}
	});
	
	
});
$("#compass_summary_stage_1").on("click", function(e) {
	getActivityStatus(compassMyValuesPage.id, function(activityStatus) {
		getActivityStatus(compassMyValuesProLifePage.id, function(activityStatusStep1) {
			getActivityStatus(compassMyValuesProLifeActionPage.id, function(activityStatusStep2) {	
				getActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, function(activityStatusStep3) {
					getActivityStatus(compassMyValuesProLifeActionResultPage.id, function(activityStatusStep4) {
						if(activityStatusStep4 && (activityStatusStep4 == SCREEN_STATUS_ACCESSIBLE || activityStatusStep4 == SCREEN_STATUS_IN_PROGRESS)){
							$.mobile.changePage('#' + compassMyValuesProLifeActionResultPage.id);
						}else{
							if(activityStatusStep3 && (activityStatusStep3 == SCREEN_STATUS_ACCESSIBLE || activityStatusStep3 == SCREEN_STATUS_IN_PROGRESS)){
								$.mobile.changePage('#' + compassMyValuesProLifeActionDescriptionPage.id);
							}else{
								if(activityStatusStep2 && (activityStatusStep2 == SCREEN_STATUS_ACCESSIBLE || activityStatusStep2 == SCREEN_STATUS_IN_PROGRESS)){
									$.mobile.changePage('#' + compassMyValuesProLifeActionPage.id);
								}else{
									if(activityStatusStep1 && (activityStatusStep1 == SCREEN_STATUS_ACCESSIBLE || activityStatusStep1 == SCREEN_STATUS_IN_PROGRESS)){
										$.mobile.changePage('#' + compassMyValuesProLifePage.id);
									}else{
										if(activityStatus && (activityStatus == SCREEN_STATUS_ACCESSIBLE || activityStatus == SCREEN_STATUS_IN_PROGRESS)){
											$.mobile.changePage('#' + compassMyValuesPage.id);
										}else{
											if(activityStatusStep4 == SCREEN_STATUS_FINISHED || activityStatusStep1 == SCREEN_STATUS_FINISHED) $.mobile.changePage('#' + compassMyValuesPage.id);
										}
									}
								}
							}
						}
					});
				});
			});
		});
	});
});
// TEMP - authorize navigate even if not accessible
$("#compass_summary_stage_2").on("click", function(e) {
	$.mobile.changePage('#' + compassMyVisionPage.id);
});

$("#compass_summary_stage_3").on("click", function(e) {
	$.mobile.changePage('#' + compassMyMissionProLife.id);
});