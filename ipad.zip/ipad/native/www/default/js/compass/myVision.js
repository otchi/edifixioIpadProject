
/* JavaScript content from js/compass/myVision.js in folder common */

$('#compass_myVision_main_wish').on("keyup", function(e) {
	var wish = $(this).val();
	compass_actions_setWish(wish, function() {
		setActivityStatus(compassMyVisionPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log('wish added');
		});
	if(wish.length>0){
		toggleEnabling('#compassMyVisionSubmit',false);
		}else{
		toggleEnabling('#compassMyVisionSubmit',true);
	}
	});
});
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyVisionPage.id, function(event) {
	
	toggleEnabling('#compassMyVisionSubmit',true);
	getCompassVisionValue("wish",function(wish) {
		if(wish){
			 $('#compass_myVision_main_wish').val(wish); 
			 if(wish.length>0){
				 setActivityStatus(compassMyVisionPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
					console.log('wish added');
					toggleEnabling('#compassMyVisionSubmit',false);
				 });
			 }
		}
	 });
});

// Add click event on button
$("#compassMyVisionSubmit").on("click", function(e) {
	setActivityStatus(compassMyValuesPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log('activity 1 in progress');
	 	$.mobile.changePage("#" + compassMyVisionPicturesPage.id);
	});
});