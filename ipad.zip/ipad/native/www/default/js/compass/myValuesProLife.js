
/* JavaScript content from js/compass/myValuesProLife.js in folder common */
// a remplacer dans la page




$(document).on("pagebeforeshow", "#" + compassMyValuesProLifePage.id, function(event) {
	
	 getImportantCriteria(function(arrayImportantCriteria) {	
		 	console.log('return importants Values ');
		 	$("#" + compassMyValuesProLifePage.id + ' #importantValues').html($.i18n.prop('compass.Myvalue.proLifeImportantValues'));
			$("#" + compassMyValuesProLifePage.id + ' #value1').html(arrayImportantCriteria[0]);
			$("#" + compassMyValuesProLifePage.id + ' #value2').html(arrayImportantCriteria[1]);
			$("#" + compassMyValuesProLifePage.id + ' #value3').html(arrayImportantCriteria[2]);
	});	
	 getActivityStatus(compassMyValuesProLifePage.id, function(status){
		 if( status && status == SCREEN_STATUS_FINISHED ){
			 $("#" + compassMyValuesProLifePage.id+ ' button[data-value]').attr('disabled','disabled');
			 $("#" + compassMyValuesProLifePage.id+ ' button[data-class = next]').css('display','block');
		 }
	 });
});

//Add click event on button
$("#" + compassMyValuesProLifePage.id+ " #proLifeNotation .ui-btn-inline").on("click", function(e) {
		var mark = $(this).attr("data-value");
		console.log('activity 1 in progress choose actions : ');
		removeProLifeMark(function() {
			addMark(mark, function() {			
					setActivityStatus(compassMyValuesProLifePage.id, SCREEN_STATUS_FINISHED, function() {
						console.log('step 1 finished');
						if(mark >2) {
							$.mobile.changePage("#" + compassSummaryPage.id);		
						}
						else {
							setActivityStatus(compassMyValuesProLifeActionPage.id, SCREEN_STATUS_ACCESSIBLE, function() {	
								$.mobile.changePage("#" + compassMyValuesProLifeActionPage.id);
							});
						}
				});
			});
		});	 	
});
$("#" + compassMyValuesProLifePage.id+ " button[data-class = next]").on("click", function(e) {
	getProLifeMark(function(mark){
		mark = parseInt(mark);
		if(mark){
			if(mark >2) {
				$.mobile.changePage("#" + compassSummaryPage.id);		
			}
			else {
				$.mobile.changePage("#" + compassMyValuesProLifeActionPage.id);
			}
		}
	});
});

