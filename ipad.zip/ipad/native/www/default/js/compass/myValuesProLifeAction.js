
/* JavaScript content from js/compass/myValuesProLifeAction.js in folder common */


$(document).on("pagebeforeshow", "#" + compassMyValuesProLifeActionPage.id, function(event) {
	
	toggleEnabling('#compass_actionsValidation',true);
	
	 getImportantCriteria(function(arrayImportantCriteria) {	
		 	console.log('return importants Values ');
			$("#" + compassMyValuesProLifeActionPage.id + ' #value1_Action').html(arrayImportantCriteria[0]);
			$("#" + compassMyValuesProLifeActionPage.id + ' #value2_Action').html(arrayImportantCriteria[1]);
			$("#" + compassMyValuesProLifeActionPage.id + ' #value3_Action').html(arrayImportantCriteria[2]);
	});
	 
	 getCompassProLifeAction(function(infoArray) {
		for( var id in infoArray){
	    	$( "#" + compassMyValuesProLifeActionPage.id+ " #ProLifeAction"+id ).val(infoArray[id]);
		}
	 });
 	
    getProLifeMark(function(mark) {
    	var actionOne = false;
    	var actionTwo = false;
    	var actionThree = false;
    	if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction1').val().length > 0){actionOne = true; }else{actionOne = false;}
		if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction2').val().length > 0){actionTwo = true; }else{actionTwo = false;}
		if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction3').val().length > 0){actionThree = true; }else{actionThree = false;}
		toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true);
		if(mark == 1){
    		// deux actions minimums sont necessaires
    		   if((actionOne) && (actionTwo)) toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',false);
    		   else toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true);   
    	}else{ 
    		if(mark==2){
    		//une action au minimum est necessaire
    			if(actionOne){
    				if((!actionThree) && (!actionTwo))toggleEnabling('#compass_actionsValidation',false);
    				if((!actionThree) && (actionTwo))toggleEnabling('#compass_actionsValidation',false);
    				if((actionThree) && (actionTwo))toggleEnabling('#compass_actionsValidation',false);
    				
    			}else toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true);
    		}
    	}
    	$("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeMark').html($.i18n.prop('compass.Myvalue.proLifeButton.'+mark));	
     });	
     
    getActivityStatus(compassMyValuesProLifeActionPage.id, function(status){
    	if(status == SCREEN_STATUS_FINISHED){
    		$('#'+compassMyValuesProLifeActionPage.id+' input').attr('disabled','disabled');
    		$('#'+compassMyValuesProLifeActionPage.id+' #compass_actionsValidation').css('display','none');
    		$('#'+compassMyValuesProLifeActionPage.id+' [data-class = next]').css('display','block');
    	}
    });
});

$("#" + compassMyValuesProLifeActionPage.id + " #compass_actionsValidation").on("click", function(e) {
	$( '#' + compassMyValuesProLifeActionPage.id+ ' input' ).each(function() {
		var idAction = $(this).attr('data-id');
		if(!($(this).val())) deleteActionMyMissionProLife(idAction);
		setActivityStatus(compassMyValuesProLifeActionPage.id, SCREEN_STATUS_FINISHED, function() {
		 	console.log('Step 2 finished');
		 	setActivityStatus(compassMyValuesProLifeActionDescriptionPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
		 		$.mobile.changePage("#" + compassMyValuesProLifeActionDescriptionPage.id); 
		 	});
		});
	});
});

$("#" + compassMyValuesProLifeActionPage.id + " button[data-class = next]").on("click", function(e) {
	$.mobile.changePage("#" + compassMyValuesProLifeActionDescriptionPage.id);
});

$("#" + compassMyValuesProLifeActionPage.id + " #ProLifeAction input").on("keyup", function(e) {
	var actionOne = false;
	var actionTwo = false;
	var actionThree = false;
	var action = $(this).attr('data-id'); 
	var value = $(this).val().trim();
	if((value)||(value.length == 0)){
		if(value.length == 0){
			compass_Action_delete(action, function(){
				console.log("delete action number  "+ action);
				compass_myValues_Action_verifAction(actionOne, actionTwo, actionThree);
			});
		}else{
			addActionProLife(action,$(this).val(), function() {
				compass_myValues_Action_verifAction(actionOne, actionTwo, actionThree);
			});    	
		}
	}
});

function compass_myValues_Action_verifAction(actionOne,actionTwo,actionThree){
	
	if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction1').val().length > 0){actionOne = true; }else{actionOne = false;}
	if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction2').val().length > 0){actionTwo = true; }else{actionTwo = false;}
	if($("#" + compassMyValuesProLifeActionPage.id + ' #ProLifeAction3').val().length > 0){actionThree = true; }else{actionThree = false;}
	toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true);
	getProLifeMark(function(mark){ 
		if(mark == 1){
			// deux actions minimums sont necessaires
			if((actionOne) && (actionTwo)) toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',false);
			    else toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true); 
		}else{ 
			if(mark==2){
			//une action au minimum est necessaire
				if(actionOne){
					if((!actionThree) && (!actionTwo))toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',false);
					if((!actionThree) && (actionTwo))toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',false);
					if((actionThree) && (actionTwo))toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',false);
				}else toggleEnabling("#" + compassMyValuesProLifeActionPage.id + ' #compass_actionsValidation',true);
			}
		}
	 });
}