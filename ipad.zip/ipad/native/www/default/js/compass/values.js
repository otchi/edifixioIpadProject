
/* JavaScript content from js/compass/values.js in folder common */
function Value(id, valueLabel) {
	this.id = id;
	this.valueLabel = valueLabel;
};

var valueMap = {};

function getValueLocalizedLabel(valueId) {
	var value = valueMap[valueId];
	if (value && value != null) {		
			return value.valueLabel;		
	}
}

function createValue(id, valueLabel) {
	valueMap[id] = new Value(id, valueLabel);
}
function createValueMap() {
	var sampleNumberString = $.i18n.prop('compass.value.number');
	
	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('compass.value.'+i);	
				createValue(i, title);
			}
	} else {
		console.log("compass.value.number is not a number");
	}
	
}