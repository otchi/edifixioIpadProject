
/* JavaScript content from js/compass/MyMissionProLifeActionDescription.js in folder common */

var cpt = 0 ;

//sauvgarde quand on appuie sur le input
$('[data-id="compass_myMission_textarea"]').on("keyup", function(e) {
	compass_myMission_setActionResponse($(this).attr("data-pos"),$(this).val(), function() {
		toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',true);
		if(($('#myMissionaAtion1 input').val().length > 0)&&($('#myMissionaAtion1 textarea').val().length>0)){
			if(cpt==1){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
			if(($('#myMissionaAtion2 input').val().length > 0)&&($('#myMissionaAtion2 textarea').val().length>0)){
				if(cpt==2){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
				if(($('#myMissionaAtion3 input').val().length > 0)&&($('#myMissionaAtion3 textarea').val().length>0)){
					if(cpt==3){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
				}
			}
		} 
	});  	
});
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyMissionProLifeActionDescription.id, function(event) {

	toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',true);
	getAllVisionImages(function(imagesMap) {
    	for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src","data:image/jpeg;base64,"+ imagesMap[imageId]);
			$('#MyMissionProLife' + imageId).empty();
			document.getElementById('MyMissionProLife' + imageId).appendChild(image);
		}
		$('#'+compassMyMissionProLifeActionDescription.id+' img').css("width","200px");
	});
	
	getCompassVisionMission(function(mission){
		$("#" + compassMyMissionProLifeActionDescription.id +' .mission').val(mission);
	});
	
	 cpt = 0;
	 $('#myMissionaAtion2').hide();
	 $('#myMissionaAtion3').hide();
	 

	 getActionProLife(function(infoArray) {
		 
			for( id in infoArray){		
				console.log(id + "==="+infoArray[id]);
		    	$( "#myMissionActionDescription"+id ).html(infoArray[id]);
		    	if(infoArray[id].length > 0) $('#myMissionaAtion'+id).show(); 
		    	if((infoArray[3]) && (infoArray[3].length > 0))cpt = 3;
		    	else {if((infoArray[2]) && (infoArray[2].length > 0))cpt=2;else cpt = 1;}
			}	  
		console.log("cpt =="+cpt);
		 });	
	 
	 getCompassActionDate("1",function(date) {
			$("#compassmyMissionactionDate1").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date is not setted');
		});
	 getCompassActionDate("2",function(date) {
			$("#compassmyMissionactionDate2").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date2 is not setted');
		});
	 getCompassActionDate("3",function(date) {
			$("#compassmyMissionactionDate3").datebox("setTheDate", date);
		}, function() {
			console.log('date actionPages_date3 is not setted');
		});	
		
	 getCompassActionResponse("1",function(text) {
		 $('#myMissionaAtion1 textarea').val(text);	
		 getCompassActionResponse("2",function(text) {
			 $('#myMissionaAtion2 textarea').val(text);
			 getCompassActionResponse("3",function(text) {
				 $('#myMissionaAtion3 textarea').val(text);
				 
				 if(($('#myMissionaAtion1 input').val().length > 0)&&($('#myMissionaAtion1 textarea').val().length>0)){
						if(cpt==1){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
						if(($('#myMissionaAtion2 input').val().length > 0)&&($('#myMissionaAtion2 textarea').val().length>0)){
							if(cpt==2){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
							if(($('#myMissionaAtion3 input').val().length > 0)&&($('#myMissionaAtion3 textarea').val().length>0)){
								if(cpt==3)toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);{}
							}
						}
					} 
			 });
		 });
	 });
	  
	// When a date is selected in the datebox, insert it in db
	 $('[data-id="compass_myMission_date"]').bind('datebox', function(e, p) {
	 	if (p.method === 'close') {
	 		var dateString = $(this).val();
	 		// set current screen in progress "a mettre plus tard"
	 		setActivityStatus(compassMyMissionProLifeActionDescription.id, SCREEN_STATUS_IN_PROGRESS, function() {
	 			console.log(compassMyMissionProLifeActionDescription.id + " is now in progress");
	 		});
	 		if (!isBlank(dateString)) {
	 			var selectedDate = $(this).datebox('getTheDate');
	 			setCalendarDate(compassMyMissionProLifeActionDescription.id +$(this).attr("data-pos"), selectedDate, "date compassMyMissionProLifeActionDescription.id number  "+$(this).attr("data-pos"), function(){
			 			compass_myMission_setActionDate($(this).attr("data-pos"),selectedDate, function() {
			 				toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',true);
			 				if(($('#myMissionaAtion1 input').val().length > 0)&&($('#myMissionaAtion1 textarea').val().length>0)){
								if(cpt==1){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
								if(($('#myMissionaAtion2 input').val().length > 0)&&($('#myMissionaAtion2 textarea').val().length>0)){
									if(cpt==2){toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);}
									if(($('#myMissionaAtion3 input').val().length > 0)&&($('#myMissionaAtion3 textarea').val().length>0)){
										if(cpt==3)toggleEnabling("#" + compassMyMissionProLifeActionDescription.id+' button',false);{}
									}
								}
							} 
			 			});	 
	 			});
	 		}	
	 		
	 	}
	 });  
});	
	
//Open datebox on text field click
$('#compassmyMissionactionDate1').on("click", function(e) {
	$('#compassmyMissionactionDate1').datebox('open');
});
$('#compassmyMissionactionDate2').on("click", function(e) {
	$('#compassmyMissionactionDate2').datebox('open');
});
$('#compassmyMissionactionDate3').on("click", function(e) {
	$('#compassmyMissionactionDate3').datebox('open');
});	

//Add click event on button
$("#" + compassMyMissionProLifeActionDescription.id+' button').on("click", function(e) {
	setActivityStatus(compassMyValuesPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		//console.log('activity 1 in progress');
	 	$.mobile.changePage("#" + compassMyMissionProLifeActionResult.id);
	 //	}); 
	});
});
