
/* JavaScript content from js/compass/myVisionMyMission.js in folder common */


// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyVisionMyMissionPage.id, function(event) {
	toggleEnabling('#' + compassMyVisionMyMissionPage.id + ' button',true);
	getAllVisionImages(function(imagesMap) {
		for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
			$('#myValue_myMission_image_' + imageId).empty();
			document.getElementById('myValue_myMission_image_' + imageId).appendChild(image);
		}
		getAllTitleImage(function(TitleImageMap) {			
			for(var i =1;i<4;i++){
				$('#myValue_myMission_input_'+i).val(TitleImageMap[i]);		
				}
			var cpt = 0;
			for(var i =1;i<4;i++){
			if($('#myValue_myMission_input_'+i).val().length > 0)cpt = cpt + 1;		
			}
			if(cpt==3)toggleEnabling('#' + compassMyVisionMyMissionPage.id + ' button',false);
			else toggleEnabling('#' + compassMyVisionMyMissionPage.id + ' button',true);
		});
		$('#'+compassMyVisionMyMissionPage.id +' img').css("width","300px");
		$('#'+compassMyVisionMyMissionPage.id +' img').css("height","300px");
		
	});
});

//sauvgarde quand on appuie sur le input
$("#" + compassMyVisionMyMissionPage.id +' [name="actions"]').on("keyup", function(e) {
	compass_myVision_setTitleImage($(this).attr("data-id"),$(this).val(), function() {
		var cpt = 0;
		for(var i =1;i<4;i++){
		if($('#myValue_myMission_input_'+i).val().length > 0){cpt = cpt + 1;}		
		}
		if(cpt==3)toggleEnabling('#' + compassMyVisionMyMissionPage.id + ' button',false);
		else toggleEnabling('#' + compassMyVisionMyMissionPage.id + ' button',true);
	});  	
});

// Add click event on button
$('#' + compassMyVisionMyMissionPage.id + ' button').on("click", function(e) {
	setActivityStatus(compassMyVisionMyMissionPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log('activity in progress');
	 	$.mobile.changePage("#" + compassmyVisionVerbsPage.id);
	 //	}); 
	});
});