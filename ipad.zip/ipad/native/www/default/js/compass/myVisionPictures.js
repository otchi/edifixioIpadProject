
/* JavaScript content from js/compass/myVisionPictures.js in folder common */
var image1 = false ;
var image2 = false ;
var image3 = false ;
var imageNumber= 0;
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyVisionPicturesPage.id, function(event) {
	toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',true);
	getAllVisionImages(function(imagesMap) {
		if(imagesMap.length == 4){toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',false);}
		if(imagesMap.length > 0) cpt_image = imagesMap.length;
		for ( imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
			$('#myValue_picture_image_' + imageId).empty();
			document.getElementById('myValue_picture_image_' + imageId).appendChild(image);
		}
		$('#'+compassMyVisionPicturesPage.id +' img').css("width","300px");
		$('#'+compassMyVisionPicturesPage.id +' img').css("height","300px");
	});	
});


$("#myValue_picture_button_1").on("click", function(e) {
	
	if((image1)&&(image2)&&(image3)){toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',false);}
	$("#myValue_picture_file_1").click();	
});

$("#myValue_picture_button_2").on("click", function(e) {	
	
	if((image1)&&(image2)&&(image3)){toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',false);}
	$("#myValue_picture_file_2").click();
});

$("#myValue_picture_button_3").on("click", function(e) {
	
	if((image1)&&(image2)&&(image3)){toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',false);}
	$("#myValue_picture_file_3").click();
});



$('#'+ compassMyVisionPicturesPage.id +' [data-id=capturePicture]').on("click", function(e) {
	imageNumber = $(this).attr("data-image");
	Camera.PictureSourceType.PHOTOLIBRARY;
    navigator.camera.getPicture(uploadPhotoVision,null,{sourceType:0,quality:60,destinationType:0});
});

function uploadPhotoVision(data){
			addVisionImage(imageNumber, data, function() {
				var image = document.createElement("img");
				image.classList.add("VisionImage");
				image.setAttribute("src", "data:image/jpeg;base64," +data);
				$('#myValue_picture_image_'+imageNumber).empty();
				document.getElementById('myValue_picture_image_'+imageNumber).appendChild(image);
				$('#'+compassMyVisionPicturesPage.id +' img').css("width","300px");
				$('#'+compassMyVisionPicturesPage.id +' img').css("height","300px");
			});
 
	 if(imageNumber==1)image1=true;
	 if(imageNumber==2)image2=true;
	 if(imageNumber==3)image3=true;
	 if((image1)&&(image2)&&(image3))toggleEnabling('#'+compassMyVisionPicturesPage.id+' [data-id=submit]',false);
}
  
// Add click event on button
$('#'+compassMyVisionPicturesPage.id+' [data-id=submit]').on("click", function(e) {
	setActivityStatus(compassMyVisionPicturesPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log('activity in progress');	 	
	 	$.mobile.changePage("#" + compassMyVisionMyMissionPage.id);
	});
});






