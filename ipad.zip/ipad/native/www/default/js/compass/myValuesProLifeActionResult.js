
/* JavaScript content from js/compass/myValuesProLifeActionResult.js in folder common */


$('#compass_myValue_actionResult').on("keyup", function(e) {
	var result = $(this).val();
	compass_actions_setResult($(this).val(), function() {
		if(result.length>0){
			toggleEnabling('#compass_actionsResult1',false);
			toggleEnabling('#compass_actionsResult2',false);
			toggleEnabling('#compass_actionsResult3',false);	
		}else{
			toggleEnabling('#compass_actionsResult1',true);
			toggleEnabling('#compass_actionsResult2',true);
			toggleEnabling('#compass_actionsResult3',true);
		}
	});  	
});
$(document).on("pagebeforeshow", "#" + compassMyValuesProLifeActionResultPage.id, function(event) {
	toggleEnabling('#compass_actionsResult1',true);
	toggleEnabling('#compass_actionsResult2',true);
	toggleEnabling('#compass_actionsResult3',true);
	 cpt_result = 0 ;
	 $('#action2_result').hide();
	 $('#action3_result').hide();
	 
	 
	 getCompassProLifeAction(function(infoArray) {	
			for( var id in infoArray){			
		    	$( "#actionResult"+id ).html(infoArray[id]);
		    	if(infoArray[id].length > 0) $('#action'+id+'_result').show(); 
			}	 
		 });
	 getProLifeMark (function(mark){
		 if(mark=="1"){$('#compass_actionsResult1').show();}
	 });
	 getCompassProLifeResult(function(result) {	
		 if((result) && (result.length>0)){
			$('#compass_myValue_actionResult').val(result);
			toggleEnabling('#compass_actionsResult1',false);
			toggleEnabling('#compass_actionsResult2',false);
			toggleEnabling('#compass_actionsResult3',false);
		 }
		 else {
			console.log('Result is not setted');
			toggleEnabling('#compass_actionsResult1',true);
			toggleEnabling('#compass_actionsResult2',true);
			toggleEnabling('#compass_actionsResult3',true);
		 }
	 });
	 getActivityStatus(compassMyValuesProLifeActionResultPage.id, function(status){
		 if(status == SCREEN_STATUS_FINISHED){
			 $('#'+compassMyValuesProLifeActionResultPage.id+ ' button[data-id]').attr('disabled','disabled');
			 $('#'+compassMyValuesProLifeActionResultPage.id+ ' textarea').attr('disabled','disabled');
			 $('#'+compassMyValuesProLifeActionResultPage.id+ ' [data-class = next]').css('display','block');
		 }
	 });
});

$('[data-id="compass_mark_result"]').on("click", function(e) {
	var mark = $(this).attr("data-value");
	setActivityStatus(compassMyValuesProLifeActionResultPage.id, SCREEN_STATUS_FINISHED, function() {
		console.log('Step 4 finished');
		removeProLifeMark(function() {
			addMark(mark, function() {			
				console.log('my Value finished');
				$.mobile.changePage("#" + compassSummaryPage.id);
			});
		});
	 	 
	});
});
$("#" + compassMyValuesProLifeActionResultPage.id +' [data-class=next]').on("click", function(e) {
	$.mobile.changePage("#" + compassSummaryPage.id);
});
