
/* JavaScript content from js/compass/myValues.js in folder common */
// Load values list
$fieldSet = $("#identFieldset");
var aClass = 'a';
var bClass = 'b';
var cClass = 'c';
var dClass = 'd';
var currentClass = 'a';
createValueMap();
$('#11').html($.i18n.prop('compass.value.array.1')); 
$('#21').html($.i18n.prop('compass.value.array.2')); 
$('#31').html($.i18n.prop('compass.value.array.3')); 
$('#41').html($.i18n.prop('compass.value.array.4')); 
$('#51').html($.i18n.prop('compass.value.array.5')); 
$('#61').html($.i18n.prop('compass.value.array.6')); 
$('#compassMyValues').hide();
$('[data-id=description]').hide();

for ( var key in valueMap) {
	
	var valueLabel = getValueLocalizedLabel(key);
	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<label for="compass_myValues_checkbox_' + key + '">' + valueLabel + '</label>';
	htmlCode += '<input name="compass_myValues_checkbox_' + key + '" id="compass_myValues_checkbox_' + key + '" type="checkbox" data-mini="true" value="' + key + '"/>';
	htmlCode += '</div>';
	$fieldSet.append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}

// Add click event on each checkbox
$("#" + compassMyValuesPage.id + " [type='checkbox']").on("click", function(e) {
	toggleVisibility('#importantValue',($("td .ui-radio-on").length==30));
	var arrayValue=new Array();
	var arrayValueId=new Array();
	var valueId = parseInt($(this).attr("value"));
	var isSelected = $(this).is(':checked');
	
		$("#" + compassMyValuesPage.id + " [type='checkbox']:checked").each(function(i) {
			var value = parseInt($(this).attr("value"));
			var valueLabel = getValueLocalizedLabel(value);
			arrayValue.push(valueLabel);
			arrayValueId.push(value);
		});				
				
		if(arrayValue.length!=6){
			$('#compassMyValues').hide();
			$('[data-id=description]').hide();
		}
		 var indice = 11;			
			for(var i=0;i<arrayValue.length;i++){
				indice = indice +1;
				console.log(arrayValue[i]);
				$('#compass_values #'+indice).html(arrayValue[i]); 
			}
		if(arrayValue.length==6){
			$('#compassMyValues').show();
			$("#" + compassMyValuesPage.id +' [data-id=description]').show();
		
			var indexe= 2;
			for ( var i=0;i<arrayValueId.length; i++) {
			
				$('#2'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#3'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#4'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#5'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#6'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);				
				indexe = indexe + 1;
			}
			var indice2 = 11;
			  for(var i=1;i<7;i++){
				  indice2 = indice2 + 1;
				  var temp = $('#'+indice2).html();
				  $('.compass'+i).html(temp);
				  $('.compass'+i).attr("value",temp);
			  }	
			  
		}
			
			if (isSelected) {	
				addValueIRecognize(valueId, function() {				
							console.log('value added');
					});
				} else if (!isSelected) {				
					removeValueIRecognize(valueId, function() {				
							console.log('value removed');
					});
					removeValueArray(valueId,  function() {				
							console.log('valueNumber removed');							
					});
				}
			 $('#compassMyValues label').removeClass( "ui-btn-active ui-radio-on" );
			 getAllCompassMyValue(function(infoArray) {
				  
				  for(var i=0;i<infoArray.length;i++){
					  var array = infoArray[i];
					  $('[data-value='+array[2]+'][data-line='+array[0]+']').find('[data-valeur="'+array[3]+'"]').addClass("ui-btn-active ui-radio-on");
					  }
			  });
			
});

// enregitrer dans la bdd la valeur de chaque bouton radio 
$("#" + compassMyValuesPage.id + " [type='radio']").on("click", function(e) {
	var valueCriteria = $(this).attr('value');
	var valueNumber = $(this).parent().parent().parent().attr('data-value');
	var valeurArray = parseInt(valueNumber);
	var valueLabel = getValueLocalizedLabel(valeurArray);
	var lineNumber = $(this).parent().parent().parent().attr('data-line');
	var columnNumber = $(this).parent().parent().parent().attr('data-column');
	setActivityStatus(compassMyValuesPage.id, SCREEN_STATUS_IN_PROGRESS, function(){
		addValueRadioArray(lineNumber,columnNumber,valueNumber,valueCriteria,valueLabel, function() {
				console.log('value radio added');
				toggleVisibility('#importantValue',($("td .ui-radio-on").length==30));
		});	
	});
});



// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyValuesPage.id, function(event) {
	
	toggleEnabling('#compass_myValues_validation',true);
	getAllValueIRecognize(function(valueIds) {	
		// verouiller ou non le bouton quand on revient dessus apres
		$("#" + compassMyValuesPage.id + " [type='checkbox']").each(function(i) {
			var value = parseInt($(this).attr("value"));
			if ($.inArray(value, valueIds) != -1) {
				$(this).attr('checked', true);
			} else {
				$(this).attr('checked', false);
			}
			$(this).checkboxradio("refresh");
		});
	});
	   
	 // reafficher tous les radio qui ont été sauvgardés dans la bdd	 
	  getAllCompassMyValue(function(infoArray) {
		   var arrayValueId = new Array();
		   $("#" + compassMyValuesPage.id + " [type='checkbox']:checked").each(function(i) {
				var value = parseInt($(this).attr("value"));
				arrayValueId.push(value);
			});	
		   var indexe= 2;
			for ( var i=0;i<arrayValueId.length; i++) {
			
				$('#2'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#3'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#4'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#5'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);
				$('#6'+ indexe +'> fieldset ').attr("data-value",arrayValueId[i]);				
				indexe = indexe + 1;
			}			
		  if($("#" + compassMyValuesPage.id + " [type='checkbox']:checked").length == 6){$('#compassMyValues').show();$('[data-id=description]').show();}else{$('#compassMyValues').hide();$('[data-id=description]').hide();}
		  $('#'+compassMyValuesPage.id +' label').removeClass( "ui-btn-active ui-radio-on" );
		 
		  var indice = 11;
		  $("#" + compassMyValuesPage.id + " [type='checkbox']:checked").each(function(i) {
				 var value = parseInt($(this).attr("value"));
				 var valueLabel = getValueLocalizedLabel(value);
				 indice = indice +1;
				 console.log(valueLabel,indice);
				 $('#'+compassMyValuesPage.id +' #'+indice).html(valueLabel); 					
		  });
		  
		  for(var i=0;i<infoArray.length;i++){
			  var array = infoArray[i];
			  $('[data-value='+array[2]+'][data-line='+array[0]+']').find('[data-valeur="'+array[3]+'"]').addClass("ui-btn-active ui-radio-on");
			  }
		  
		  
		  toggleVisibility('#importantValue',($("td .ui-radio-on").length==30));
		  indice = 11;
		  for(var i=1;i<7;i++){
			  indice = indice + 1;
			  var temp = $('#'+compassMyValuesPage.id +' #'+indice).html();
			  $('#'+compassMyValuesPage.id +' .compass'+i).html(temp);
			  $('#'+compassMyValuesPage.id +' .compass'+i).attr("value",temp);
		  }
		  var importantCriteria1 ;
		  var importantCriteria2 ;
		  var importantCriteria3 ;
		  $("#" + compassMyValuesPage.id+ " select" )
		  .change(function () {
			  
			   importantCriteria1 = $("#select-native-14").find(":selected").text();
			   importantCriteria2 = $("#select-native-15").find(":selected").text();
			   importantCriteria3 = $("#select-native-16").find(":selected").text();
				   if((importantCriteria1 !=importantCriteria2)&&(importantCriteria1 !=importantCriteria3)&&(importantCriteria2 !=importantCriteria3)){
					   addImportantCriteria(importantCriteria1,importantCriteria2,importantCriteria3, function() {						
								console.log('Important Criteria added');					
						});	
					   toggleEnabling('#compass_myValues_validation',false);
				   }else{
					   toggleEnabling('#compass_myValues_validation',true);  
				   }
		  })
		  .change();		   
	  });
	  
	  getImportantCriteria(function(arrayImportantCriteria) {	
	 
		  $('#select-native-14 [value="'+arrayImportantCriteria[0]+'"]').prop('selected', true);
		  $('#select-native-15 [value="'+arrayImportantCriteria[1]+'"]').prop('selected', true);
		  $('#select-native-16 [value="'+arrayImportantCriteria[2]+'"]').prop('selected', true);
		  $('#select-native-14').selectmenu('refresh');
		  $('#select-native-15').selectmenu('refresh');
		  $('#select-native-16').selectmenu('refresh');
		 if((arrayImportantCriteria[0] !=arrayImportantCriteria[1])&&(arrayImportantCriteria[0] !=arrayImportantCriteria[2])&&(arrayImportantCriteria[1] !=arrayImportantCriteria[2])){
			 toggleEnabling('#compass_myValues_validation',false);
		 }
		});
	  
	  getActivityStatus(compassMyValuesPage.id, function(status){
		  if(status == SCREEN_STATUS_FINISHED){
			  $('#'+compassMyValuesPage.id + ' input').attr('disabled','disabled');
			  $('#'+compassMyValuesPage.id + ' select').attr('disabled','disabled');
			  $('#'+compassMyValuesPage.id + ' #compass_myValues_validation').css('display','none');
			  $('#'+compassMyValuesPage.id + ' [data-class = next]').css('display','block');
		  }
			  
	  });
	  
});

// Add click event on button
$('#'+compassMyValuesPage.id + ' #compass_myValues_validation').on("click", function(e) {
	setActivityStatus(compassMyValuesPage.id, SCREEN_STATUS_FINISHED, function() {
		console.log('activity 1 in progress');
	 		setActivityStatus(compassMyValuesProLifePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
	 		 console.log('activity 2 in my Values is now accessible');
	 		 $.mobile.changePage("#" + compassMyValuesProLifePage.id);
	  }); 
	});
});

$('#'+compassMyValuesPage.id + ' [data-class = next]').on("click", function(e) {
	 $.mobile.changePage("#" + compassMyValuesProLifePage.id);
});