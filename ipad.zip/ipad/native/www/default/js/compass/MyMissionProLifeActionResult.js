
/* JavaScript content from js/compass/MyMissionProLifeActionResult.js in folder common */

var cptResult = 0 ;

// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyMissionProLifeActionResult.id, function(event) {
	toggleEnabling("#" + compassMyMissionProLifeActionResult.id+' button',true);
	getAllVisionImages(function(imagesMap) {
    	for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64,"+imagesMap[imageId]);
			$('#MyMissionProLifeResult' + imageId).empty();
			document.getElementById('MyMissionProLifeResult' + imageId).appendChild(image);
		}
		$('#'+compassMyMissionProLifeActionResult.id+' img').css("width","200px");
	});
	
	getCompassVisionMission(function(mission){
		$("#" + compassMyMissionProLifeActionResult.id +' .mission').val(mission);
	});
	
	cptResult = 0;
	 $('#myMissionActionResult2').hide();
	 $('#myMissionActionResult3').hide();
	 
	 getActionProLife(function(infoArray) {
	    	$("#myMissionActionR1").html(infoArray[0]);
	    	if(infoArray[1].length>0){cptResult = cptResult + 1;$("#myMissionActionR2").html(infoArray[1]);}
			if(infoArray[2].length>0){cptResult = cptResult + 1;$("#myMissionActionR3").html(infoArray[2]);}
			if(cptResult == 2){$('#myMissionActionResult2').show();$('#myMissionActionResult3').show();}
			if(cptResult == 1){$('#myMissionActionResult2').show();}	    				 
	 });	
	 getCompassActionResult(function(result){
		 $("#" + compassMyMissionProLifeActionResult.id +' textarea').html(result);	 
		 if(result.length>0)toggleEnabling("#" + compassMyMissionProLifeActionResult.id+' button',false);
		 else toggleEnabling("#" + compassMyMissionProLifeActionResult.id+' button',true);
	 });
	 getMarkProLife(function(mark) {
		 if (mark==1) $('#' + compassMyMissionProLifeActionResult.id + ' [data-id = "2"]').show();
		 if (mark==2) $('#' + compassMyMissionProLifeActionResult.id + ' [data-id = "2"]').hide();
	 });

});	
$("#" + compassMyMissionProLifeActionResult.id +' textarea').on("keyup", function(e) {
	var text = $(this).val();
	compass_myMission_setActionResult($(this).val(), function() {
		if(text.length>0)toggleEnabling("#" + compassMyMissionProLifeActionResult.id+' button',false);
		else toggleEnabling("#" + compassMyMissionProLifeActionResult.id+' button',true);
	});
	
});
	
//Add click event on button
$('#'+compassMyMissionProLifeActionResult.id +' button').on("click", function(e) {
		var mark = $(this).attr("data-id");
		console.log('activity in progress choose actions : ');
		removeMarkProLife(function() {
			addMarkProLife(mark, function() {			
					setActivityStatus(compassMyMissionProLifeActionResult.id, SCREEN_STATUS_IN_PROGRESS, function() {
					console.log('mark added');
				    $.mobile.changePage("#" + compassMyMissionProLifeActionBoussole.id);
				});
			});
		});	 	
});


