
/* JavaScript content from js/compass/verbs.js in folder common */
function Verbs(id, verbsLabel) {
	this.id = id;
	this.verbsLabel = verbsLabel;
};

var verbsMap = {};

function getVerbsLocalizedLabel(valueId) {
	var verbs = verbsMap[valueId];
	if (verbs && verbs != null) {		
			return verbs.verbsLabel;		
	}
}

function createVerb(id, verbsLabel) {
	verbsMap[id] = new Verbs(id, verbsLabel);
}
function createVerbsMap() {
	var sampleNumberString = $.i18n.prop('compass.myVision.myMission.verbs.number');
	
	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('compass.myVision.myMission.verbs.'+i);	
				createVerb(i, title);
			}
	} else {
		console.log("compass.myVision.myMission.verbs.number is not a number");
	}
	
}