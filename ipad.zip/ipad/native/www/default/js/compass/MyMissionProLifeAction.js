
/* JavaScript content from js/compass/MyMissionProLifeAction.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + compassMyMissionProLifeAction.id, function(event) {

	getAllVisionImages(function(imagesMap) {
    	for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("VisionImage");
			image.setAttribute("src", "data:image/jpeg;base64,"+ imagesMap[imageId]);
			$('#MyMissionProLife_' + imageId).empty();
			document.getElementById('MyMissionProLife_' + imageId).appendChild(image);
		}
		$('#'+compassMyMissionProLifeAction.id+' img').css("width","200px");
	});
	
	getCompassVisionMission(function(mission){
		$("#" + compassMyMissionProLifeAction.id +' textarea').val(mission);
	});
	
	getActionProLife(function(infoArray) {	 
    	for( var id in infoArray){
	    	$( "#myMissionProLifeAction"+id ).val(infoArray[id]);
		}
	 });
	 
	getMarkProLife(function(mark) {
	    	
		var actionOne = false;
    	var actionTwo = false;
    	var actionThree = false;
    	if($('#myMissionProLifeAction1').val().length > 0){actionOne = true; }else{actionOne = false;}
		if($('#myMissionProLifeAction2').val().length > 0){actionTwo = true; }else{actionTwo = false;}
		if($('#myMissionProLifeAction3').val().length > 0){actionThree = true; }else{actionThree = false;}
		toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);
	    	
			if(mark == 1){
	    		// deux actions minimums sont necessaires
					if(action2){toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);}
					if((actionOne) && (actionTwo)) toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
		    		   else toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);   
	    	}else{ 
	    		if(mark==2){
	    		//une action au minimum est necessaire
	    			if(actionOne){
	    				if((!actionThree) && (!actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
	    				if((!actionThree) && (actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
	    				if((actionThree) && (actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
	    				
	    			}else toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);
	    		}
	    	}
	    	
	    	$('#mark').html($.i18n.prop('compass.Myvalue.proLifeButton.'+mark));	
	    	$('#' + compassMyMissionProLifeAction.id+ ' input').keyup(function( event ) {
	    	var actionOne = false;
	        	var actionTwo = false;
	        	var actionThree = false;
	        	console.log('ohkjh');
	    		var action = $(this).attr('data-id'); 
	    		
	    		if($(this).val()){
		    		var valueAction = $(this).val();
		    		console.log(valueAction);
		    		addActionMyMissionProLife(action,valueAction, function() {
		    			
			    			if($('#myMissionProLifeAction1').val().length > 0){actionOne = true; }else{actionOne = false;}
			    			if($('#myMissionProLifeAction2').val().length > 0){actionTwo = true; }else{actionTwo = false;}
			    			if($('#myMissionProLifeAction3').val().length > 0){actionThree = true; }else{actionThree = false;}
			    			toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);
			    			if(mark == 1){
			    	    		// deux actions minimums sont necessaires
			    				if(action2){toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);}
								if((actionOne) && (actionTwo)) toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
					    		   else toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);   
			    	    	}else{ 
			    	    		if(mark==2){
			    	    		//une action au minimum est necessaire
			    	    			if(actionOne){
			    	    				if((!actionThree) && (!actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
			    	    				if((!actionThree) && (actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
			    	    				if((actionThree) && (actionTwo))toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',false);
			    	    				
			    	    			}else toggleEnabling("#" + compassMyMissionProLifeAction.id +' button',true);
			    	    		}
			    	    	
			    	    	}
		    			//}); 
		    		});
	    		}else deleteActionMyMissionProLife(action);
 		   });
	    });	    	
});

$("#" + compassMyMissionProLifeAction.id +' button').on("click", function(e) {
	$( '#' + compassMyMissionProLifeAction.id+ ' input' ).each(function() {
		var idAction = $(this).attr('data-id');
		if(!($(this).val())) deleteActionMyMissionProLife(idAction);
		setActivityStatus(compassMyMissionProLifeAction.id, SCREEN_STATUS_IN_PROGRESS, function() {
	 		console.log('Writing result of actions and mark');
	 		$.mobile.changePage("#" + compassMyMissionProLifeActionDescription.id); 
	});
	});
});

