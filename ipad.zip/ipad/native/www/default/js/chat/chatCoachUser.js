
/* JavaScript content from js/chat/chatCoachUser.js in folder common */
var chatCoachUserPageloginUser=null;
var chatCoachUserPagelogincoach =null;

$(document).on("pagebeforeshow", "#" + chatCoachUserPage.id, function(event) {
	chatCoachUserPageloginUser=null;
	chatCoachUserPagelogincoach =null;
	$("#" + chatCoachUserPage.id+ ' .chatMessage').empty();
	$('#'+chatCoachUserPage.id + ' [data-id=basic]').val("");
	//faire appel a la fonction pour recuperer l'historique des messages sur le serveur
	// etape 1 : recuperer le login du coach du user courant
	getUserNameValue(function(login){
		chatCoachUserPageloginUser = login;
		getInformationCoach(login);
	});
});

$('#'+chatCoachUserPage.id +' [data-id=chatTeam]').on("click", function(e) {
	$('#'+chatCoachPage.id + ' .chatMessage').empty();
	chatCoachUserPageloginUser=null;
	chatCoachUserPagelogincoach =null;
	$("#" + chatCoachUserPage.id+ ' .chatMessage').empty();
	$('#'+chatCoachUserPage.id + ' [data-id=basic]').val("");
	//faire appel a la fonction pour recuperer l'historique des messages sur le serveur
	// etape 1 : recuperer le login du coach du user courant
	getUserNameValue(function(login){
		chatCoachUserPageloginUser = login;
		getInformationCoach(login);
	});
});

$('#'+chatCoachUserPage.id +' [data-id=send]').on("click", function(e) {
	// $.mobile.changePage("#" + introProfilePage.id);
	//sauvegarde du message envoyé en base de données serveur avec le user courant et le login du coach
	var dNow = new Date();
	var localdate=  dNow.getFullYear() + '-' +(dNow.getMonth()+1)  + '-' +dNow.getDate() + ' ' + dNow.getHours() + ':' + dNow.getMinutes() +':'+ dNow.getSeconds();
	$('#'+chatCoachUserPage.id +' .chatMessage').append('<br>'+chatCoachUserPageloginUser +': <li>'+$('#'+chatCoachUserPage.id +' [data-id=basic]').val()+'</li>'+localdate);
	setMessageCoach(chatCoachUserPageloginUser,$('#'+chatCoachUserPage.id + ' [data-id=basic]').val(),localdate,chatCoachUserPagelogincoach);
	$('#'+chatCoachUserPage.id + ' [data-id=basic]').val("");
});

//fonction qui recupere depuis le serveur les information sur le coach du user courant
function getInformationCoach(param){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getInformationCoach',
			parameters : [param]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessInformationCoach,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessInformationCoach(result){
	WL.Logger.debug("loadFeedsSuccessInformationCoach success");
	if (result.invocationResult.resultSet.length>0) 
		saveMessageCoachUser(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}

//sauvegarde du message envoyé en base de données serveur avec le user courant et le login du coach
function saveMessageCoachUser(result){
	chatCoachUserPagelogincoach = result[0].loginCoach ;
	$("#" + chatCoachUserPage.id+' .chatTeam').html(result[0].nameCoach+'<br>'+result[0].prenomCoach);
	getMessageCoach(chatCoachUserPageloginUser, chatCoachUserPagelogincoach, chatCoachUserPagelogincoach, chatCoachUserPageloginUser);
}


// chargement depuis la base de données serveur des informations sur les messages
function getMessageCoach(param,param1,param2,param3){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getMessageCoach',
			parameters : [param,param1,param2,param]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessGetMessageCoach,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessGetMessageCoach(result){
	WL.Logger.debug("loadFeedsSuccessGetMessageTeam success");
	if ((result) &&(result.invocationResult.resultSet.length>0)) 
		showMessageCoach(result.invocationResult.resultSet) ;
	else 
		WL.Logger.debug("messagerie vide");
}

// afficharge de l'historique des messages entre le user et le coach
function showMessageCoach(result){
	$('.chatMessage').empty();
		for(var i=0;i<result.length;i++){
			var dateTime = result[i].dateMessageCoach;
			dateTime = dateTime.substring(0,dateTime.length-5);
			$('.chatMessage').append('<br>'+result[i].loginMessageCoach +': <li>'+result[i].messageCoach+'</li>'+dateTime+'<br>');
		}
		
	
}
