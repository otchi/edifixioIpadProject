
/* JavaScript content from js/chat/chatTeam.js in folder common */
var chatTeamPageIdteam = null;
$(document).on("pagebeforeshow", "#" + chatTeamPage.id, function(event) {
	//getUserIdTeamValue(function(idTeam){
		//getMessageTeam(idTeam);
	//});
	currentVariable = chatTeamPage.id;
	
	$("#" + chatTeamPage.id+' .chatMessage').empty();
	chatTeamPageIdteam = null;
	getUserNameValue(function(login){
		getChatTeam(login,login);
	});
	
});

$('#'+chatTeamPage.id +' [data-id=chatTeam]').on("click", function(e) {
	chatTeamPageIdteam = null;
	$("#" + chatTeamPage.id+' .chatMessage').empty();
	getUserNameValue(function(login){
		getChatTeam(login,login);
	});
});

$('#'+chatTeamPage.id +' [data-id=send]').on("click", function(e) {
	// $.mobile.changePage("#" + introProfilePage.id);
	var dNow = new Date();
	var localdate=  dNow.getFullYear() + '-' +(dNow.getMonth()+1)  + '-' +dNow.getDate() + ' ' + dNow.getHours() + ':' + dNow.getMinutes() +':'+ dNow.getSeconds();
	getUserNameValue(function(login){
		$('.chatMessage').append('<br>'+login +': <li>'+$('#basic').val()+'</li>'+localdate);
		//$('#chatTeam .chatMessage').animate( { scrollTop: $($('#chatTeam .chatMessage li')[$('#chatTeam .chatMessage li').length-1]).offset().top}, 750 );  
		//ajout du message dans la table message Team
		setMessageTeam(login,$('#basic').val(),localdate,chatTeamPageIdteam);
	});
});

// sauvegarde dans la base de données serveur des informations sur les messages
function setMessageTeam(login,localdate,message,idTeam){
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'setMessageTeam',
			parameters : [login,localdate,message,idTeam]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessMessageTeam,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessMessageTeam(result){
	WL.Logger.debug("loadFeedsSuccessMessageTeam success");
	$('#basic').val("");
}


//recuperer les informations des differents user de la meme equipe que le user courant
function getChatTeam(login,login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getTeam',
			parameters : [login,login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessInformationChatTeam,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessInformationChatTeam(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		showInformationChatTeam(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}

function showInformationChatTeam(result){
	chatTeamPageIdteam = result[0].idTeam;
	$("#" + chatTeamPage.id+' .chatTeam').empty();
	for(var i =0;i<result.length;i++){
		$("#" + chatTeamPage.id+' .chatTeam').append('<br>'+result[i].nom + '<br>'+ result[i].prenom + '<br>');
	}
	getMessageTeam(chatTeamPageIdteam);
	
	
}

// chargement depuis la base de données serveur des informations sur les messages
function getMessageTeam(idTeam){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getMessageTeam',
			parameters : [idTeam]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessGetMessageTeam,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessGetMessageTeam(result){
	WL.Logger.debug("loadFeedsSuccessGetMessageTeam success");
	if ((result) &&(result.invocationResult.resultSet.length>0)) 
		showMessageTeam(result.invocationResult.resultSet) ;
	else 
		WL.Logger.debug("messagerie vide");
}



function showMessageTeam(result){
	var dateTime=null;
	for(var i=0;i<result.length;i++){
		dateTime = result[i].dateMessageTeam;
		dateTime = dateTime.substring(0,dateTime.length-5);
		$('.chatMessage').append('<br>'+result[i].loginMessageTeam +': <li>'+result[i].messageTeam+'</li>'+dateTime+'<br>');
	}
	//$('#chatTeam .chatMessage').animate( { scrollTop: $($('#chatTeam .chatMessage li')[$('#chatTeam .chatMessage li').length-1]).offset().top}, 750 ); 
	getUserNameValue(function(login){
		addInformationsTeam(login, chatTeamPageIdteam, dateTime , function(){
			//getMessageTeam(chatTeamPageIdteam);
			
			var refreshChatTeamMessage = function (){
				getInformationsTeam(function(values){
					if (currentVariable != chatTeamPage.id) clearInterval(timer);
					else getNewMessagesTeam(values[1], values[0]);
				});
			};
			var timer = setInterval(refreshChatTeamMessage, 10000);
			
		});
	});
}

function getNewMessagesTeam(date,idTeam){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getNewMessagesTeam',
			parameters : [date,idTeam]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : getNewMessagesTeamSucces,
		onFailure : loadFeedsFailure
	});
}

function getNewMessagesTeamSucces(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		getNewMessagesTeamTreatment (result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}
function getNewMessagesTeamTreatment(result){
	var dateTime=null;
	console.log(result);
	if(result.length > 1){
		for(var i=0;i<result.length;i++){
			dateTime = result[i].dateMessageTeam;
			dateTime = dateTime.substring(0,dateTime.length-5);
			$('.chatMessage').append('<br>'+result[i].loginMessageTeam +': <li>'+result[i].messageTeam+'</li>'+dateTime+'<br>');
		}
		addInformationsTeam(result[result.length-1].loginMessageTeam, result[result.length-1].chatTeamPageIdteam, dateTime);
		//$('#chatTeam .chatMessage').animate( { scrollTop: $($('#chatTeam .chatMessage li')[$('#chatTeam .chatMessage li').length-1]).offset().top}, 750 ); 
	}
}






