
/* JavaScript content from js/chat/chatCoach.js in folder common */

$(document).on("pagebeforeshow", "#" + chatCoachPage.id, function(event) {
	getUserNameValue(function(login){
		getChatCoachUserActif("idUserActif", function(loginActifId){
			getChatCoachUser(loginActifId, function(loginActif){
				$("#" + chatCoachPage.id +' .chatTeam').html(loginActif[1]+'<br>'+loginActif[2]);
				getMessageCoach(login, loginActif[0], loginActif[0], login);	
			});
		});
	});
});

$('#'+chatCoachPage.id +' [data-id=chatTeam]').on("click", function(e) {
	$('#'+chatCoachPage.id + ' .chatMessage').empty();
	getUserNameValue(function(login){
		getChatCoachUserActif("idUserActif", function(loginActifId){
			getChatCoachUser(loginActifId, function(loginActif){
				$("#" + chatCoachPage.id +' .chatTeam').html(loginActif[1]+'<br>'+loginActif[2]);
				getMessageCoach(login, loginActif[0], loginActif[0], login);	
			});
		});
	});
});

$('#'+chatCoachPage.id +' [data-id=send]').on("click", function(e) {
	// $.mobile.changePage("#" + introProfilePage.id);
	var dNow = new Date();
	var localdate=  dNow.getFullYear() + '-' +(dNow.getMonth()+1)  + '-' +dNow.getDate() + ' ' + dNow.getHours() + ':' + dNow.getMinutes() +':'+ dNow.getSeconds();
	
	getUserNameValue(function(login){
		$('#'+chatCoachPage.id +' .chatMessage').append('<br>'+login +': <li>'+$('#'+chatCoachPage.id +' [data-id=basic]').val()+'</li>'+localdate);
		
		// recuperer le login du user avec le quel le coach va entamer une discussion (local)
		getChatCoachUserActif("idUserActif", function(loginActifId){
			getChatCoachUser(loginActifId, function(loginActif){
				setMessageCoach(login,$('#'+chatCoachPage.id + ' [data-id=basic]').val(),localdate,loginActif[0]);
			});
		});
	});
});

// sauvegarde dans la base de données serveur des informations sur les messages
function setMessageCoach(login,message,localdate,loginActif){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'setMessageCoach',
			parameters : [login,message,localdate,loginActif]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessMessageCoach,
		onFailure : loadFeedsFailureMessageCoach
	});
}

function loadFeedsSuccessMessageCoach(result){
	WL.Logger.debug("loadFeedsSuccessMessageCoach success");
	$('#'+chatCoachPage.id +' [data-id=basic]').val("");
}

function loadFeedsFailureMessageCoach(){
	WL.Logger.error("loadFeedsFailureMessageCoach failure");
}

