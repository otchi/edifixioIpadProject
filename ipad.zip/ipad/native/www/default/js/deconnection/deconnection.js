
/* JavaScript content from js/deconnection/deconnection.js in folder common */

function deconnectSendInfo(callback) {
	var jsonBdd ="";
	var noEmptyTables = new Array();
	getUserNameValue(function(userName){
		getAllTableDeconnect(function(tableArray){
		
		if(tableArray)
		for(var i=0;i<tableArray.length;i++){	
			getQueryTable(tableArray[i],function(query){
				executeQuery(noEmptyTables,i,jsonBdd,tableArray[i],query, function(table,indice,noEmptyTablesTemp){
					jsonBdd = jsonBdd + table ;
					if ((noEmptyTablesTemp)&&(noEmptyTablesTemp.length!=0)) noEmptyTables.push(noEmptyTablesTemp);	
					if((tableArray)&&(indice==tableArray.length-1)){
						jsonBdd=jsonBdd.substring(0, jsonBdd.length-1); 
						jsonBdd ='{'+jsonBdd+'}'; 
						//setJsonClient(jsonBdd);
					
					var contact = JSON.parse(jsonBdd);
					tableNotTmpty(noEmptyTables, "T_ACTIVITIES_STATUS", function(findTable){
				    	if(findTable){
								var contenuTable = contact.T_ACTIVITIES_STATUS;
								var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_ACTIVITIES_STATUS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_ANNOTATIONS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_ANNOTATIONS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_ANNOTATIONS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_BAROMETER", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_BAROMETER;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_BAROMETER",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_BAROMETER_INIT", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_BAROMETER_INIT;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_BAROMETER_INIT",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_ACTIONS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_ACTIONS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_ACTIONS",userName,jsonString,jsonString);	
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_ACTIONS_TEMP", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_ACTIONS_TEMP;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_ACTIONS_TEMP",userName,jsonString,jsonString);	
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_ARRAY_VALUES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_ARRAY_VALUES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_ARRAY_VALUES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_IMPORTANT_CRITERIA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_IMPORTANT_CRITERIA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_IMPORTANT_CRITERIA",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_MARK", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_MARK;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_MARK",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_MYMISSION_ACTIONS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_MYMISSION_ACTIONS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_MYMISSION_ACTIONS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_MYMISSION_MARK", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_MYMISSION_MARK;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_MYMISSION_MARK",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_VALUES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_VALUES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_VALUES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_VISION", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_VISION;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_VISION",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_VISION_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_VISION_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_VISION_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_VISION_MISSION_VERBS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_VISION_MISSION_VERBS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_VISION_MISSION_VERBS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_COMPASS_VISION_TITLE_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_COMPASS_VISION_TITLE_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_COMPASS_VISION_TITLE_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_ATTITUDE_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_ATTITUDE_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_ATTITUDE_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_CHOOSEQUALITY_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_CHOOSEQUALITY_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_CHOOSEQUALITY_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_DEVELOPMENT_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_DEVELOPMENT_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_DEVELOPMENT_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_FIVELEADERS_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_FIVELEADERS_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_FIVELEADERS_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_FIVELEADERS_STATE_LEADER", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_FIVELEADERS_STATE_LEADER;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_FIVELEADERS_STATE_LEADER",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_QUESTIONS_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_QUESTIONS_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_QUESTIONS_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LEADERSHIP_STEREOTYPE_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LEADERSHIP_STEREOTYPE_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LEADERSHIP_STEREOTYPE_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_LOCKED_PAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_LOCKED_PAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_LOCKED_PAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_PROJECTMYSELF_CARDSROUTES_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_PROJECTMYSELF_CARDSROUTES_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_PROJECTMYSELF_CARDSROUTES_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_PROJECTMYSELF_INFIVEYEARS_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_PROJECTMYSELF_INFIVEYEARS_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_PROJECTMYSELF_INFIVEYEARS_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_PROJECTMYSELF_INFIVEYEARS_VERBS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_PROJECTMYSELF_INFIVEYEARS_VERBS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_PROJECTMYSELF_INFIVEYEARS_VERBS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_ISAYI_DATA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_ISAYI_DATA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_ISAYI_DATA",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MORNINGPAGES_DATA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MORNINGPAGES_DATA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MORNINGPAGES_DATA",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MYBELIEFS_ANSWERS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MYBELIEFS_ANSWERS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MYBELIEFS_ANSWERS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MYLITTLEME_DATA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MYLITTLEME_DATA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MYLITTLEME_DATA",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MYLITTLEME_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MYLITTLEME_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MYLITTLEME_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MYLITTLEME_NAMES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MYLITTLEME_NAMES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MYLITTLEME_NAMES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_MYLITTLEME_SENTENCES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_MYLITTLEME_SENTENCES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_MYLITTLEME_SENTENCES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_OTHERVOICES_DESCRIPTIONS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_OTHERVOICES_DESCRIPTIONS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_OTHERVOICES_DESCRIPTIONS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_OTHERVOICES_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_OTHERVOICES_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_OTHERVOICES_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPFOUR_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPFOUR_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPFOUR_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPONE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPONE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPONE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPONE_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPONE_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPONE_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPTWO", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPTWO;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPTWO",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPTWO_KEY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPTWO_KEY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPTWO_KEY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SAYI_PASSION_STEPTWO_PICTURES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SAYI_PASSION_STEPTWO_PICTURES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SAYI_PASSION_STEPTWO_PICTURES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_SEEN_PAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_SEEN_PAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_SEEN_PAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_CHILDHOOD", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_CHILDHOOD;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_CHILDHOOD",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_CHILDHOOD_ANSWERS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_CHILDHOOD_ANSWERS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_CHILDHOOD_ANSWERS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_CHILDHOOD_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_CHILDHOOD_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_CHILDHOOD_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_ENHANCE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_ENHANCE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_ENHANCE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_ENHANCE_DATA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_ENHANCE_DATA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_ENHANCE_DATA",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_ENHANCE_STAGE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_ENHANCE_STAGE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_ENHANCE_STAGE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_PLAY", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_PLAY;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_PLAY",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_RECOGNIZE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_RECOGNIZE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_RECOGNIZE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_I_SPOT", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_I_SPOT;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_I_SPOT",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_MANIFESTE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_MANIFESTE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_MANIFESTE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_MANIFESTE_RESULTS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_MANIFESTE_RESULTS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_MANIFESTE_RESULTS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_OTHER_RECOGNIZE", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_OTHER_RECOGNIZE;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_OTHER_RECOGNIZE",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_OTHER_RECOGNIZE_IMAGES", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_OTHER_RECOGNIZE_IMAGES;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_OTHER_RECOGNIZE_IMAGES",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_TALENTS_OTHER_RECOGNIZE_RESULTS", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_TALENTS_OTHER_RECOGNIZE_RESULTS;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_TALENTS_OTHER_RECOGNIZE_RESULTS",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T__STATUS_PREGRESSION", function(findTable){
						if(findTable){
							    var contenuTable = contact.T__STATUS_PREGRESSION;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T__STATUS_PREGRESSION",userName,jsonString,jsonString);
						 }
					});
					tableNotTmpty(noEmptyTables, "T_USER_DATA", function(findTable){
						if(findTable){
							    var contenuTable = contact.T_USER_DATA;
							    var jsonString = JSON.stringify(contenuTable);
								setJsonClient("T_USER_DATA",userName,jsonString,jsonString);
						 }
					});
				}	
			});
		});	
	  }
	});
		setIPresentUser("yes",userName);
		if (callback && callback != '') {
			callback();
		}
	
	});
}

//mettre present dans la base du serveur a "yes"
function setIPresentUser(login,response){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'setPresentUser',
			parameters : [login,response]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessSet,
		onFailure : loadFeedsFailureSet
	});
}

function loadFeedsSuccessSet(result){
	WL.Logger.debug("load Feeds Success Set present");
}

function loadFeedsFailureSet(jsonBdd){
	WL.Logger.error("Feed retrieve failure Set present");
	
//	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
//			[{
//				text : 'Reload',
//				handler : WL.Client.reloadApp 
//			},
//			{
//				text: 'Close',
//				handler : function() {}
//			}]
//		);
}



