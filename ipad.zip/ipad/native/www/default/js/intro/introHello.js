
/* JavaScript content from js/intro/introHello.js in folder common */

$(document).on("pagebeforeshow", "#" + introHelloPage.id, function(event) {
	
	$( "#" + introHelloPage.id +' #introduction_sponsor_video').load( "pages/intro/introHello_design.html",function(){
		
		translatePage(introHelloPage.id);
		//Add click event on button
		$('#'+introHelloPage.id +' [data-id=next]').on("click", function(e) {
				
		 $.mobile.changePage("#" + introSponsorTextPage.id);
					
		});
		
	});
});



