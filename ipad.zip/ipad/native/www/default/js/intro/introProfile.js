
/* JavaScript content from js/intro/introProfile.js in folder common */
$(document).on("pagebeforeshow", "#" + introProfilePage.id, function(event) {
	// returnInformationProfile recupere les informations sur le profile depuis le serveur
	//$("#" + introProfilePage.id).css('display','none');
	$( "#" + introProfilePage.id +' #introduction_profile').load( "pages/intro/introductionProfile_design.html",function(){
		
		
		
		translatePage(introProfilePage.id);
		returnInformationProfile();
		
		$("#profile-pic").on('change', function(event) {
			changePictureProfile($(this).prop("files")[0]);
		});
		
		$('#'+introProfilePage.id +' [data-id=next]').on("click", function(e) {
			$.mobile.changePage("#" + introTeamPage.id);
		});
		
		$('#'+introProfilePage.id +' [data-id=last]').on("click", function(e) {
			$.mobile.changePage("#" + introCoachsPage.id);
		});
	
		//vérification que tous les textarea sont remplis
		$('#'+ introProfilePage.id+" input").on("keyup", function(e) {
			console.log("test");
			verifInformationsProfileNotNull();
		});
		
	});
	
	
	
});

function returnInformationProfile(){
	getUserNameValue(function(login){
		getInformationProfile(login);
	});
}

function verifInformationsProfileNotNull(){
	
	if(($("#" + introProfilePage.id+' [name=edit-text-1]').val())&&($("#" + introProfilePage.id+' [name=edit-text-1]').val().length>0)&&
		($("#" + introProfilePage.id+' [name=edit-text-2]').val())&&($("#" + introProfilePage.id+' [name=edit-text-2]').val().length>0)&&
				($("#" + introProfilePage.id+' [name=edit-text-3]').val())&&($("#" + introProfilePage.id+' [name=edit-text-3]').val().length>0)&&
						($("#" + introProfilePage.id+' [name=edit-text-4]').val())&&($("#" + introProfilePage.id+' [name=edit-text-4]').val().length>0))
							$($("#" + introProfilePage.id+" [data-id=next] img" ).removeAttr("src")).attr('src','./design/assets/img/block-img/page-6-btn.png');
	else $($("#" + introProfilePage.id+" [data-id=next] img" ).removeAttr("src")).attr('src','./design/assets/img/block-img/suivant-off.png');
		
}

function changePictureProfile(file){
	var fileName = file.name;
	if (file && hasImageExtension(fileName)) {
		console.log("Image upload to add entering");
		console.log("file type = " + file.type);
		encodeToBase64(file, function(base64Value) {
			getUserNameValue(function(login){
			console.log('image added');
			addPhotoProfileInServer(base64Value,login);
		});
		});
	} else {
		console.log('file removed or has not a image extension');
	}
}
// pour modifier la photo de profile du coté serveur
function addPhotoProfileInServer (photoFile,login){
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'addPhotoProfileInServer',
			parameters : [photoFile,login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessAddPhoto,
		onFailure : loadFeedsFailurePhoto
	});
}

function loadFeedsSuccessAddPhoto(){
	WL.Logger.debug("Feed retrieve success");
}

function loadFeedsFailurePhoto(){
	WL.Logger.error("Feed retrieve failure");
}
	
//Pour rapporter toutes les informations du profile qui se trouvent sur le serveur
function getInformationProfile(login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getInformationProfile',
			parameters : [login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessInformationProfile,
		onFailure : loadFeedsFailureInformationProfile
	});
}

function loadFeedsSuccessInformationProfile(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		showInformationProfile(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailureInformationProfile();
}

function loadFeedsFailureInformationProfile(){
	WL.Logger.error("Feed retrieve failure");
	
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}

function showInformationProfile(result){
	var informationProfile = result[0];
	$("#" + introProfilePage.id + " [data-id=fullName]" ).html(informationProfile.nom +' '+informationProfile.prenom);
	$("#" + introProfilePage.id + " [data-id=function]" ).html(informationProfile.fonction);
	$("#" + introProfilePage.id + " [data-id=mail]" ).html(informationProfile.mail);
	$("#" + introProfilePage.id + " [data-id=phoneNumber]" ).html(informationProfile.phoneNumber);
	$("#" + introProfilePage.id+" [data-id=profile-img]").attr('src',informationProfile.image);
	verifInformationsProfileNotNull();
}
