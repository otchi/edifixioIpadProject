
/* JavaScript content from js/intro/introductionSponsorText.js in folder common */

$(document).on("pagebeforeshow", "#" + introHelloPage.id, function(event) {
	
	$( "#" + introSponsorTextPage.id +' #introduction_sponsor_text').load( "pages/intro/introductionSponsorText_design.html",function(){
		
		
		translatePage(introSponsorTextPage.id);
		$('#'+introSponsorTextPage.id +' [data-id=next]').on("click", function(e) {
			
			 $.mobile.changePage("#" + introCoachsPage.id);
						
		});
	});
});

//Add click event on button


