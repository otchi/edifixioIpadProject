
/* JavaScript content from js/intro/introCoachs.js in folder common */

$(document).on("pagebeforeshow", "#" + introCoachsPage.id, function(event) {
	
	$( "#" + introCoachsPage.id +' #introduction_coachs').load( "pages/intro/introductionCoachs_design.html",function(){
		
		$('#'+introCoachsPage.id +' [data-id=next]').on("click", function(e) {
			//alert('hello'); 
			$.mobile.changePage("#" + introProfilePage.id);
			 
		});
		
		translatePage(introCoachsPage.id);
		$('#'+introCoachsPage.id +' [data-id=last]').on("click", function(e) {
			 $.mobile.changePage("#" + introSponsorTextPage.id);					
		});
		
	});
	
//	avoir les informations sur le coach
//	getUserNameValue(function(login){
//		getNameCoachs(login);
//	});

});


function getNameCoachs(login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getNameCoachs',
			parameters : [login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessCoach,
		onFailure : loadFeedsFailureCoach
	});
}

function loadFeedsSuccessCoach(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		showNameCoach(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailureCoach();
}

function loadFeedsFailureCoach(){
	WL.Logger.error("Feed retrieve failure");
	
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}
function showNameCoach(result){
	var resultCoach = result[0];
	$('#intro_coachs_1').html("coach 1 : "+ resultCoach.prenomCoach+"  "+resultCoach.nameCoach);
}
