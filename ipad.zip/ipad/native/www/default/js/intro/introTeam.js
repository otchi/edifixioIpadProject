
/* JavaScript content from js/intro/introTeam.js in folder common */
$(document).on("pagebeforeshow", "#" + introTeamPage.id, function(event) {
	
	
	//$("#" + introTeamPage.id).css('display','none');
	$( "#" + introTeamPage.id +' #introduction_compagnons').load( "pages/intro/introductionCompagnons_design.html",function(){
		
		
		
		translatePage(introTeamPage.id);
		getUserNameValue(function(login){
			getTeam(login,login);
		});
		$('#'+introTeamPage.id +' [data-id=next]').on("click", function(e) {
			$.mobile.changePage("#" + dashBoardPage.id);
		});
		
		$('#'+introTeamPage.id +' [data-id=last]').on("click", function(e) {
			$.mobile.changePage("#" + introProfilePage.id);
		});

	});
});

function getTeam(login,login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getTeam',
			parameters : [login,login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessInformationTeam,
		onFailure : loadFeedsFailureInformationTeam
	});
}

function loadFeedsSuccessInformationTeam(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		showInformationTeam(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailureInformationTeam();
}

function loadFeedsFailureInformationTeam(){
	WL.Logger.error("Feed retrieve failure");
	
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}
function showInformationTeam(result){
	
		for(var i=0;i<result.length;i++){
				
				$('#'+introTeamPage.id +' [data-id=fullName_'+i+']').html(result[i].nom + ' '+ result[i].prenom);
				$('#'+introTeamPage.id +' [data-id=function_'+i+']').html(result[i].fonction);
				$('#'+introTeamPage.id +' [data-id=profile_'+i+'-img]').attr('src',result[i].image);
				//$("#" + introTeamPage.id).css('display','block');
			}
}

//Add click event on button


