
/* JavaScript content from js/myNetwork/myExtendedNetwork.js in folder common */
//
//myInternalNetworkPosition = 0 ;
//$(document).on("pagebeforeshow", "#" + myNetworkMyExtendedNetwork.id, function(event) {
//	
//	getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
//		getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
//			getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
//				$("#" + myNetworkMyExtendedNetwork.id + ' td[data-title=sector1]').html(sector1);
//				$("#" + myNetworkMyExtendedNetwork.id + ' td[data-title=sector2]').html(sector2);
//				$("#" + myNetworkMyExtendedNetwork.id + ' td[data-title=sector3]').html(sector3);
//			});
//		});
//	});
//	
//	myNetwork_myInternalNetwork_getAllResponse("knowledge", function(listeValeurs){
//		$('#'+myNetworkMyInternalNetwork.id + ' .row').html('');
//		for( var i=0 ; i < listeValeurs.length ; i++){
//			$('#'+myNetworkMyExtendedNetwork.id + ' [data-row='+listeValeurs[i][0]+']').append(listeValeurs[i][3]+' '+listeValeurs[i][2]+'<br>');	
//		}
//	}, function(){
//		console.log("there is no knowledge setted yet ");
//	});
//	
//});
//
//$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').on("click", function(e) {
//	myNetwork_setKey("knowledge_Type", $(this).attr('value'));
//});
//
//// add click event on counter validation button
//$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').on("click", function(e) {
//	var value = $('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').val();
//	myNetwork_getKey("knowledge_Type", function(knowledgeType){
//		myNetwork_myInternalNetwork_getKey("knowledge", myNetworkMyExtendedNetwork, function(number){
//			myNetwork_myInternalNetwork_setKnowledge("knowledge", myInternalNetworkPosition, "2", value,knowledgeType, function(){
//				myNetwork_myInternalNetwork_setKey("knowledge",myInternalNetworkPosition,"2",function(){
//					$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_popup').popup("close");
//					$('#'+myNetworkMyExtendedNetwork.id + ' [data-row='+myInternalNetworkPosition+']').append(value);
//				});
//			});
//		}, function(){
//			myNetwork_myInternalNetwork_setKey("knowledge",myInternalNetworkPosition, "1",function(){
//				myNetwork_myInternalNetwork_setKnowledge("knowledge", myInternalNetworkPosition, "1", value,knowledgeType, function(){
//					$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_popup').popup("close");
//					$('#'+myNetworkMyExtendedNetwork.id + ' [data-row='+myInternalNetworkPosition+']').append( value+'</br>');
//				});
//			});
//		});
//	}, null);
//	
//});
//
////add click event on counter validation button
//$( '#'+myNetworkMyExtendedNetwork.id + " button[data-class = validate]").on("click", function(e) {
//	$.mobile.changePage('#' + myNetworkMyExtendedNetwork.id);
//});
//
//$( '#'+myNetworkMyExtendedNetwork.id + " .row").on("click", function(e) {
//	myNetwork_MyInternalNetwork_unCheckRadio();
//	myInternalNetworkPosition = $(this).attr('data-row');
//	myNetwork_myInternalNetwork_getKey("knowledge", myInternalNetworkPosition, function(number){
//		if(number == "1")	$( '#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_add_connaissance').click();
//	}, function(){
//		$( '#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_add_connaissance').click();
//	});
//	$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').val('');
//});
//$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').keyup(function() {
////$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').on("keyup", function(e) {
//	var value = $(this).val().trim();
//	if((value)||(value.length == 0))
//		if(value.length == 0){
//			// disparaitre le bouton
//			$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
//		}
//		else {
//			// appraitre le bouton
//			if($('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').is(':checked')){
//				$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','block');
//			}else{
//				$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
//			}
//		}
//});
//
//
//function myNetwork_MyInternalNetwork_unCheckRadio(){
//	$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').each(function() {
//		$(this).attr('checked', false).checkboxradio("refresh");
//	});
//	$('#'+myNetworkMyExtendedNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
//}
//
//
