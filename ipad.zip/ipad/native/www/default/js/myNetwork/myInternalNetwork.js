
/* JavaScript content from js/myNetwork/myInternalNetwork.js in folder common */
//createNetworkMap();
//$fieldSetNetworkMap = $('#'+myNetworkMyInternalNetwork.id +' select');
//for ( var key in sectorMap) {
//	var valueLabel = getSectorLocalizedLabel(key);
//	var htmlCode = '<option  class ="MyInternalNetworkOption_'+key+'" value="#">'+valueLabel+'</option>';
//	$fieldSetNetworkMap.append(htmlCode);
//}
var myInternalNetworkPosition = 0;
$(document).on("pagebeforeshow", "#" + myNetworkMyInternalNetwork.id, function(event) {
	
	getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
		getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
			getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
				$("#" + myNetworkMyInternalNetwork.id + ' td[data-title=sector1]').html(sector1);
				$("#" + myNetworkMyInternalNetwork.id + ' td[data-title=sector2]').html(sector2);
				$("#" + myNetworkMyInternalNetwork.id + ' td[data-title=sector3]').html(sector3);
			});
		});
	});
	
	myNetwork_myInternalNetwork_getAllResponse("knowledge", function(listeValeurs){
		$('#'+myNetworkMyInternalNetwork.id + ' .row').html('');
		for( var i=0 ; i < listeValeurs.length ; i++){
			$('#'+myNetworkMyInternalNetwork.id + ' [data-row='+listeValeurs[i][0]+']').append(listeValeurs[i][3]+' '+listeValeurs[i][2]+'<br>');	
		}
	}, function(){
		console.log("there is no knowledge setted yet ");
	});
	
});
$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').on("click", function(e) {
	myNetwork_setKey("knowledge_Type", $(this).attr('value'));
});

// add click event on counter validation button
$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').on("click", function(e) {
	var value = $('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').val();
	myNetwork_getKey("knowledge_Type", function(knowledgeType){
		myNetwork_myInternalNetwork_getKey("knowledge", myInternalNetworkPosition, function(number){
			myNetwork_myInternalNetwork_setKnowledge("knowledge", myInternalNetworkPosition, "2", value,knowledgeType, function(){
				myNetwork_myInternalNetwork_setKey("knowledge",myInternalNetworkPosition,"2",function(){
					$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup').popup("close");
					$('#'+myNetworkMyInternalNetwork.id + ' [data-row='+myInternalNetworkPosition+']').append(value);
				});
			});
		}, function(){
			myNetwork_myInternalNetwork_setKey("knowledge",myInternalNetworkPosition, "1",function(){
				myNetwork_myInternalNetwork_setKnowledge("knowledge", myInternalNetworkPosition, "1", value,knowledgeType, function(){
					$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup').popup("close");
					$('#'+myNetworkMyInternalNetwork.id + ' [data-row='+myInternalNetworkPosition+']').append( value+'</br>');
				});
			});
		});
	}, null);
	
});

//add click event on counter validation button
$( '#'+myNetworkMyInternalNetwork.id + " button[data-class = validate]").on("click", function(e) {
	$.mobile.changePage('#' + myNetworkMyExtendedNetwork.id);
});

$( '#'+myNetworkMyInternalNetwork.id + " .row").on("click", function(e) {
	myNetwork_MyInternalNetwork_unCheckRadio();
	myInternalNetworkPosition = $(this).attr('data-row');
	myNetwork_myInternalNetwork_getKey("knowledge", myInternalNetworkPosition, function(number){
		if(number == "1")	$( '#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_add_connaissance').click();
	}, function(){
		$( '#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_add_connaissance').click();
	});
	$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').val('');
});
$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').keyup(function() {
//$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_popup input[type=text]').on("keyup", function(e) {
	var value = $(this).val().trim();
	if((value)||(value.length == 0))
		if(value.length == 0){
			// disparaitre le bouton
			$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
		}
		else {
			// appraitre le bouton
			if($('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').is(':checked')){
				$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','block');
			}else{
				$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
			}
		}
});


function myNetwork_MyInternalNetwork_unCheckRadio(){
	$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_list input[type = radio]').each(function() {
		$(this).attr('checked', false).checkboxradio("refresh");
	});
	$('#'+myNetworkMyInternalNetwork.id + ' #myNetwork_MyInternal_Network_validatePopup').css('display','none');
}


