
/* JavaScript content from js/transverse/overview.js in folder common */
//$("#overview_stage_0").on("click", function(e) {
//	$.mobile.changePage('#' + leadershipSummaryPage.id);
//});
//
//$("#overview_stage_1").on("click", function(e) {
//	$.mobile.changePage('#' + sayISummaryPage.id);
//});
//
//$("#overview_stage_2").on("click", function(e) {
//	$.mobile.changePage('#' + talentsSummaryPage.id);
//});
//
//$("#overview_stage_3").on("click", function(e) {
//	$.mobile.changePage('#' + compassSummaryPage.id);
//});
//
//$("#overview_stage_4").on("click", function(e) {
//	$.mobile.changePage('#' + projectMyselfSummaryPage.id);
//});
//
//$("#overview_stage_5").on("click", function(e) {
//	$.mobile.changePage('#' + visibilitySummary.id);
//});
//
//$("#overview_stage_6").on("click", function(e) {
//	$.mobile.changePage('#' + myNetworkSummary.id);
//});


// on page show
$(document).on("pagebeforeshow", "#" + overviewPage.id, function(event) {

	$( "#" + overviewPage.id +' #main-content').css('display','none');
	$( "#" + overviewPage.id +' #overview_bigStep').load( "pages/transverse/bigStep_design.html",function(){	
		translatePage(overviewPage.id);
		$( "#" + overviewPage.id +' [data-link = back]').attr('href','#'+dashBoardPage.id) ;
	
		$("#" + overviewPage.id + ' [data-select =leadership]').on("click", function(e) {
			get_Status_Progression(PROGRESS_STAPE_1, function(progress){
				console.log('founded PROGRESS_STAPE_1');
				$.mobile.changePage("#" + transitionLeadership.id);	
			},function(){
				console.log('not founded PROGRESS_STAPE_1');
				$.mobile.changePage('#' + leadershipFiveLeadersPage.id);
			});
			
		});
	});
	
	
	
	
//	getAllFinishedActivities(function(activities) {
//		// Stage 1
//		// Stage 2
//		var stage2Percent = 0;
//		if ($.inArray(talentsIEnhancePage.id, activities) != -1) {
//			stage2Percent = 100;
//			console.log('overview: talents stage 2 : 100% finished');
//		} else if ($.inArray(talentsIPlayPage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 6;
//			console.log('overview: talents stage 2 : 6 screens done');
//		} else if ($.inArray(talentsISpotPage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 5;
//			console.log('overview: talents stage 2 : 5 screens done');
//		} else if ($.inArray(talentsOtherRecognizePage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 4;
//			console.log('overview: talents stage 2 : 4 screens done');
//		} else if ($.inArray(talentsManifestePage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 3;
//			console.log('overview: talents stage 2 : 3 screens done');
//		} else if ($.inArray(talentsChildhoodPage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 2;
//			console.log('overview: talents stage 2 : 2 screens done');
//		} else if ($.inArray(talentsIRecognizePage.id, activities) != -1) {
//			stage2Percent = (100 / 7) * 1;
//			console.log('overview: talents stage 2 : 1 screens done');
//		} else {
//			stage2Percent = 0;
//			console.log('overview: talents stage 2 : 0 screens done');
//		}
//		stage2Percent = Math.round(stage2Percent);
//		$('#overview_percent_2').html(stage2Percent + '% ' + $.i18n.prop('overview.completed.label') + '<br/>');
//		$('#overview_percent_2').append('<input id="overview_slider_2" data-highlight="true" min="0" max="100" value="' + stage2Percent + '" type="range" disabled="disabled">');
//	});
//	get_Status_Progression("leadership_progression", function(value){
//		$('#'+overviewPage.id+' .overview_progression_0').html(value+'%');
//	}, null);
//	get_Status_Progression("sayI", function(value){
//		$('#'+overviewPage.id+' .overview_progression_1').html(value+'%');
//	}, null);
//	get_Status_Progression("talent", function(value){
//		$('#'+overviewPage.id+' .overview_progression_2').html(value+'%');
//	}, null);
});