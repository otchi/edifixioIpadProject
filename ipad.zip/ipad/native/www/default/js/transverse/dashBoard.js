
/* JavaScript content from js/transverse/dashBoard.js in folder common */
// on page show
var currentVariable = dashBoardPage.id;
$(document).on("pagebeforeshow", "#" + dashBoardPage.id, function(event) {
	
	$( "#" + dashBoardPage.id +' #dashBoardPage_page').load( "pages/transverse/dashboard_design.html",function(){
		//translatePage(dashBoardPage.id);
		$('#dashBoardPage_page').css('display','none');
	
		
		$("#" + dashBoardPage.id + ' .right-button').on("click", function(e) {
//			//$('#percentage-value-2').html('28');	
//			$(".knob-2").data("value","5");
//			$(".knob").data("value","5");
//			$(".knob-2").attr('data-value','28');
//			
//			$('.knob-2').val(100).trigger('change');
//			$('.knob').val(100).trigger('change');
			$.mobile.changePage('#' + overviewPage.id);
		
			
		});
		
	setTimeout(function(){
		addpourcentage();
			$(".knob").data("value","5");
			$(".knob-2").data("value","5");
			$(".knob-2").attr('data-value','5');
			$('.knob-2').val(5).trigger('change');
			$('.knob').val(5).trigger('change');
		}, 250);
		$('#dashBoardPage_page').css('display','block');
	
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	currentVariable = dashBoardPage.id;
//	getAccessibleOrInProgressActivity(function(activityId) {
//		console.log('dashboard :: activityId = ' + activityId);
//		if (activityId && activityId != null && !isBlank(activityId)) {
//			console.log('dashboard :: a activity is in progress or accessible');
//			$('#dashboard_work_in_progress').html($.i18n.prop(activityId + '.title'));
//			$('#dashboard_see_again_execices').show();
//		} else {
//			console.log('dashboard :: nothing done');
//			$('#dashboard_work_in_progress').html($.i18n.prop('dashboard.start'));
//			$('#dashboard_see_again_execices').hide();
//		}
//	});
});

$('#'+ dashBoardPage.id+' #dashboard_work_in_progress').on("click", function(e) {
	
	getAccessibleOrInProgressActivity(function(activityId) {
		if (activityId && activityId != null && !isBlank(activityId)) {
			$.mobile.changePage("#"+activityId);
		} else {
			$.mobile.changePage("#"+overviewPage.id);
		}
	});
	
});

$('#'+ dashBoardPage.id+' #dashboard_see_again_execices').on("click", function(e) {
	$.mobile.changePage("#"+overviewPage.id);
});

$('#'+ dashBoardPage.id+' [data-id=chatTeam]').on("click", function(e) {
	$.mobile.changePage("#"+chatTeamPage.id);
});

$("#" + dashBoardPage.id + "_deconnectLink").on("click", function(e) {
	
//	if (returnTypeConnection()=="No network connection") alert('veuillez vous connectez a internet');
//	else {
		getUserNameValue(function(login){
			 setStatUser('no',login);
		});
//	}
//	dashBoardPageDeconnect();
});


$("#" + dashBoardPage.id + "_deleteBDD").on("click", function(e) {

	clearTables(0, function() {
		console.log('all tables cleared');
		$.mobile.changePage('#' + leadershipFiveLeadersPage.id);
	});
	
});



function dashBoardPageDeconnect(){
	
	deconnectSendInfo(function(){
		setGetConnection("no", function(){
			clearTables(0, function() {
				console.log('all tables cleared');
				console.log('deconnection reussie');
				$.mobile.changePage('#' + authentication.id);	
			});
	    });
    });
	
}

function setStatUser(param,param1){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'statUserConnection',
			parameters : [param,param1]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessConnect,
		onFailure : loadFeedsFailureConnect
	});
}

function loadFeedsSuccessConnect(result){
	WL.Logger.debug("Feed retrieve success");
	dashBoardPageDeconnect();
}

function loadFeedsFailureConnect(jsonBdd){
	WL.Logger.error("Feed retrieve failure");
	$("#" + dashBoardPage.id + "_deconnectLink").click();
}

