
/* JavaScript content from js/barometer/barometerInit.js in folder common */
$(document).on("pagebeforeshow", "#" + barometerInitPage.id, function(event) {
	getBarometerInitValues(function(values) {

		for (var i = 0; i < values.length; i++) {
			var criteria = values[i];
			$checkBox = $("#" + barometerInitPage.id + " input[name = 'barometer_init_criteria" + criteria.number + "'][value='" + criteria.value + "']");
			$checkBox.attr('checked', true);
			$checkBox.checkboxradio("refresh");
		}

		if (values.length == 5) {
			toggleEnabling('#validInitBarometer', false);
		} else {
			toggleEnabling('#validInitBarometer', true);
		}
	});
});

$("#" + barometerInitPage.id + " input[name^='barometer_init_criteria']").on("click", function(e) {
	var criteriaNumber = $(this).attr("data-criteria");
	var criteriaValue = $(this).attr("value");

	// Set barometerinit in progress
	setActivityStatus(barometerInitPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log("barometerInit is now in progress");
	});

	addBarometerInitValue(parseInt(criteriaNumber), parseInt(criteriaValue), function() {
		console.log("criteria save");

		var number = $("input[name^='barometer_init_criteria']:checked").length;
		if (number == 5) {
			toggleEnabling('#validInitBarometer', false);
		} else {
			toggleEnabling('#validInitBarometer', true);
		}
	});
});

$("#validInitBarometer").on("click", function(e) {
	// Set barometerinit to finished
	setActivityStatus(barometerInitPage.id, SCREEN_STATUS_FINISHED, function() {
		console.log("barometerInit is now finished");

		setActivityStatus(sayIiSayIPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
			console.log("i say i is now accessible");

			$.mobile.changePage("#" + dashBoardPage.id);
		});
	});
});
