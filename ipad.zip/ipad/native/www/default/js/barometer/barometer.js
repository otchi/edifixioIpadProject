
/* JavaScript content from js/barometer/barometer.js in folder common */
$("#barometer_backLink").on("click", function(e) {
	history.back();
});

$("#globalDateDivId" + i).hide();
for (var i = 0; i < 5; i++) {
	$("#dateDivId_" + i).hide();
}

$(document).on("pagebeforeshow", "#" + barometerPage.id, function(event) {

	getBarometerInitValues(function(values) {
		for (var i = 0; i < values.length; i++) {
			var criteria = values[i];
			$("#initValue" + criteria.number).html(criteria.value);
		}
	});

	getBarometerValues(function(values) {
		var lastUpdateDate = null;

		for (var i = 0; i < values.length; i++) {
			var criteria = values[i];
			$checkBox = $("#" + barometerPage.id + " input[name = 'barometer_criteria" + criteria.number + "'][value='" + criteria.value + "']");
			$checkBox.attr('checked', true);
			$checkBox.checkboxradio("refresh");

			$("#dateDivId_" + criteria.number).show();
			$("#dateId_" + criteria.number).html(criteria.updateDate.toLocaleString());

			if (lastUpdateDate == null) {
				lastUpdateDate = criteria.updateDate;
			} else if (criteria.updateDate > lastUpdateDate) {
				lastUpdateDate = criteria.updateDate;
			}
		}

		if (lastUpdateDate != null) {
			$("#globalDateId").html(lastUpdateDate.toLocaleString());
		} else {
			console.log('date is null');
			$("#globalDateDivId").hide();
		}
	});
});

$("#" + barometerPage.id + " input[id ^='barometer_criteria']").on("click", function(e) {
	var criteriaNumber = $(this).attr("data-criteria");
	var criteriaValue = $(this).attr("value");

	addBarometerValue(criteriaNumber, criteriaValue, function() {
		console.log("criteria save");
	});
});
