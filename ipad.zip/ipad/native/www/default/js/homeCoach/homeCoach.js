
/* JavaScript content from js/homeCoach/homeCoach.js in folder common */
$(document).on("pagebeforeshow", "#" + homeCoachPage.id, function(event) {
	$("#" + homeCoachPage.id + ' [data-comment=coach]').css('display','none');
	getUserNameValue(function(login){
		getUserCoachs(login);
	});
});

$('#'+homeCoachPage.id +' a').on("click", function(e) {
	console.log($(this).attr('data-number'));
	setChatCoachUserActif("idUserActif",$(this).attr('data-number'), function(){
		//getChatCoachUserActif("idUserActif", function(ee){
		//	getChatCoachUser(ee, function(eee){
		//		console.log(eee);
		//	});
		//});
		$.mobile.changePage('#' + chatCoachPage.id);
	});
});

function getUserCoachs(login){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'getUserCoachs',
			parameters : [login]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessUserCoachs,
		onFailure : loadFeedsFailure
	});
}

function loadFeedsSuccessUserCoachs(result){
	WL.Logger.debug("Feed retrieve success");
	if (result.invocationResult.resultSet.length>0) 
		showUserChatCoach(result.invocationResult.resultSet) ;
	else 
		loadFeedsFailure();
}
function showUserChatCoach(result){
	for(var i=0;i<result.length;i++){
		$("#" + homeCoachPage.id + ' [data-id=chatUser_'+i+']').css('display','block');
		var image = document.createElement("img");
		image.setAttribute("src", result[i].image);
		$('#homeCoachUser_'+i).empty();
		document.getElementById('homeCoachUser_'+i).appendChild(image);
		$('.userName_'+i).html(result[i].nom);
		$('.userFirstName_'+i).html(result[i].prenom);
		$("#" + homeCoachPage.id+" img").css("height","110px");
		setChatCoachUser(i,result[i].login, result[i].nom, result[i].prenom);		
	}
}