
/* JavaScript content from js/pages.js in folder common */


// Build page hierarchy
const PROGRESS_STAPE_1="leadership_stape1_progress";
function Page(id, path, hasHelpText, hasEditoText, canAnnotate, displayToolBox, backPageId,calendar,StepPage) {
	this.id = id;
	this.path = path;
	this.hasHelpText = hasHelpText;
	this.hasEditoText = hasEditoText;
	this.canAnnotate = canAnnotate;
	this.displayToolBox = displayToolBox;
	this.backPageId = backPageId;
	this.calendar = calendar ;
	this.StepPage= StepPage;
};



var pageMap = {};

var authentication = new Page("authentication", "pages/authentication/authentication.html", false, false, false, false,null,false,false);
pageMap[authentication.id] = authentication;

var dashBoardPage = new Page("dashboard", "pages/transverse/dashBoard.html", true, true, true, true, null,false,false);
pageMap[dashBoardPage.id] = dashBoardPage;

var homeCoachPage = new Page("homeCoach", "pages/homeCoach/homeCoach.html", false, false, false, false,null,false,false);
pageMap[homeCoachPage.id] = homeCoachPage;

var introHelloPage = new Page("introHello", "pages/intro/introHello.html", false, false, false, false, null,false,false);
pageMap[introHelloPage.id] = introHelloPage;

var introSponsorTextPage = new Page("introSponsorTextPage", "pages/intro/introductionSponsorText.html", false, false, false, false, null,false,false);
pageMap[introSponsorTextPage.id] = introSponsorTextPage;

var introCoachsPage = new Page("introCoachs", "pages/intro/introCoachs.html", false, false, false, false, null,false,false);
pageMap[introCoachsPage.id] = introCoachsPage;

var introProfilePage = new Page("introProfile", "pages/intro/introProfile.html", false, false, false, false,dashBoardPage.id,false,false);
pageMap[introProfilePage.id] = introProfilePage;

var introTeamPage = new Page("introTeam", "pages/intro/introTeam.html", false, false, false, false,null,false,false);
pageMap[introTeamPage.id] = introTeamPage;

var chatCoachUserPage = new Page("chatCoachUser", "pages/chat/chatCoachUser.html", false, false, false, false,dashBoardPage.id,false,false);
pageMap[chatCoachUserPage.id] = chatCoachUserPage;

var chatTeamPage = new Page("chatTeam", "pages/chat/chatTeam.html", false, false, false, false,dashBoardPage.id,false,false);
pageMap[chatTeamPage.id] = chatTeamPage;

var chatCoachPage = new Page("chatCoach", "pages/chat/chatCoach.html", false, false, false, false, homeCoachPage.id,false,false);
pageMap[chatCoachPage.id] = chatCoachPage;

var home1Page = new Page("home1", "pages/home/home1.html", false, false, false, false, null,false,false);
pageMap[home1Page.id] = home1Page;

var home2Page = new Page("home2", "pages/home/home2.html", false, false, false, false, null,false,false);
pageMap[home2Page.id] = home2Page;

var barometerInitPage = new Page("barometerInit", "pages/barometer/barometerInit.html", true, true, true, false, null, false,false);
pageMap[barometerInitPage.id] = barometerInitPage;

var barometerPage = new Page("barometer", "pages/barometer/barometer.html", true, true, true, false, null, false,false);
pageMap[barometerPage.id] = barometerPage;

var overviewPage = new Page("overview", "pages/transverse/overview.html", true, true, true, true, dashBoardPage.id, false,false);
pageMap[overviewPage.id] = overviewPage;

var transitionLeadership = new Page("transitionLeadership", "pages/leadership/transitionLeadership.html", true, true, true, true, overviewPage.id,false,false);
pageMap[transitionLeadership.id] = transitionLeadership;

//var leaderchipvp= new Page("", path, hasHelpText, hasEditoText, canAnnotate, displayToolBox, backPageId, calendar, StepPage);
var leadershipFiveLeadersPage = new Page("leadership_fiveLeader", "pages/leadership/fiveLeaders.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipFiveLeadersPage.id] = leadershipFiveLeadersPage;

var leadershipFiveLeadersChoosePage = new Page("leadership_fiveLeaderChoose", "pages/leadership/fiveLeadersChoose.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipFiveLeadersChoosePage.id] = leadershipFiveLeadersChoosePage;

var leadershipDevelopmentPage = new Page("leadership_development", "pages/leadership/development.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipDevelopmentPage.id] = leadershipDevelopmentPage;

var leadershipQuestionsInYourHistoryIntroduction = new Page("leadershipQuestionsInYourHistoryIntroduction", "pages/leadership/leadershipQuestionsInYourHistoryIntroduction.html", true, true, true, true,  transitionLeadership.id,false,false);
pageMap[leadershipQuestionsInYourHistoryIntroduction.id] = leadershipQuestionsInYourHistoryIntroduction;

var leadershipQuestionsInYourHistory = new Page("leadershipQuestionsInYourHistory", "pages/leadership/leadershipQuestionsInYourHistory.html", true, true, true, true,  transitionLeadership.id,false,false);
pageMap[leadershipQuestionsInYourHistory.id] = leadershipQuestionsInYourHistory;

var leadershipStereotypePage = new Page("leadership_stereotype", "pages/leadership/stereotype.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipStereotypePage.id] = leadershipStereotypePage;

var leadershipStereotypeConclusionPage = new Page("leadership_stereotype_conclusion", "pages/leadership/stereotypeConclusion.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipStereotypeConclusionPage.id] = leadershipStereotypeConclusionPage;

var leadershipMoiEtLe = new Page("leadership_moi_et_le", "pages/leadership/moiEtLe.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipMoiEtLe.id] = leadershipMoiEtLe;

var les5AttitudesLeaderIntro= new Page("les_5_attitude_intro", "pages/leadership/les5AttitudesLeaderIntro.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[les5AttitudesLeaderIntro.id] = les5AttitudesLeaderIntro;

var les5AttitudesLeader= new Page("les_5_attitude", "pages/leadership/les5AttitudesLeader.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[les5AttitudesLeader.id] = les5AttitudesLeader;


var leadershipfeelingPage = new Page("leadership_feeling", "pages/leadership/feeling.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipfeelingPage.id] = leadershipfeelingPage;

var leadershipAttitudePage = new Page("leadership_attitude", "pages/leadership/attitude.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipAttitudePage.id] = leadershipAttitudePage;

var leadershipMarkAttitudePage = new Page("leadership_markAttitude", "pages/leadership/markAttitude.html", true, true, true, true, transitionLeadership.id,false,false);
pageMap[leadershipMarkAttitudePage.id] = leadershipMarkAttitudePage;

var talentsSummaryPage = new Page("talents_summary", "pages/talents/summary.html", true, true, true, true, overviewPage.id,false,false);
pageMap[talentsSummaryPage.id] = talentsSummaryPage;

var talentsIRecognizePage = new Page("talents_irecognize", "pages/talents/iRecognize.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsIRecognizePage.id] = talentsIRecognizePage;

var talentsChildhoodPage = new Page("talents_childhood", "pages/talents/childhood.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsChildhoodPage.id] = talentsChildhoodPage;

var talentsManifestePage = new Page("talents_manifeste", "pages/talents/manifeste.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsManifestePage.id] = talentsManifestePage;

var talentsOtherRecognizePage = new Page("talents_otherrecognize", "pages/talents/otherRecognize.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsOtherRecognizePage.id] = talentsOtherRecognizePage;

var talentsISpotPage = new Page("talents_ispot", "pages/talents/iSpot.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsISpotPage.id] = talentsISpotPage;

var talentsIPlayPage = new Page("talents_iplay", "pages/talents/iPlay.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsIPlayPage.id] = talentsIPlayPage;

var talentsIEnhancePage = new Page("talents_ienhance", "pages/talents/iEnhance.html", true, true, true, true, talentsSummaryPage.id, true,false);
pageMap[talentsIEnhancePage.id] = talentsIEnhancePage;

var sayISummaryPage = new Page("sayI_summary", "pages/sayI/summary.html", true, true, true, true, overviewPage.id,false,false);
pageMap[sayISummaryPage.id] = sayISummaryPage;

var sayIiSayIPage = new Page("sayI_iSayI", "pages/sayI/iSayI.html", true, true, true, true, sayISummaryPage.id, true, false);
pageMap[sayIiSayIPage.id] = sayIiSayIPage;

var sayImorningPagesPage = new Page("sayI_morningPages", "pages/sayI/morningPages.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayImorningPagesPage.id] = sayImorningPagesPage;

var sayImyLittleMePage = new Page("sayI_myLittleMe", "pages/sayI/myLittleMe.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayImyLittleMePage.id] = sayImyLittleMePage;

var sayIiListenMyLittleMe = new Page("sayI_iListenMyLittleMe", "pages/sayI/iListenMyLittleMe.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIiListenMyLittleMe.id] = sayIiListenMyLittleMe;

var sayImyBeliefsPage = new Page("sayI_myBeliefs", "pages/sayI/myBeliefs.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayImyBeliefsPage.id] = sayImyBeliefsPage;

var sayIotherVoicesPage = new Page("sayI_otherVoices", "pages/sayI/otherVoices.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIotherVoicesPage.id] = sayIotherVoicesPage;

var sayIpassionsPage = new Page("sayI_passions_stepOne", "pages/sayI/passions.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIpassionsPage.id] = sayIpassionsPage;

var sayIpassionsStepTwoPage = new Page("sayI_passions_stepTwo", "pages/sayI/passionsStepTwo.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIpassionsStepTwoPage.id] = sayIpassionsStepTwoPage;

var sayIpassionsStepThreePage = new Page("sayI_passions_stepThree", "pages/sayI/passionsStepThree.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIpassionsStepThreePage.id] = sayIpassionsStepThreePage;

var sayIpassionsStepFourPage = new Page("sayI_passions_stepFour", "pages/sayI/passionsStepFour.html", true, true, true, true, sayISummaryPage.id, true,false);
pageMap[sayIpassionsStepFourPage.id] = sayIpassionsStepFourPage;

var compassSummaryPage = new Page("compass_SummaryPage", "pages/compass/summary.html", true, true, true, true, overviewPage.id,false,false);
pageMap[compassSummaryPage.id] = compassSummaryPage;

var compassMyValuesPage =  new Page("compass_values", "pages/compass/myValues.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyValuesPage.id] = compassMyValuesPage;

var compassMyValuesProLifePage = new Page("compass_valuesProLife", "pages/compass/myValuesProLife.html", true, true, true, true, compassSummaryPage.id, true,true);
pageMap[compassMyValuesProLifePage.id] = compassMyValuesProLifePage;

var compassMyValuesProLifeActionPage = new Page("compass_valuesProLifeAction", "pages/compass/myValuesProLifeActionPage.html", true, true, true, true, compassSummaryPage.id, true, true);
pageMap[compassMyValuesProLifeActionPage.id] = compassMyValuesProLifeActionPage;

var compassMyValuesProLifeActionDescriptionPage = new Page("compass_valuesProLifeActionDescription", "pages/compass/myValuesProLifeActionDescription.html", true, true, true, true, compassSummaryPage.id, true, true);
pageMap[compassMyValuesProLifeActionDescriptionPage.id] = compassMyValuesProLifeActionDescriptionPage;

var compassMyValuesProLifeActionResultPage = new Page("compass_valuesProLifeActionResult", "pages/compass/myValuesProLifeActionResult.html", true, true, true, true, compassSummaryPage.id, true,true);
pageMap[compassMyValuesProLifeActionResultPage.id] = compassMyValuesProLifeActionResultPage;

var compassMyVisionPage = new Page("compass_MyVisionPage", "pages/compass/myVision.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyVisionPage.id] = compassMyVisionPage;

var compassMyVisionPicturesPage = new Page("compass_MyVisionPicturesPage", "pages/compass/myVisionPictures.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyVisionPicturesPage.id] = compassMyVisionPicturesPage;

var compassMyVisionMyMissionPage = new Page("compass_MyVisionMyMissionPage", "pages/compass/myVisionMyMission.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyVisionMyMissionPage.id] = compassMyVisionMyMissionPage;

var compassmyVisionVerbsPage = new Page("compass_myVisionVerbsPage", "pages/compass/myVisionVerbs.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassmyVisionVerbsPage.id] = compassmyVisionVerbsPage;

var compassmyVisionMyMissionDescriptionPage = new Page("compass_myVisionMyMissionDescriptionPage", "pages/compass/myVisionMyMissionDescription.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassmyVisionMyMissionDescriptionPage.id] = compassmyVisionMyMissionDescriptionPage;

var compassMyMissionProLife = new Page("compass_MyMissionProLife", "pages/compass/MyMissionProLife.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyMissionProLife.id] = compassMyMissionProLife;

var compassMyMissionProLifeAction = new Page("compass_MyMissionProLifeAction", "pages/compass/MyMissionProLifeAction.html", true, true, true, true, compassSummaryPage.id, true, false);
pageMap[compassMyMissionProLifeAction.id] = compassMyMissionProLifeAction;

var compassMyMissionProLifeActionDescription = new Page("compass_MyMissionProLifeActionDescription", "pages/compass/MyMissionProLifeActionDescription.html", true, true, true, true, compassMyMissionProLifeAction.id, true, false);
pageMap[compassMyMissionProLifeActionDescription.id] = compassMyMissionProLifeActionDescription;

var compassMyMissionProLifeActionResult = new Page("compass_MyMissionProLifeActionResult", "pages/compass/MyMissionProLifeActionResult.html", true, true, true, true, compassMyMissionProLifeActionDescription.id, true, false);
pageMap[compassMyMissionProLifeActionResult.id] = compassMyMissionProLifeActionResult;

var compassMyMissionProLifeActionBoussole = new Page("compass_MyMissionProLifeActionBoussole", "pages/compass/compass.html", true, true, true, true, compassMyMissionProLifeActionResult.id, true, false);
pageMap[compassMyMissionProLifeActionBoussole.id] = compassMyMissionProLifeActionBoussole;

var projectMyselfSummaryPage = new Page("projectMyself_SummaryPage", "pages/projectMyself/summary.html", true, true, true, true, overviewPage.id,false,false);
pageMap[projectMyselfSummaryPage.id] = projectMyselfSummaryPage;

var projectMyselfGetTheFactsPage = new Page("projectMysel_GetTheFactsPage", "pages/projectMyself/GetTheFacts.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfGetTheFactsPage.id] = projectMyselfGetTheFactsPage;

var projectMyselfInFiveYearsPage = new Page("projectMysel_InFiveYearsPage", "pages/projectMyself/inFiveYears.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfInFiveYearsPage.id] = projectMyselfInFiveYearsPage;

var projectMyselfInFiveYears2Page = new Page("projectMysel_InFiveYearsPage2", "pages/projectMyself/inFiveYears2.html", true, true, true, true, projectMyselfInFiveYearsPage.id, false,false);
pageMap[projectMyselfInFiveYears2Page.id] = projectMyselfInFiveYears2Page;

var projectMyselfMyCardRoutesPage = new Page("projectMysel_MyCardRoutesPage", "pages/projectMyself/CardRoutesPage_step1.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfMyCardRoutesPage.id] = projectMyselfMyCardRoutesPage;

var GoodDirection = new Page("GoodDirection", "pages/projectMyself/GoodDirection.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[GoodDirection.id] = GoodDirection;

var projectMyselfMyCardRoutesPage2 = new Page("projectMysel_MyCardRoutesPage_2", "pages/projectMyself/CardRoutesPage_step2.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfMyCardRoutesPage2.id] = projectMyselfMyCardRoutesPage2;

var projectMyselfFisrtStep = new Page("projectMyself_FisrtStep", "pages/projectMyself/fisrtStep.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfFisrtStep.id] = projectMyselfFisrtStep;

var projectMyselfFisrtStepAction = new Page("projectMyself_FisrtStepAction", "pages/projectMyself/fisrtStepAction.html", true, true, true, true, projectMyselfSummaryPage.id, false,false);
pageMap[projectMyselfFisrtStepAction.id] = projectMyselfFisrtStepAction;

var visibilitySummary = new Page("visibility_Summary", "pages/visibility/summary.html", true, true, true, true, overviewPage.id, false,false);
pageMap[visibilitySummary.id] = visibilitySummary;

var visibilityTellYou = new Page("visibility_tellYou", "pages/visibility/tellYou.html", true, true, true, true, visibilitySummary.id, false,false);
pageMap[visibilityTellYou.id] = visibilityTellYou;

var visibilityTellWhatYouOffer = new Page("visibility_tellWhatYouOffer", "pages/visibility/tellWhatYouOffer.html", true, true, true, true, visibilitySummary.id, false,false);
pageMap[visibilityTellWhatYouOffer.id] = visibilityTellWhatYouOffer;

var  myNetworkSummary = new Page("myNetwork_Summary", "pages/myNetwork/summary.html", true, true, true, true, overviewPage.id, false,false);
pageMap[myNetworkSummary.id] = myNetworkSummary;

var myNetworkMyInternalNetwork = new Page("myNetwork_MyInternalNetwork", "pages/myNetwork/myInternalNetwork.html", true, true, true, true, myNetworkSummary.id, false,false);
pageMap[myNetworkMyInternalNetwork.id] = myNetworkMyInternalNetwork;

var myNetworkMyExtendedNetwork = new Page("myNetwork_myExtendedNetwork", "pages/myNetwork/myExtendedNetwork.html", true, true, true, true, myNetworkSummary.id, false,false);
pageMap[myNetworkMyExtendedNetwork.id] = myNetworkMyExtendedNetwork;


var calendarPage = new Page("calendarPage", "pages/calendar/calendar.html", true, true, true, true, dashBoardPage.id, false,false);
pageMap[calendarPage.id] = calendarPage;



function createPage(pages, index, callback) {
	console.log("createPage entering with index = " + index + " and pages.length = " + pages.length);
	if (index < pages.length) {
		var page = pages[index];

		console.log("createPage :: page id = " + page.id);
		console.log("createPage :: page path = " + page.path);

//		var pageDiv = document.createElement("div");
//		pageDiv.setAttribute("data-role", "page");
//		pageDiv.setAttribute("id", page.id);
		
//		var headerDiv = document.createElement("div");
//		headerDiv.setAttribute("data-role", "header");
//		headerDiv.innerHTML = '<h1 data-type="bundle" data-key="' + page.id + '.title"></h1>';
//		pageDiv.appendChild(headerDiv);
		if(true){
			var pageDiv = document.createElement("div");
			pageDiv.setAttribute("data-role", "page");
			pageDiv.setAttribute("id", page.id);
			//pageDiv.innerHTML="<div class=\"col-md-2 col-sm-2\" id=\"left_header\"></div><div class=\"col-md-8 col-sm-8 text-center\" id=\"center_header\"></div><div class=\"col-md-2 col-sm-2\" id=\"right_header\"></div>";
			
			var headerDivMain = document.createElement("div");
			headerDivMain.setAttribute("id", "main-content");
			
			var headerDiv1 = document.createElement("div");
			headerDiv1.setAttribute("class", "navbar navbar-inverse nav-page-2");
			headerDiv1.setAttribute("role", "navigation");
			
			var headerDiv2 = document.createElement("div");
			headerDiv2.setAttribute("class", "container-fluid");
			
			var headerDiv4 = document.createElement("div");
			headerDiv4.setAttribute("class", "row-fluid");
			
			var headerDiv3 = document.createElement("div");
			headerDiv3.setAttribute("class", "head-row");
			
			var headerText = document.createElement("div");
			headerText.setAttribute("class", "row-fluid");
			
			var headerLeft = document.createElement("div");
			headerLeft.setAttribute("class", "col-md-2 col-sm-2");
			headerDiv3.appendChild(headerLeft);
			
			var headerCenter = document.createElement("div");
			headerCenter.setAttribute("class", "col-md-8 col-sm-8 text-center");
			headerCenter.innerHTML = '<div class="nav-heading"><h2 class="leadership"><span data-type="bundle" data-key="' + page.id + '.title"></span></h2><hr class="nav-hr"><p><span data-type="bundle" data-key="' + page.id + '.title.number"></span></p></div>';
			headerDiv3.appendChild(headerCenter);
			
			var headerRight = document.createElement("div");
			headerRight.setAttribute("class", "col-md-2 col-sm-2");
			// si la page accepte la direction mon coach,                                                                                
			headerRight.innerHTML = '<div class="pull-right"><a class="mon-coach-anchor" href="#"><img class="mon-coach-img" src="design/assets/img/block-img/coach-2.png"></a></div>';
			headerDiv3.appendChild(headerRight);
			
			var headerText1 = document.createElement("div");
			headerText1.setAttribute("class", "nav-sub-parent-div");
			
			var headerText2 = document.createElement("div");
			headerText2.setAttribute("class", "col-md-8 col-sm-8");
			
			// condition si la page a une description 
			if(page.backPageId){
				headerText2.innerHTML = '<div class="pull-left"><div class="nav-sub-text"><h2 class="nav-sub-h2"><span data-type="bundle" data-key="' + page.id + '.title.description"></h2><p><span data-type="bundle" data-key="' + page.id + '.description"></p></div></div>';
			}
				
			var headerText3 = document.createElement("div");
			headerText3.setAttribute("class", "col-md-4 col-sm-4");
			
			var headerText4 = document.createElement("div");
			headerText4.setAttribute("class", "pull-right nav-icons");
			
			headerText.appendChild(headerText1);
			headerText1.appendChild(headerText2);
			headerText1.appendChild(headerText3);
			headerText3.appendChild(headerText4);
			headerDiv4.appendChild(headerDiv3);
			headerDiv2.appendChild(headerDiv4);
			headerDiv2.appendChild(headerText);
			headerDiv1.appendChild(headerDiv2);
			//headerDivMain.appendChild(headerDiv1);
			pageDiv.appendChild(headerDivMain);
			
		}
			
			if (page.hasEditoText) {
				
				var infoLink = document.createElement("a");
				infoLink.setAttribute("href", "#");
				infoLink.setAttribute("class", "info-img");
				infoLink.innerHTML = '<img class="info-img" src="design/assets/img/block-img/info.png">';
				
				var bookLink = document.createElement("a");
				bookLink.setAttribute("href", "#");
				bookLink.setAttribute("class", "book-img");
				bookLink.innerHTML = '<img class="book-img" src="design/assets/img/block-img/book.png">';
				
				headerText4.appendChild(infoLink);
				headerText4.appendChild(bookLink);
				
				var editoTextMessage = $.i18n.prop(page.id + EDITO_TEXT_BUNDLE_KEY);
	
				if (!isBlank(editoTextMessage)) {
					var editoPopupDiv = document.createElement("div");
					editoPopupDiv.setAttribute("data-role", "popup");
					editoPopupDiv.setAttribute("data-theme", "b");
					editoPopupDiv.setAttribute("data-dismissible", "false");
					editoPopupDiv.setAttribute("class", "ui-corner-all");
					editoPopupDiv.setAttribute("id", page.id + EDITO_POPUP_DIV_ID);
					editoPopupDiv.innerHTML = "<p><span data-type=\"bundle\" data-key=\"" + page.id + EDITO_TEXT_BUNDLE_KEY + "\"></span></p><br/><br/>";
					
					var closeEditoLink = document.createElement("a");
					closeEditoLink.setAttribute("href", "#");
					closeEditoLink.setAttribute("data-rel", "back");
					closeEditoLink.setAttribute("class", "ui-btn ui-btn-right ui-corner-all ui-shadow ui-btn-a ui-icon-delete ui-btn-icon-notext ui-btn-right");
					editoPopupDiv.appendChild(closeEditoLink);
					pageDiv.appendChild(editoPopupDiv);
				}
			}
			
			
		if(true){
			// deconnect session
//			var deconnectLink = document.createElement("a");
//			deconnectLink.setAttribute("href", "#");
//			deconnectLink.setAttribute("class", "ui-btn ui-btn-inline ui-icon-power ui-btn-icon-notext ui-corner-all");
//			deconnectLink.setAttribute("id",page.id +"_deconnectLink");
//			pageDiv.appendChild(deconnectLink);
		}	
		
		if(page.backPageId){
			headerLeft.innerHTML = '<div class="pull-left"><a class="mon-dashboard-anchor" href="#'+page.backPageId+'"><img class="logo" src="design/assets/img/block-img/dashboard.png"></a></div>';
		}
		
		
		
//		var headerDivRight = document.createElement("div");
//		headerDivRight.setAttribute("class", "ui-btn-right");
//		headerDiv.appendChild(headerDivRight);

		var mainDiv = document.createElement("div");
		mainDiv.setAttribute("data-role", "main");
		mainDiv.setAttribute("class", "ui-content");
		pageDiv.appendChild(mainDiv);

		document.body.appendChild(pageDiv);

//		if (page.canAnnotate) {
//			var annotationPanelDiv = document.createElement("div");
//			annotationPanelDiv.setAttribute("data-role", "panel");
//			annotationPanelDiv.setAttribute("data-dismissible", "false");
//			annotationPanelDiv.setAttribute("data-swipe-close", "false");
//			annotationPanelDiv.setAttribute("data-position", "right");
//			annotationPanelDiv.setAttribute("data-display", "overlay");
//			annotationPanelDiv.setAttribute("id", page.id + annotationPanelId);
//			annotationPanelDiv.innerHTML = "<textarea id=\"" + page.id + annotationPanelTextId + "\"></textarea>";
//			pageDiv.appendChild(annotationPanelDiv);
//
//			var annotationLinkSave = document.createElement("a");
//			annotationLinkSave.setAttribute("href", "#");
//			annotationLinkSave.setAttribute("class", "ui-btn ui-btn-inline ui-icon-check ui-btn-icon-left");
//			annotationLinkSave.setAttribute("id", page.id + "_annotationLinkSave");
//			annotationLinkSave.innerHTML = "<span data-type=\"bundle\" data-key=\"general.save\"></span>";
//			annotationPanelDiv.appendChild(annotationLinkSave);
//			$("#" + page.id + "_annotationLinkSave").on("click", function(e) {
//				saveAnnotation(page.id);
//			});
//
//			var annotationLinkClose = document.createElement("a");
//			annotationLinkClose.setAttribute("href", "#");
//			annotationLinkClose.setAttribute("class", "ui-btn ui-btn-inline ui-icon-minus ui-btn-icon-left");
//			annotationLinkClose.setAttribute("id", page.id + "_annotationLinkClose");
//			annotationLinkClose.innerHTML = "<span data-type=\"bundle\" data-key=\"general.close\"></span>";
//			annotationPanelDiv.appendChild(annotationLinkClose);
//			$("#" + page.id + "_annotationLinkClose").on("click", function(e) {
//				$("#" + page.id + annotationPanelId).panel("close");
//			});
//
//			var annotationLinkOpen = document.createElement("a");
//			annotationLinkOpen.setAttribute("class", "ui-btn ui-btn-inline ui-icon-edit ui-btn-icon-notext ui-corner-all");
//			annotationLinkOpen.setAttribute("href", "#" + page.id + annotationPanelId);
//			annotationLinkOpen.setAttribute("id", page.id + "_annotationLink");
//			annotationLinkOpen.innerHTML = "<span data-type=\"bundle\" data-key=\"general.annotation.link\"></span>";
//			headerDivRight.appendChild(annotationLinkOpen);
//
//			$("#" + page.id + annotationPanelId).on("panelcreate", function(event, ui) {
//				loadAnnotation(page.id);
//			});
//		}
//
//		if (page.hasHelpText) {
//			var helpTextMessage = $.i18n.prop(page.id + HELP_TEXT_BUNDLE_KEY);
//
//			if (!isBlank(helpTextMessage)) {
//				var helpOpenLink = document.createElement("a");
//				helpOpenLink.setAttribute("class", "ui-btn ui-btn-inline ui-icon-info ui-btn-icon-notext ui-corner-all");
//				helpOpenLink.setAttribute("id", page.id + "_helpLink");
//				helpOpenLink.innerHTML = "<span data-type=\"bundle\" data-key=\"general.help.link\"></span>";
//
//				var helpPanelDiv = document.createElement("div");
//				helpPanelDiv.setAttribute("data-role", "panel");
//				helpPanelDiv.setAttribute("data-dismissible", "false");
//				helpPanelDiv.setAttribute("data-swipe-close", "false");
//				helpPanelDiv.setAttribute("data-position", "right");
//				helpPanelDiv.setAttribute("data-display", "overlay");
//				helpPanelDiv.setAttribute("id", page.id + helpPanelId);
//				helpPanelDiv.innerHTML = "<p><span data-type=\"bundle\" data-key=\"" + page.id + HELP_TEXT_BUNDLE_KEY + "\"></span></p><br/><br/>";
//				pageDiv.appendChild(helpPanelDiv);
//
//				var helpLinkClose = document.createElement("a");
//				helpLinkClose.setAttribute("href", "#");
//				helpLinkClose.setAttribute("class", "ui-btn ui-btn-inline ui-icon-minus ui-btn-icon-left");
//				helpLinkClose.setAttribute("id", page.id + "_helpLinkClose");
//				helpLinkClose.innerHTML = "<span data-type=\"bundle\" data-key=\"general.close\"></span>";
//				helpPanelDiv.appendChild(helpLinkClose);
//				$("#" + page.id + "_helpLinkClose").on("click", function(e) {
//					$("#" + page.id + helpPanelId).panel("close");
//				});
//
//				headerDivRight.appendChild(helpOpenLink);
//
//				$("#" + page.id + "_helpLink").on("click", function(e) {
//					$("#" + page.id + helpPanelId).panel("open");
//				});
//			}
//		}
//
//		if (page.hasEditoText) {
//			var editoTextMessage = $.i18n.prop(page.id + EDITO_TEXT_BUNDLE_KEY);
//
//			if (!isBlank(editoTextMessage)) {
//				var editoPopupDiv = document.createElement("div");
//				editoPopupDiv.setAttribute("data-role", "popup");
//				editoPopupDiv.setAttribute("data-theme", "b");
//				editoPopupDiv.setAttribute("data-dismissible", "false");
//				editoPopupDiv.setAttribute("class", "ui-corner-all");
//				editoPopupDiv.setAttribute("id", page.id + EDITO_POPUP_DIV_ID);
//				editoPopupDiv.innerHTML = "<p><span data-type=\"bundle\" data-key=\"" + page.id + EDITO_TEXT_BUNDLE_KEY + "\"></span></p><br/><br/>";
//				
//				var closeEditoLink = document.createElement("a");
//				closeEditoLink.setAttribute("href", "#");
//				closeEditoLink.setAttribute("data-rel", "back");
//				closeEditoLink.setAttribute("class", "ui-btn ui-btn-right ui-corner-all ui-shadow ui-btn-a ui-icon-delete ui-btn-icon-notext ui-btn-right");
//				editoPopupDiv.appendChild(closeEditoLink);
//				pageDiv.appendChild(editoPopupDiv);
//			}
//		}
//
//		if (page.displayToolBox) {
//			var toolBoxPopinDiv = document.createElement("div");
//			toolBoxPopinDiv.setAttribute("id", page.id + "_toolBoxPopin");
//			/*
//			 * toolBoxPopinDiv.setAttribute("data-role", "panel");
//			 * toolBoxPopinDiv.setAttribute("data-transition", "slideup");
//			 */
//			toolBoxPopinDiv.setAttribute("data-role", "panel");
//			toolBoxPopinDiv.setAttribute("data-dismissible", "false");
//			toolBoxPopinDiv.setAttribute("data-swipe-close", "false");
//			toolBoxPopinDiv.setAttribute("data-position", "right");
//			toolBoxPopinDiv.setAttribute("data-display", "overlay");
//
//			mainDiv.appendChild(toolBoxPopinDiv);
//
//			var barometerLink = document.createElement("a");
//			barometerLink.setAttribute("href", "#" + barometerPage.id);
//			barometerLink.setAttribute("class", "ui-btn ui-icon-location ui-btn-icon-left");
//			barometerLink.innerHTML = "<span data-type=\"bundle\" data-key=\"general.toolbox.barometer.link\"></span>";
//			toolBoxPopinDiv.appendChild(barometerLink);
//
//			var calendarLink = document.createElement("a");
//			calendarLink.setAttribute("class", "ui-btn ui-icon-calendar ui-btn-icon-left");
//			calendarLink.innerHTML = "<span data-type=\"bundle\" data-key=\"general.toolbox.calendar.link\"></span>";
//			toolBoxPopinDiv.appendChild(calendarLink);
//
//			var toolBoxLinkOpen = document.createElement("a");
//			toolBoxLinkOpen.setAttribute("class", "ui-btn ui-corner-all ui-shadow ui-btn-inline ui-icon-gear ui-btn-icon-left");
//			toolBoxLinkOpen.setAttribute("href", "#" + page.id + "_toolBoxPopin");
//			toolBoxLinkOpen.setAttribute("data-rel", "popup");
//			toolBoxLinkOpen.innerHTML = "<span data-type=\"bundle\" data-key=\"general.toolbox.link\"></span>";
//			var buttonCalendarOpen = document.createElement("a");
//				if (page.calendar) {
//					buttonCalendarOpen.setAttribute("class", "ui-btn-right");
//					buttonCalendarOpen.setAttribute("data-id", "calendarId");
//					buttonCalendarOpen.setAttribute("type","button");
//					buttonCalendarOpen.innerHTML = "<span data-type=\"bundle\" data-key=\"general.calendar\"></span>";					
//				}
//			var footerDiv = document.createElement("div");
//			footerDiv.setAttribute("data-role", "footer");
//			footerDiv.appendChild(toolBoxLinkOpen);
//			if (page.calendar ) {
//				footerDiv.appendChild(buttonCalendarOpen);
//					$('[data-id = calendarId]').on("click", function(e) {
//						// redirection vers l'agenda
//						$.mobile.changePage('#' + calendarPage.id);
//					});		
//			}
//			pageDiv.appendChild(footerDiv);
//		}
//		
//		
//		if (page.backPageId) {
//			var backPageLink = document.createElement("a");
//			backPageLink.setAttribute("href", "#" + page.backPageId);
//			backPageLink.setAttribute("id",page.id +"_backpageId");
//			backPageLink.setAttribute("class", "ui-btn ui-btn-left ui-icon-arrow-l ui-btn-icon-left");
//			backPageLink.innerHTML = '<span data-type="bundle" data-key="general.back"></span>';
//			headerDiv.appendChild(backPageLink);
//		}
//		
//		if (true) {
//			// deconnect session
//			var deconnectLink = document.createElement("a");
//			deconnectLink.setAttribute("href", "#");
//			deconnectLink.setAttribute("class", "ui-btn ui-btn-inline ui-icon-power ui-btn-icon-notext ui-corner-all");
//			deconnectLink.setAttribute("id",page.id +"_deconnectLink");
//			headerDivRight.appendChild(deconnectLink);
//			
//			$("#" + page.id + "_deconnectLink").on("click", function(e) {
//				 setGetConnection("no", function(){
//					deconnectSendInfo(function(){
//						clearTables(0, function() {
//							console.log('all tables cleared');
//							console.log('deconnection reussie');
//							$.mobile.changePage('#' + authentication.id);	
//						});
//				    });
//			     });
//			});
////			
//			// delete all data
//			var deleteLink = document.createElement("a");
//			deleteLink.setAttribute("href", "#");
//			deleteLink.setAttribute("class", "ui-btn ui-btn-inline ui-icon-delete ui-btn-icon-notext ui-corner-all");
//			deleteLink.setAttribute("id", page.id + "_deleteLink");
//			headerDivRight.appendChild(deleteLink);
//			
//			$("#" + page.id + "_deleteLink").on("click", function(e) {
//				clearTables(0, function() {
//					console.log('all tables cleared');
//					$.mobile.changePage('#' + dashBoardPage.id);
//				});
//			});
//		}
		$("#" + page.id + " > [data-role ='main']").load(page.path, function(responseTxt, statusTxt, xhr) {
			console.log(page.id + " loaded");
			createPage(pages, index += 1, callback);
		});
	} else {
		if (callback && callback != '') {
			callback();
		}
	}
}

function loadPages() {
	$.i18n.properties({
		name : 'Messages',
		path : 'messages/',
		mode : 'map',
		callback : function() {
			var pages = new Array();
			for ( var key in pageMap) {
				if (pageMap.hasOwnProperty(key)) {
					pages.push(pageMap[key]);
				}
			}
			createPage(pages, 0, translatePages);
		}
	});
}

function translatePages() {
	$("[data-type ='bundle']").each(function() {
		var key = $(this).attr("data-key");
		if (key && key != '') {
			var value = $.i18n.prop(key);
			if (value) {
				$(this).html(value);
			}
		}
	});
 getConnectionValue(function(value){
	 if(value=="yes") $.mobile.changePage('#' + introHelloPage.id);
	 else {if(value="no")$.mobile.changePage('#' + authentication.id);}
//	 $.mobile.changePage('#' + introProfilePage.id);
 });
}

function loadAnnotation(pageId) {
	console.log('loadAnnotation entering with pageId = ' + pageId);
	getAnnotation(pageId, function(annotation) {
		$("#" + pageId + annotationPanelTextId).val(annotation);
	});
}

function saveAnnotation(pageId) {
	console.log('saveAnnotation entering with pageId = ' + pageId);
	var text = $("#" + pageId + annotationPanelTextId).val();
	setAnnotation(pageId, text, function() {
		$("#" + pageId + annotationPanelId).panel("close");
	});
}