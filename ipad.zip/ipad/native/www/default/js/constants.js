
/* JavaScript content from js/constants.js in folder common */
var helpPanelId = '_helpPanel';
var annotationPanelId = '_annotationPanel';
var annotationPanelTextId = '_annotationPanelText';
var annotationLinkId = '_annotationLink';
var SCREEN_STATUS_LOCKED = 'SCREEN_STATUS_LOCKED';
var SCREEN_STATUS_ACCESSIBLE = 'SCREEN_STATUS_ACCESSIBLE';
var SCREEN_STATUS_IN_PROGRESS = 'SCREEN_STATUS_IN_PROGRESS';
var SCREEN_STATUS_FINISHED = 'SCREEN_STATUS_FINISHED';

var CSS_DISABLE_CLASSNAME = "ui-disabled";

var HELP_TEXT_BUNDLE_KEY = ".helpText";

var EDITO_TEXT_BUNDLE_KEY = ".editoText";
var EDITO_POPUP_DIV_ID = "_editoPopup";