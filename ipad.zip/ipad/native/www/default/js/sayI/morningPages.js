
/* JavaScript content from js/sayI/morningPages.js in folder common */
$(document).on("pagebeforeshow", "#" + sayImorningPagesPage.id, function(event) {
	sayI_morningPages_SetScreenState();
});

// Open datebox on text field click
$('#sayI_morningPages_date').on("click", function(e) {
	$('#sayI_morningPages_date').datebox({
	    mode: "calbox",
	    afterToday: true,
		useInline:false,
		useFocus:false,
		useNewStyle:false,
		useButton:false,
	});
	$('#sayI_morningPages_date').datebox('open');
});

// When a date is selected in the datebox, insert it in db
$('#sayI_morningPages_date').bind('datebox', function(e, p) {
	if (p.method === 'close') {
		var dateString = $('#sayI_morningPages_date').val();

		// set current screen in progress
		setActivityStatus(sayImorningPagesPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log(sayImorningPagesPage.id + " is now in progress");
		});

		if (!isBlank(dateString)) {
			var selectedDate = $('#sayI_morningPages_date').datebox('getTheDate');
			setCalendarDate(sayImorningPagesPage.id , selectedDate, "date"+ sayImorningPagesPage.id +" sayImorningPages", function(){
				sayI_morningPages_setDate(selectedDate, function() {
					sayI_morningPages_SetScreenState();
				});
			});
		}
	}
});

// add click event on validation button
$("#sayI_morningPages_validation").on("click", function(e) {
	sayI_MorningPages_validate(function() {
		console.log('morning pages are now validated');
		sayI_morningPages_SetScreenState();
	});

	// set current screen in progress
	
	setActivityStatus(sayImorningPagesPage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("sayI", 22 , function(){
			console.log(sayImorningPagesPage.id + " is now finished");
			setActivityStatus(sayImyLittleMePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log(sayImyLittleMePage.id + 'activity is now accessible');
				$.mobile.changePage("#" + sayISummaryPage.id);
			});
		});
	});
});

function sayI_morningPages_SetScreenState(initState) {
	//$("#" + sayImorningPagesPage.id + ' [role=button]').css("display",'none');
	sayI_MorningPages_isValidated(function() {
		toggleVisibility('#sayI_morningPages_validation', false);
		toggleEnabling('#sayI_morningPages_date', true);
	}, function() {
		toggleVisibility('#sayI_morningPages_validation', true);
		toggleEnabling('#sayI_morningPages_date', false);
	});

	sayI_morningPages_getDate(function(date) {
		$("#sayI_morningPages_date").datebox("setTheDate", date);
		toggleEnabling('#sayI_morningPages_validation', false);
	}, function() {
		console.log('date is not setted');
		toggleEnabling('#sayI_morningPages_validation', true);
	});
}