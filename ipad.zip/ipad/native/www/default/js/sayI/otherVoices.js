
/* JavaScript content from js/sayI/otherVoices.js in folder common */
$(document).on("pagebeforeshow", "#" + sayIotherVoicesPage.id, function(event) {
	console.log(sayIotherVoicesPage.id + "pagebeforeshow");
	sayI_otherVoices_SetScreenState();
});

$("#sayI_otherVoices_left_bloc1_image_button").on("click", function(e) {
	$("#sayI_otherVoices_left_bloc1_file").click();
});

$("#sayI_otherVoices_left_bloc2_image_button").on("click", function(e) {
	$("#sayI_otherVoices_left_bloc2_file").click();
});

$("#sayI_otherVoices_right_bloc1_image_button").on("click", function(e) {
	$("#sayI_otherVoices_right_bloc1_file").click();
});

$("#sayI_otherVoices_right_bloc2_image_button").on("click", function(e) {
	$("#sayI_otherVoices_right_bloc2_file").click();
});

// Image file upload
$("[id^=sayI_otherVoices_][id$=_file]").on('change', function(event) {
	console.log("Image upload to add entering");
	var imageNumber = $(this).attr("data-position");
	var file = $(this).prop("files")[0];
	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		console.log("file type = " + file.type);

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			sayI_otherVoices_addImage(imageNumber, base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.setAttribute("src", base64Value);

				var divImageId = '';
				if (imageNumber == 1) {
					divImageId = 'sayI_otherVoices_left_bloc1_image';
				} else if (imageNumber == 2) {
					divImageId = 'sayI_otherVoices_right_bloc1_image';
				} else if (imageNumber == 3) {
					divImageId = 'sayI_otherVoices_left_bloc2_image';
				} else if (imageNumber == 4) {
					divImageId = 'sayI_otherVoices_right_bloc2_image';
				}

				$('[id=' + divImageId + ']').empty();
				document.getElementById(divImageId).appendChild(image);

				sayI_otherVoices_checkValidationButtonEnabling();
			});
		});
	} else {
		console.log('file removed or has not a image extension');
	}
});

// On key up save current belief
$('[id^="sayI_otherVoices_"],[id$="_textarea"]').on("keyup", function(e) {
	console.log('blur event');

	var position = parseInt($(this).attr("data-position"));
	var value = $(this).val();

	sayI_otherVoices_SetDescription(position, value, function() {
		console.log('description added');
		sayI_otherVoices_checkValidationButtonEnabling();
	});
});

// Click on start button
$("#sayI_otherVoices_start_button").on("click", function(e) {

	setActivityStatus(sayIotherVoicesPage.id, SCREEN_STATUS_IN_PROGRESS, function() {

		toggleVisibility('#sayI_otherVoices_start_button', false);
		toggleVisibility('#sayI_otherVoices_valid_button', true);
		toggleEnabling('#sayI_otherVoices_valid_button', true);

		// display textareas
		toggleVisibility("#sayI_otherVoices_left_bloc1_textarea", true);
		toggleVisibility("#sayI_otherVoices_left_bloc2_textarea", true);
		toggleVisibility("#sayI_otherVoices_right_bloc1_textarea", true);
		toggleVisibility("#sayI_otherVoices_right_bloc2_textarea", true);

		// display upload photo buttons
		toggleVisibility("#sayI_otherVoices_left_bloc1_image_button", true);
		toggleVisibility("#sayI_otherVoices_left_bloc2_image_button", true);
		toggleVisibility("#sayI_otherVoices_right_bloc1_image_button", true);
		toggleVisibility("#sayI_otherVoices_right_bloc2_image_button", true);

		// clear sample description
		$('#sayI_otherVoices_left_bloc1_description').empty();
		$('#sayI_otherVoices_left_bloc2_description').empty();
		$('#sayI_otherVoices_right_bloc1_description').empty();
		$('#sayI_otherVoices_right_bloc2_description').empty();

		// clear sample images
		$('#sayI_otherVoices_left_bloc1_image').empty();
		$('#sayI_otherVoices_left_bloc2_image').empty();
		$('#sayI_otherVoices_right_bloc1_image').empty();
		$('#sayI_otherVoices_right_bloc2_image').empty();
	});
});

// Click on valid button
$("#sayI_otherVoices_valid_button").on("click", function(e) {

	setActivityStatus(sayIotherVoicesPage.id, SCREEN_STATUS_FINISHED, function() {
		 console.log(sayIotherVoicesPage.id + ' finished');
		 set_Status_Progression("sayI", 55 , function(){
			 setActivityStatus(sayIpassionsPage.id, SCREEN_STATUS_ACCESSIBLE,function() {
				 console.log(sayIpassionsPage.id + ' is now accessible');
				 $.mobile.changePage("#" + sayISummaryPage.id);
			 });
		 });
	});
});

function sayI_otherVoices_SetScreenState() {

	// If the activity is finished, hide action buttons;
	getActivityStatus(sayIotherVoicesPage.id, function(activityStatus) {

		console.log('activityStatus = ' + activityStatus);

		if (SCREEN_STATUS_ACCESSIBLE == activityStatus) {
			// hide upload photos button
			toggleVisibility("#sayI_otherVoices_left_bloc1_image_button", false);
			toggleVisibility("#sayI_otherVoices_left_bloc2_image_button", false);
			toggleVisibility("#sayI_otherVoices_right_bloc1_image_button", false);
			toggleVisibility("#sayI_otherVoices_right_bloc2_image_button", false);

			// hide and display button
			toggleVisibility("#sayI_otherVoices_start_button", true);
			toggleVisibility("#sayI_otherVoices_valid_button", false);

			// hide textareas
			toggleVisibility("#sayI_otherVoices_left_bloc1_textarea", false);
			toggleVisibility("#sayI_otherVoices_left_bloc2_textarea", false);
			toggleVisibility("#sayI_otherVoices_right_bloc1_textarea", false);
			toggleVisibility("#sayI_otherVoices_right_bloc2_textarea", false);

			sayI_otherVoices_displaySamples();
		} else if (SCREEN_STATUS_IN_PROGRESS == activityStatus) {
			toggleVisibility("#sayI_otherVoices_start_button", false);
			toggleVisibility("#sayI_otherVoices_valid_button", true);

			// show textareas
			toggleVisibility("#sayI_otherVoices_left_bloc1_textarea", true);
			toggleVisibility("#sayI_otherVoices_left_bloc2_textarea", true);
			toggleVisibility("#sayI_otherVoices_right_bloc1_textarea", true);
			toggleVisibility("#sayI_otherVoices_right_bloc2_textarea", true);

			sayI_otherVoices_loadImagesAndDescriptions();
			sayI_otherVoices_checkValidationButtonEnabling();
		} else if (SCREEN_STATUS_FINISHED == activityStatus) {
			sayI_otherVoices_loadImagesAndDescriptions();

			// disabling textareas
			toggleEnabling("#sayI_otherVoices_left_bloc1_textarea", true);
			toggleEnabling("#sayI_otherVoices_left_bloc2_textarea", true);
			toggleEnabling("#sayI_otherVoices_right_bloc1_textarea", true);
			toggleEnabling("#sayI_otherVoices_right_bloc2_textarea", true);

			// hide upload photos button
			toggleVisibility("#sayI_otherVoices_left_bloc1_image_button", false);
			toggleVisibility("#sayI_otherVoices_left_bloc2_image_button", false);
			toggleVisibility("#sayI_otherVoices_right_bloc1_image_button", false);
			toggleVisibility("#sayI_otherVoices_right_bloc2_image_button", false);

			// hide start and valid buttons
			toggleVisibility("#sayI_otherVoices_start_button", false);
			toggleVisibility("#sayI_otherVoices_valid_button", false);
		}
	});
}

function sayI_otherVoices_displaySamples() {

	for (var i = 0; i < 4; i++) {
		var context = '';
		var divId = '';

		if (i == 0) {
			context = 'left.bloc1';
			divId = 'left_bloc1';
		} else if (i == 1) {
			context = 'left.bloc2';
			divId = 'left_bloc2';
		} else if (i == 2) {
			context = 'right.bloc1';
			divId = 'right_bloc1';
		} else if (i == 3) {
			context = 'right.bloc2';
			divId = 'right_bloc2';
		}

		console.log('key = ' + 'sayI_otherVoices.' + context + '.sample.number');
		var sampleNumberString = $.i18n.prop('sayI_otherVoices.' + context + '.sample.number');

		// Random
		if (!isNaN(sampleNumberString)) {
			var sampleNumber = parseInt(sampleNumberString);
			console.log('sampleNumber = ' + sampleNumber);

			var randomIndice = getRandomInt(1, sampleNumber);
			console.log('randomIndice = ' + randomIndice);

			console.log('key = ' + 'sayI_otherVoices.' + context + '.sample.description.' + randomIndice);
			var description = $.i18n.prop('sayI_otherVoices.' + context + '.sample.description.' + randomIndice);

			console.log('key = ' + 'sayI_otherVoices.' + context + '.sample.photo.' + randomIndice);
			var imagePath = $.i18n.prop('sayI_otherVoices.' + context + '.sample.photo.' + randomIndice);

			$('#sayI_otherVoices_' + divId + '_description').html(description);

			var image = document.createElement("img");
			image.setAttribute("src", imagePath);

			$('#sayI_otherVoices_' + divId + '_image').empty();
			document.getElementById('sayI_otherVoices_' + divId + '_image').appendChild(image);
		}
	}
}

function sayI_otherVoices_loadImagesAndDescriptions() {
	// display images
	sayI_otherVoices_getAllImages(function(imageMap) {

		for ( var imageId in imageMap) {
			var image = document.createElement("img");
			image.setAttribute("src", imageMap[imageId]);

			var divImageId = '';
			if (imageId == 1) {
				divImageId = 'sayI_otherVoices_left_bloc1_image';
			} else if (imageId == 2) {
				divImageId = 'sayI_otherVoices_right_bloc1_image';
			} else if (imageId == 3) {
				divImageId = 'sayI_otherVoices_left_bloc2_image';
			} else if (imageId == 4) {
				divImageId = 'sayI_otherVoices_right_bloc2_image';
			}

			$('[id=' + divImageId + ']').empty();
			document.getElementById(divImageId).appendChild(image);
		}
	});

	// display descriptions
	sayI_otherVoices_getAllDescriptions(function(descriptionsMap) {

		for ( var position in descriptionsMap) {

			var textAreaId = '';
			if (position == 1) {
				textAreaId = 'sayI_otherVoices_left_bloc1_textarea';
			} else if (position == 2) {
				textAreaId = 'sayI_otherVoices_right_bloc1_textarea';
			} else if (position == 3) {
				textAreaId = 'sayI_otherVoices_left_bloc2_textarea';
			} else if (position == 4) {
				textAreaId = 'sayI_otherVoices_right_bloc2_textarea';
			}

			console.log('textarea id = ' + textAreaId);

			$('#' + textAreaId).val(descriptionsMap[position]);
		}
	});
}

function sayI_otherVoices_checkValidationButtonEnabling() {
	toggleEnabling('#sayI_otherVoices_valid_button', true);

	sayI_otherVoices_getAllImages(function(imageMap) {
		var imageCount = 0;

		for ( var imageId in imageMap) {
			imageCount++;
		}

		console.log('imageCount = ' + imageCount);

		if (imageCount == 4) {
			var nonBlankDescriptionCount = 0;
			sayI_otherVoices_getAllDescriptions(function(descriptionsMap) {

				for ( var position in descriptionsMap) {
					if (!isBlank(descriptionsMap[position])) {
						nonBlankDescriptionCount++;
					}
				}

				console.log('nonBlankDescriptionCount = ' + nonBlankDescriptionCount);

				if (nonBlankDescriptionCount == 4) {
					toggleEnabling('#sayI_otherVoices_valid_button', false);
				}
			});
		}
	});
}
