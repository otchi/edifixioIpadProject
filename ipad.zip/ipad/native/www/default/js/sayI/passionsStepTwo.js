
/* JavaScript content from js/sayI/passionsStepTwo.js in folder common */
var	passionStep2Image1 ;
var	passionStep2Image2 ;
var	passionStep2Image3 ;
var	passionStep2imagesPresent ;
var	passionStep2InputPresent ;
var sayIPassionsStepTwoImageNumber = 0;


$(document).on("pagebeforeshow", "#" + sayIpassionsStepTwoPage.id, function(event) {
	console.log(sayIpassionsStepTwoPage.id + "pagebeforeshow");
	sayI_passions_step2_SetScreenState();
});

$("#sayI_passions_stepTwo_button_1").on("click", function(e) {
	$("#sayI_passions_stepTwo_file_1").click();	
});

$("#sayI_passions_stepTwo_button_2").on("click", function(e) {	
	$("#sayI_passions_stepTwo_file_2").click();
});

$("#sayI_passions_stepTwo_button_3").on("click", function(e) {
	$("#sayI_passions_stepTwo_file_3").click();
});

$('#'+ sayIpassionsStepTwoPage.id +' [data-id=capturePicture]').on("click", function(e) {
	sayIPassionsStepTwoImageNumber = $(this).attr("data-image");
	Camera.PictureSourceType.PHOTOLIBRARY;
    navigator.camera.getPicture(sayIPassionsStep2UploadPictures,null,{sourceType:0,quality:60,destinationType:0});
});

function sayIPassionsStep2UploadPictures(data){
		console.log(sayIPassionsStepTwoImageNumber);
		sayI_passion_setPassion_step2_pictures(sayIPassionsStepTwoImageNumber, data, function(){
			var image = document.createElement("img");
			image.classList.add("passion_Step2_picture");
			image.setAttribute("src", "data:image/jpeg;base64," +data);
			console.log(sayIPassionsStepTwoImageNumber);
			$('#sayI_passions_stepTwo_image_'+sayIPassionsStepTwoImageNumber).empty();
			document.getElementById('sayI_passions_stepTwo_image_'+sayIPassionsStepTwoImageNumber).appendChild(image);
			$('#'+sayIpassionsStepTwoPage.id +' img').css("width","300px");
			$('#'+sayIpassionsStepTwoPage.id +' img').css("height","300px");
		});
	 if(sayIPassionsStepTwoImageNumber==1) passionStep2Image1=true;
	 if(sayIPassionsStepTwoImageNumber==2) passionStep2Image2=true;
	 if(sayIPassionsStepTwoImageNumber==3) passionStep2Image3=true;
     if((passionStep2Image1)&&(passionStep2Image2)&&(passionStep2Image3)){
    	 if(passionStep2InputPresent)
    		 toggleEnabling('#sayI_passion_step2_validation', false);
    	 passionStep2imagesPresent = true;
     }else{
    	 toggleEnabling('#sayI_passion_step2_validation', true);
    	 passionStep2imagesPresent = false;
     }
};

//sauvegarde quand on appuie sur le input
$("#" + sayIpassionsStepTwoPage.id + ' input').on("keyup", function(e) {
	var positionInput = $(this).attr('data-id');
	if(positionInput.length > 0)
	var valueInput = $(this).val();
	sayI_passion_setPassion_step2_key('input_'+positionInput,valueInput);
	if(($('#'+sayIpassionsStepTwoPage.id +' [data-id=1]').val().length > 0)&&($('#'+sayIpassionsStepTwoPage.id +' [data-id=2]').val().length > 0)
			&&($('#'+sayIpassionsStepTwoPage.id +' [data-id=3]').val().length > 0)){
		if(passionStep2imagesPresent)
		 toggleEnabling('#sayI_passion_step2_validation', false);
		passionStep2InputPresent = true;
	}else{
		toggleEnabling('#sayI_passion_step2_validation', true);
		passionStep2InputPresent = false;
	}	      
});

function sayI_passions_step2_SetScreenState(intro){
	
		passionStep2Image1 = false;
		passionStep2Image2 = false;
		passionStep2Image3 = false;
		passionStep2InputPresent = false;
		passionStep2imagesPresent = false;
		sayI_passion_getInputPassion_step2("bloc1_validation",function(){
			// bloc 1 validé 
			$('#sayI_passions_stepTwo_button_1').css('visibility','hidden');
			$('#sayI_passions_stepTwo_button_2').css('visibility','hidden');
     		$('#sayI_passions_stepTwo_button_3').css('visibility','hidden');
     		$("#" + sayIpassionsStepTwoPage.id+' input').attr('disabled','disabled');
     		toggleVisibility('#sayI_passion_step2_select_passion', true);
    		toggleVisibility('#sayI_passion_step2_validation', false);
    		toggleVisibility('#sayI_passion_step2_validation_page', true);
    		sayI_passion_getInputPassion_step2("bloc2_validation",function(){
    			// bloc 2 validé
    			getActivityStatus(sayIpassionsStepTwoPage.id, function(status){
    				if(status == SCREEN_STATUS_FINISHED){
    					$('#'+sayIpassionsStepTwoPage.id+' .sayI_passion_step2_validation_page').css('display','none');
    					$('#'+sayIpassionsStepTwoPage.id+' [data-class=next]').css('display','block');
    				}
    			});
    			$('#select_passion_step2').attr('disabled','disabled');
    			sayI_passion_getInputPassion_step2("selectedPassion",function(selectedPassion){
    				$('#select_passion_step2-button span').html(selectedPassion);
    			},
    			function(){
    				console.log("page is not validated ");
    			});
    			
    		},null);
		},
		function(){
			console.log("bloc 1 is not validated yet");
			toggleVisibility('#sayI_passion_step2_select_passion', false);
			toggleEnabling('#sayI_passion_step2_validation', true);
			toggleVisibility('#sayI_passion_step2_validation_page', false);
		});
		
		sayI_Passions_step2_getPictures(function(imagesMap) {
			if(imagesMap.length == 4){passionStep2imagesPresent=true;}
			for ( imageId in imagesMap) {
				var image = document.createElement("img");
				image.classList.add("passion_Step2_picture");
				console.log("photo : "+ imagesMap[imageId]);
				console.log("numero de photo : "+imageId);
				image.setAttribute("src", "data:image/jpeg;base64," + imagesMap[imageId]);
				$('#sayI_passions_stepTwo_image_' + imageId).empty();
				document.getElementById('sayI_passions_stepTwo_image_' + imageId).appendChild(image);
			}
			$('#'+sayIpassionsStepTwoPage.id +' img').css("width","300px");
			$('#'+sayIpassionsStepTwoPage.id +' img').css("height","300px");
			
			sayI_Passions_getValue("importantPassion1", function(importantPassion1){
			   $('#' + sayIpassionsStepTwoPage.id +' .sayI_passions_stepTwo_passion_1').html(importantPassion1);
			   $($('#sayI_passion_step2_select_passion option')[0]).html(importantPassion1);
			   $('#select_passion_step2-button span').html(importantPassion1);
			   sayI_Passions_getValue("importantPassion2", function(importantPassion2){
			      $('#' + sayIpassionsStepTwoPage.id +' .sayI_passions_stepTwo_passion_2').html(importantPassion2);
			      $($('#sayI_passion_step2_select_passion option')[1]).html(importantPassion2);
		          sayI_Passions_getValue("importantPassion3", function(importantPassion3){
		    	     $('#' + sayIpassionsStepTwoPage.id +' .sayI_passions_stepTwo_passion_3').html(importantPassion3);
		    	     $($('#sayI_passion_step2_select_passion option')[2]).html(importantPassion3);
	    	     		sayI_passion_getInputPassion_step2("input_1",function(valueInput){
		    				$('#' + sayIpassionsStepTwoPage.id +' [data-id=1]').val(valueInput);
		    			},
		    			function(){
		    				console.log("input 1 not setted");
		    			});
		    	     	sayI_passion_getInputPassion_step2("input_2",function(valueInput){
		    				$('#' + sayIpassionsStepTwoPage.id +' [data-id=2]').val(valueInput);
		    			},
		    			function(){
		    				console.log("input 2 not setted");
		    			});
		    	     	sayI_passion_getInputPassion_step2("input_3",function(valueInput){
		    				$('#' + sayIpassionsStepTwoPage.id +' [data-id=3]').val(valueInput);
		    			},
		    			function(){
		    				console.log("input 3 not setted");
		    			});
		    	     	if(($('#'+sayIpassionsStepTwoPage.id +' [data-id=1]').val().length > 0)&&($('#'+sayIpassionsStepTwoPage.id +' [data-id=2]').val().length > 0)
		    	    			&&($('#'+sayIpassionsStepTwoPage.id +' [data-id=3]').val().length > 0)){
	    	     			if (passionStep2imagesPresent)
	    	     				toggleEnabling('#sayI_passion_step2_validation', true);
	    	     			passionStep2InputPresent = true;
		    	     	}
		          });
		       });
			});
		});	
}

//add click event validation page button
$("#sayI_passion_step2_validation").on("click", function(e) {
	sayI_passion_setPassion_step2_key('bloc1_validation','true',function(){
		// valider le bloc 1
		// desactiver tous les inputs
		toggleVisibility('#sayI_passion_step2_select_passion', true);
		toggleVisibility('#sayI_passion_step2_validation', false);
		$('#sayI_passions_stepTwo_button_1').css('visibility','hidden');
		$('#sayI_passions_stepTwo_button_2').css('visibility','hidden');
 		$('#sayI_passions_stepTwo_button_3').css('visibility','hidden');
 		$("#" + sayIpassionsStepTwoPage.id+' input').attr('disabled','disabled');
 		toggleVisibility('#sayI_passion_step2_validation_page', true);
 		sayI_Passions_getValue("importantPassion1", function(importantPassion1){
		   $($('#sayI_passion_step2_select_passion option')[0]).html(importantPassion1);
		   $('#select_passion_step2-button span').html(importantPassion1);
		   sayI_Passions_getValue("importantPassion2", function(importantPassion2){
		      $($('#sayI_passion_step2_select_passion option')[1]).html(importantPassion2);
	          sayI_Passions_getValue("importantPassion3", function(importantPassion3){
	    	     $($('#sayI_passion_step2_select_passion option')[2]).html(importantPassion3);
	          });
		   });
 		});
	});
});
//add click event validation page button
$("#sayI_passion_step2_validation_page").on("click", function(e) {
	sayI_passion_setPassion_step2_key("selectedPassion", $('#select_passion_step2-button span').html(), function(){
		sayI_passion_setPassion_step2_key('bloc2_validation','true',function(){
			var positionPictureSelected = $('#select_passion_step2' ).find(":selected").attr('data-pos');;
			sayI_passion_setPassion_step2_key('positionPictureSelected',positionPictureSelected,function(){	
				setActivityStatus(sayIpassionsStepTwoPage.id, SCREEN_STATUS_FINISHED, function(){
					set_Status_Progression("sayI", 77, function(){
						setActivityStatus(sayIpassionsStepThreePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
							$.mobile.changePage("#" + sayIpassionsStepThreePage.id);
						});
					});
				});
			});	
		});
	});
});

$("#"+sayIpassionsStepTwoPage.id+" [data-class=next]").on("click", function(e) {
	$.mobile.changePage("#" + sayIpassionsStepThreePage.id);
});