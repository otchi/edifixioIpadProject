
/* JavaScript content from js/sayI/passionsStepThree.js in folder common */
$(document).on("pagebeforeshow", "#" + sayIpassionsStepThreePage.id, function(event) {
	console.log(sayIpassionsStepThreePage.id + "pagebeforeshow");
	sayI_passions_step3_SetScreenState();
});

$("#sayI_passion_step3_validation_page").on("click", function(e) {
	
	var markPassion = $('#' + sayIpassionsStepThreePage.id +' select' ).find(":selected").text();
	var positionMarkPassion = $('#' + sayIpassionsStepThreePage.id +' select' ).find(":selected").attr('data-pos');
	sayI_passion_setPassion_step2_key('markPassionStep3', markPassion, function(){
		sayI_passion_setPassion_step2_key('page_passion_step3_validated','true', function(){
			setActivityStatus(sayIpassionsStepThreePage.id, SCREEN_STATUS_FINISHED, function(){
				set_Status_Progression("sayI", 88, function(){
					positionMarkPassion = parseInt(positionMarkPassion);
					if( positionMarkPassion < 3) {
						setActivityStatus(sayIpassionsStepFourPage.id, SCREEN_STATUS_ACCESSIBLE, function(){
							$.mobile.changePage("#" + sayIpassionsStepFourPage.id);
						});
					}
					else{
						$.mobile.changePage("#" + sayISummaryPage.id);
					}
				});
			});
		});
	})
});	

$("#" + sayIpassionsStepThreePage.id+' [data-class=next]').on("click", function(e) {
	var positionMarkPassion = $('#' + sayIpassionsStepThreePage.id +' select' ).find(":selected").attr('data-pos');
	positionMarkPassion = parseInt(positionMarkPassion);
	if( positionMarkPassion < 3) {
		$.mobile.changePage("#" + sayIpassionsStepFourPage.id);
	}
	else{
		$.mobile.changePage("#" + sayISummaryPage.id);
	}
});

function sayI_passions_step3_SetScreenState(){
	$('#select_passion_mark_step3 option').each(function(i) {
		$(this).html($.i18n.prop('compass.Myvalue.proLifeButton.'+(i+1)));
	});
	$('#select_passion_mark_step3-button span').html($.i18n.prop('compass.Myvalue.proLifeButton.1'));
	sayI_passion_getInputPassion_step2("selectedPassion",function(selectedPassion){
		$('#'+sayIpassionsStepThreePage.id+' .passion_Selected').html(selectedPassion);
		sayI_passion_getInputPassion_step2("positionPictureSelected",function(positionPictureSelected){
			sayI_passion_getPicture_step3(positionPictureSelected, function(data){
				var image = document.createElement("img");
				image.classList.add("passion_Selected_picture");
				image.setAttribute("src", "data:image/jpeg;base64," +data);
				$('#passion_Selected_picture').empty();
				document.getElementById('passion_Selected_picture').appendChild(image);
				$('#'+sayIpassionsStepThreePage.id +' img').css("width","300px");
				$('#'+sayIpassionsStepThreePage.id +' img').css("height","300px");
			}, null);
			sayI_passion_getInputPassion_step2("page_passion_step3_validated",function(page_passion_step3_validated){
				$('#select_passion_mark_step3').attr('disabled','disabled');
					sayI_passion_getInputPassion_step2("markPassionStep3",function(markPassionStep3){
						getActivityStatus(sayIpassionsStepThreePage.id, function(status){
							if(status == SCREEN_STATUS_FINISHED){
								$('#'+sayIpassionsStepThreePage.id+' .sayI_passion_step3_validation_page').css('display','none');
								$('#'+sayIpassionsStepThreePage.id+' [data-class=next]').css('display','block');
							}
							$('#select_passion_mark_step3-button span').html(markPassionStep3);
						});
					},null);
			},null);
		},null);
	},null);
}

