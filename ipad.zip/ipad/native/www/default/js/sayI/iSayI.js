
/* JavaScript content from js/sayI/iSayI.js in folder common */
$(document).on("pagebeforeshow", "#" + sayIiSayIPage.id, function(event) {
	sayI_ISayI_SetScreenState(true);
});

$(document).on("pagecreate", "#" + sayIiSayIPage.id, function(event) {
	$("#sayI_iSayI_i_slider").on("slidestop", function(e, ui) {

		var counterIValue = $(this).val();

		sayI_ISayI_setICounterValue(counterIValue, function() {
			sayI_ISayI_setActivityInProgress();
			sayI_ISayI_SetScreenState(false);
		});
	});

	$("#sayI_iSayI_one_slider").on("slidestop", function(e, ui) {

		var counterIValue = $(this).val();

		sayI_ISayI_setOneCounterValue(counterIValue, function() {
			sayI_ISayI_setActivityInProgress();
			sayI_ISayI_SetScreenState(false);
		});
	});
});

// add click event on counter validation button
$("#sayI_iSayI_counter_validation").on("click", function(e) {
	sayI_ISayI_validateCounter(function() {
		console.log('counter are now validated');
		sayI_ISayI_SetScreenState(false);
	});
});

// add click event on counter validation button
$("#sayI_iSayI_bloc2_validation").on("click", function(e) {
	sayI_ISayI_validateBloc2(function() {
		console.log('bloc 2 is now validated');
		sayI_ISayI_SetScreenState(false);
	});
});

// add event when press key on textarea comment
$("#sayI_iSayI_bloc2_textarea").on("keyup", function(e) {
	var comment = $(this).val();

	sayI_ISayI_setComment(comment, function() {
		console.log('comment added');
		sayI_ISayI_SetScreenState(false);
	});
});

// Open datebox on text field click
$('#sayI_iSayI_bloc3_date').on("click", function(e) {
	$('#sayI_iSayI_bloc3_date').datebox({
	    mode: "calbox",
	    afterToday: true,
		useInline:false,
		useFocus:false,
		useNewStyle:false,
		useButton:false,
	});
	$('#sayI_iSayI_bloc3_date').datebox('open');
});

// When a date is selected in the datebox, insert it in db
$('#sayI_iSayI_bloc3_date').bind('datebox', function(e, p) {
	if (p.method === 'close') {
		var dateString = $('#sayI_iSayI_bloc3_date').val();

		if (!isBlank(dateString)) {
			var selectedDate = $('#sayI_iSayI_bloc3_date').datebox('getTheDate');
 			setCalendarDate(sayIiSayIPage.id , selectedDate, "date"+ sayIiSayIPage.id +" NosayNo", function(){
				sayI_ISayI_setDate(selectedDate, function() {
					sayI_ISayI_SetScreenState(false);
				});
 			});
		}
	}
});

// add click event on bloc 3 validation button
$("#sayI_iSayI_bloc3_validation").on("click", function(e) {
	sayI_ISayI_validateBloc3(function() {
		console.log('bloc 3 is now validated');
		sayI_ISayI_SetScreenState(false);

		setActivityStatus(sayIiSayIPage.id, SCREEN_STATUS_FINISHED, function() {
			set_Status_Progression("sayI", 11, function(){
				console.log(sayIiSayIPage.id + ' activity is now finished');
				setActivityStatus(sayImorningPagesPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
					console.log(sayImorningPagesPage.id + 'activity is now accessible');
					$.mobile.changePage("#" + sayISummaryPage.id);
				});
			});
		});
	});
});

function sayI_ISayI_setActivityInProgress() {
	setActivityStatus(sayIiSayIPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log(sayIiSayIPage.id + " is now in progress");
	});
}

function sayI_ISayI_SetScreenState(initState) {
	//$("#" + sayIiSayIPage.id + ' [role=button]').css("display",'none');
	if (initState) {
		sayI_ISayI_getICounterValue(function(counterValue) {
			$("#sayI_iSayI_i_slider").val(counterValue).slider("refresh");
			;
		});

		sayI_ISayI_getOneCounterValue(function(counterValue) {
			$("#sayI_iSayI_one_slider").val(counterValue).slider("refresh");
			;
		});

		sayI_ISayI_getComment(function(comment) {
			$('#sayI_iSayI_bloc2_textarea').val(comment);
		}, null);

		sayI_ISayI_getDate(function(date) {
			$("#sayI_iSayI_bloc3_date").datebox("setTheDate", date);
		}, function() {
			console.log('date is not setted');
		});
	}

	sayI_ISayI_getICounterValue(function(iCounterValue) {

		if (iCounterValue > 0) {
			sayI_ISayI_getOneCounterValue(function(oneCounterValue) {

				if (oneCounterValue > 0) {
					toggleEnabling('#sayI_iSayI_counter_validation', false);
				} else {
					toggleEnabling('#sayI_iSayI_counter_validation', true);
				}
			});
		} else {
			toggleEnabling('#sayI_iSayI_counter_validation', true);
		}
	});

	sayI_ISayI_isCounterValidated(function() {
		toggleEnabling('#sayI_iSayI_i_slider', true);
		$("#sayI_iSayI_i_slider").slider('refresh');
		
		toggleEnabling('#sayI_iSayI_one_slider', true);
		$("#sayI_iSayI_one_slider").slider('refresh');
		
		toggleVisibility('#sayI_iSayI_counter_validation', false);
		toggleVisibility('#sayI_iSayI_bloc2', true);

		sayI_ISayI_isBloc2Validated(function() {
			console.log('bloc 2 is validated');
			toggleVisibility('#sayI_iSayI_bloc3', true);
			toggleVisibility('#sayI_iSayI_bloc2_validation', false);
			toggleEnabling('#sayI_iSayI_bloc2_textarea', true);

			sayI_ISayI_getDate(function(date) {
				toggleEnabling('#sayI_iSayI_bloc3_validation', false);
				console.log('date is setted : ' + date);

				sayI_ISayI_isBloc3Validated(function() {
					console.log('bloc 3 is validated');
					toggleEnabling('#sayI_iSayI_bloc3_date', true);
					toggleVisibility('#sayI_iSayI_bloc3_validation', false);
				}, function() {
					toggleEnabling('#sayI_iSayI_bloc3_date', false);
					toggleVisibility('#sayI_iSayI_bloc3_validation', true);
					console.log('bloc 3 is not validated');
				});
			}, function() {
				toggleEnabling('#sayI_iSayI_bloc3_validation', true);
				console.log('date is not setted');
			});

		}, function() {
			console.log('bloc 2 isn\'t validated');
			toggleEnabling('#sayI_iSayI_bloc2_textarea', false);
			toggleVisibility('#sayI_iSayI_bloc2_validation', true);
			toggleVisibility('#sayI_iSayI_bloc3', false);

			sayI_ISayI_getComment(function(comment) {
				if (!isBlank(comment)) {
					console.log('Comments are setted and aren\'t blank');
					toggleEnabling('#sayI_iSayI_bloc2_validation', false);
				} else {
					console.log('Comments are setted but are blank');
					toggleEnabling('#sayI_iSayI_bloc2_validation', true);
				}
			}, function() {
				console.log('Comments are not setted');
				toggleEnabling('#sayI_iSayI_bloc2_validation', true);
			});
		});

	}, function() {
		toggleVisibility('#sayI_iSayI_bloc2', false);
		toggleVisibility('#sayI_iSayI_bloc3', false);
	});
}