
/* JavaScript content from js/sayI/passions.js in folder common */
var nombreInputPassions = 6;
$(document).on("pagebeforeshow", "#" + sayIpassionsPage.id, function(event) {
	console.log(sayIpassionsPage.id + "pagebeforeshow");
	sayI_passions_SetScreenState(true);
});

//sauvgarde quand on appuie sur le input
$("#" + sayIpassionsPage.id + ' textarea').on("keyup", function(e) {
	sayI_passions_addPassionButton();
});

$("#" + sayIpassionsPage.id +' [data-id=addPassion]').on("click", function(e) {
	sayI_passions_addPassionEvent();
});

$("#" + sayIpassionsPage.id +' [data-id=removePassion]').on("click", function(e) {
	sayI_passions_removePassionEvent();
});

$('#sayI_passion_step1_left_validation').on("click", function(e) {
	sayI_passion_savebloc1();
	sayI_passions_SetScreenState(false);
});

$('#sayI_passion_step1_left_annulation').on("click", function(e) {
	sayI_passion_deletePassion_step1(table_sayi_passion_stepone,function(){
		sayI_passion_deletePassion_step1(table_sayi_passion_stepone_key,function(){
			$("#" + sayIpassionsPage.id+' textarea').removeAttr('disabled');
			toggleVisibility('#sayI_passion_step1_left_annulation', false);
			$("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','block');
			$("#" + sayIpassionsPage.id +' [data-id=removePassion]').css('display','block');
			toggleEnabling('#sayI_passion_step1_left_validation', false); 
			toggleVisibility('#sayI_passion_step1_bloc2', false);
		});
	});
});

$('#sayI_passion_step1_right_validation').on("click", function(e) {
	sayI_passion_savebloc2();
	sayI_passions_SetScreenState(false);
});

$('#' + sayIpassionsPage.id +' select' )
.change(function () {
	  
   var importantPassion1 = $("#select-passion-1").find(":selected").text();
   var positionPassion1 = $("#select-passion-1").find(":selected").attr('data-pos');
   desableSlectOption(positionPassion1, 2);
   var importantPassion2 = $("#select-passion-2").find(":selected").text();
   var positionPassion2 = $("#select-passion-2").find(":selected").attr('data-pos');
   desableSlectOption(positionPassion2, 3);
   var importantPassion3 = $("#select-passion-3").find(":selected").text();
   var positionPassion3 = $("#select-passion-3").find(":selected").attr('data-pos');
   var positionOption1 = parseInt(positionPassion1);
   var positionOption2 = parseInt(positionPassion2);
   var positionOption3 = parseInt(positionPassion3);
   if((importantPassion1 !=importantPassion2)&&(importantPassion1 !=importantPassion3)&&(importantPassion2 !=importantPassion3)){
	   if(( positionOption1 < positionOption2) && (positionOption2 < positionOption3)){
		   sayI_passion_setPassion_step1_key("importantPassion1",importantPassion1,function(){
			   sayI_passion_setPassion_step1_key("importantPassion2",importantPassion2,function(){
				   sayI_passion_setPassion_step1_key("importantPassion3",importantPassion3,function(){
					   toggleEnabling('#sayI_passion_step1_right_validation',false);
				   });
			   });
		   });
	   }else{
		   //nous informer que les option doivent etre ordonnés
		   toggleEnabling('#sayI_passion_step1_right_validation',true);  
	   }
   }else{
	   toggleEnabling('#sayI_passion_step1_right_validation',true);  
   }
})
.change();		   

//add click event validation page button
$("#sayI_passion_step1_validation").on("click", function(e) {
	$.mobile.changePage("#" + sayIpassionsStepTwoPage.id);
});



function desableSlectOption(index,select){
	if(index > 0){
		$('#select-passion-'+select+' option').each(function() {
			  $( this ).removeAttr('disabled');  
		});
		for(var i=0;i < index;i++){
			 $($('#select-passion-'+select+' option')[i]).attr('disabled','disabled');
		}
		
	}
}
function sayI_passions_SetScreenState(intro){
	if(intro){
		toggleVisibility('#sayI_passion_step1_validation', false);
		//recuperer toutes les infos sur la page
		sayI_Passion_IsBlocValidate("bloc1Validate",function() {
			
			$("#" + sayIpassionsPage.id+' textarea').attr('disabled','disabled');
			$("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','none');
			$("#" + sayIpassionsPage.id +' [data-id=removePassion]').css('display','none');
			toggleVisibility('#sayI_passion_step1_bloc2', true);
			toggleEnabling('#sayI_passion_step1_left_validation', true);
			
			sayI_Passion_IsBlocValidate ("bloc2Validate",function() {
				// si le bloc 2 est validé
				getActivityStatus(sayIpassionsPage.id, function(status){
					toggleEnabling('#sayI_passion_step1_left_annulation', true);
					$("#" + sayIpassionsPage.id+' select').attr('disabled','disabled');
					
					if(status == SCREEN_STATUS_FINISHED){
						toggleVisibility('#sayI_passion_step1_right_validation', false);
						toggleVisibility('#sayI_passion_step1_validation', true);
					}
				});
				
			},function() {
				// si bloc 1 est validé mais le bloc 2 non
				toggleVisibility('#sayI_passion_step1_left_annulation', true);
			});
		},function() {
			toggleVisibility('#sayI_passion_step1_left_validation', false);
			toggleVisibility('#sayI_passion_step1_left_annulation', false);
			toggleVisibility('#sayI_passion_step1_bloc2', false);
		});
	}
	sayI_Passion_IsBlocValidate("bloc1Validate",function() {
		//recuperer les passion
		sayI_Passions_getValue("numberPassions", function(numberPassions){
			nombreInputPassions = numberPassions;
			sayI_Passions_getPassions(function(passions){
				var listePassions =  new Array();
				for(var passion in passions) 
					for(var v in passions[passion]) 
						if (v==1) listePassions.push(passions[passion][v]);
					
				   for(var i=1;i<nombreInputPassions;i++){
					   $("#" + sayIpassionsPage.id +' [data-position='+i+']').val(listePassions[i-1]);
					   $("#" + sayIpassionsPage.id +' [data-pos='+i+']').html(listePassions[i-1]);
					   $("#" + sayIpassionsPage.id +' [data-position='+i+']').css('display','block');
					   $("#" + sayIpassionsPage.id +' [data-pos='+i+']').css('display','block');
					   if(i==(nombreInputPassions-1))
						   while(i<11){
							   i++;
							   $("#" + sayIpassionsPage.id +' [data-pos='+i+']').css('display','none');
						   }
				   }
				   $('#select-passion-1 option').each(function() {
						  $( this ).removeAttr('disabled');  
				   });
				   $('#select-passion-2 option').each(function() {
						  $( this ).removeAttr('disabled');  
				   });
				   $($('#select-passion-1 option')[nombreInputPassions-2]).attr('disabled','disabled');
				   $($('#select-passion-1 option')[nombreInputPassions-3]).attr('disabled','disabled');
				   $($('#select-passion-2 option')[nombreInputPassions-2]).attr('disabled','disabled');
				   $('#select-passion-1-button span').html($($('#select-passion-1 option')[0]).html());
				   $('#select-passion-2-button span').html($($('#select-passion-1 option')[1]).html());
				   $('#select-passion-3-button span').html($($('#select-passion-1 option')[2]).html());
				   
				   sayI_Passion_IsBlocValidate ("bloc2Validate",function() {
					   sayI_Passions_getValue("importantPassion1", function(importantPassion1){
						   writeImportantPassion(importantPassion1,1);
						   sayI_Passions_getValue("importantPassion2", function(importantPassion2){
							   writeImportantPassion(importantPassion2,2);
						       sayI_Passions_getValue("importantPassion3", function(importantPassion3){
						    	   writeImportantPassion(importantPassion3,3);
					           })
					       })
					   })
				   },null);
			});
		})
	},null);
}


function writeImportantPassion(importantPassion,selectNumber){
	
	$('#select-passion-'+selectNumber+' option').each(function() {
		  if($(this).html()==importantPassion)$(this).attr("selected","selected");
	});
	$('#select-passion-'+selectNumber).selectmenu('refresh');
}

function sayI_passions_addPassionButton(){
	
		var addPassion = true;
		for(var i =1; i < nombreInputPassions;i++){
			var inputCurrent = ($("#" + sayIpassionsPage.id + ' [data-position='+i+']').val()).trim();
			if( inputCurrent.length == 0 ) addPassion = false;
			}
		if(addPassion){
			toggleVisibility('#sayI_passion_step1_left_validation', true);
			if (nombreInputPassions!=11) $("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','block');
			else $("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','none');
		}else{
			toggleVisibility('#sayI_passion_step1_left_validation', false);
			$("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','none');
		}
		
}

function sayI_passions_removePassionEvent(){
	
	$("#" + sayIpassionsPage.id +' [data-position='+(nombreInputPassions-1)+']').val("");
	$("#" + sayIpassionsPage.id +' [data-position='+(nombreInputPassions-1)+']').css('display','none');
	nombreInputPassions --;
	if(nombreInputPassions==6)$("#" + sayIpassionsPage.id +' [data-id=removePassion]').css('display','none');
	sayI_passions_addPassionButton();
}

function sayI_passions_addPassionEvent(){
	toggleVisibility('#sayI_passion_step1_left_validation', false);
	$("#" + sayIpassionsPage.id +' [data-id=removePassion]').css('display','block');
	$("#" + sayIpassionsPage.id +' [data-position='+nombreInputPassions+']').css('display','block');
	$("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','none');
	nombreInputPassions ++;
}

function sayI_passion_savebloc1(){
	
	$("#" + sayIpassionsPage.id+' textarea').attr('disabled','disabled');
	$("#" + sayIpassionsPage.id +' [data-id=addPassion]').css('display','none');
	$("#" + sayIpassionsPage.id +' [data-id=removePassion]').css('display','none');
	toggleVisibility('#sayI_passion_step1_bloc2', true);
	toggleVisibility('#sayI_passion_step1_left_annulation', true);
	toggleEnabling('#sayI_passion_step1_left_validation', true); 
	$('#select-passion-1 option').each(function() {
		  $( this ).removeAttr('disabled');  
	});
	$('#select-passion-2 option').each(function() {
		  $( this ).removeAttr('disabled');  
	});
	$($('#select-passion-1 option')[nombreInputPassions-2]).attr('disabled','disabled');
	$($('#select-passion-1 option')[nombreInputPassions-3]).attr('disabled','disabled');
	$($('#select-passion-2 option')[nombreInputPassions-2]).attr('disabled','disabled');
	sayI_passion_setPassion_step1_key("bloc1Validate","true",function(){
		sayI_passion_setPassion_step1_key("numberPassions",nombreInputPassions,function(){
			for(var i=1;i<nombreInputPassions;i++){
				sayI_passion_setPassion_step1(i,$("#" + sayIpassionsPage.id+' [data-position='+i+']').val());
				$('#select-passion-1-button span').html($($('#select-passion-1 option')[0]).html());
				$('#select-passion-2-button span').html($($('#select-passion-1 option')[1]).html());
				$('#select-passion-3-button span').html($($('#select-passion-1 option')[2]).html());
				$($('#select-passion-1 option')[0]).attr("selected","selected");
				writeImportantPassion('1', 2);
				$($('#select-passion-2 option')[1]).attr("selected","selected");
				writeImportantPassion('2', 2);
				$($('#select-passion-3 option')[2]).attr("selected","selected");
			}
		});
	});
}

function sayI_passion_savebloc2(){
	console.log('page Motivate yourself with your passions step 1 is now validated');
	setActivityStatus(sayIpassionsPage.id, SCREEN_STATUS_FINISHED, function() {
		console.log(sayIpassionsPage.id + ' activity is now finished');
		set_Status_Progression("sayI", 66, function(){
			setActivityStatus(sayIpassionsStepTwoPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log(sayIpassionsStepTwoPage.id + 'activity is now accessible');
				sayI_passion_setPassion_step1_key("bloc2Validate","true",function(){
					$.mobile.changePage("#" + sayIpassionsStepTwoPage.id);
				});
			});
		});
	});
}


