
/* JavaScript content from js/sayI/summary.js in folder common */
$("#sayI_summary_stage_1").on("click", function(e) {
	$.mobile.changePage('#' + sayIiSayIPage.id);
});

$("#sayI_summary_stage_2").on("click", function(e) {
	getActivityStatus(sayImorningPagesPage.id, function(activityStatus_sayIiSayI_screen) {
		if (activityStatus_sayIiSayI_screen && !activityStatus_sayIiSayI_screen == '') {
			$.mobile.changePage('#' + sayImorningPagesPage.id);
		} 
	});
});

$("#sayI_summary_stage_3").on("click", function(e) {
	getActivityStatus(sayImyLittleMePage.id, function(activityStatus_sayImyLittleMe_screen) {
		if (activityStatus_sayImyLittleMe_screen && !activityStatus_sayImyLittleMe_screen == '') {
			$.mobile.changePage('#' + sayImyLittleMePage.id);
		} 
	});
});

$("#sayI_summary_stage_4").on("click", function(e) {
	getActivityStatus(sayImyBeliefsPage.id, function(activityStatus_sayImyBeliefs_screen) {
		if (activityStatus_sayImyBeliefs_screen && !activityStatus_sayImyBeliefs_screen == '') {
			$.mobile.changePage('#' + sayImyBeliefsPage.id);
		} 
	});
});

$("#sayI_summary_stage_5").on("click", function(e) {
	getActivityStatus(sayIotherVoicesPage.id, function(activityStatus_sayIotherVoices_screen) {
		if (activityStatus_sayIotherVoices_screen && !activityStatus_sayIotherVoices_screen == '') {
			$.mobile.changePage('#' + sayIotherVoicesPage.id);
		} 
	});
});

$("#sayI_summary_stage_6").on("click", function(e) {
	getActivityStatus(sayIpassionsStepTwoPage.id, function(activityStatus_sayIpassionsStepTwo_screen){
		getActivityStatus(sayIpassionsStepThreePage.id, function(activityStatus_sayIpassionsStepThree_screen){
			getActivityStatus(sayIpassionsStepFourPage.id, function(activityStatus_sayIpassionsStepFour_screen){
				getActivityStatus(sayIpassionsPage.id, function(activityStatus_sayIpassionsPage_screen) {
					if((activityStatus_sayIpassionsStepFour_screen) && ((activityStatus_sayIpassionsStepFour_screen==SCREEN_STATUS_ACCESSIBLE)||(activityStatus_sayIpassionsStepFour_screen==SCREEN_STATUS_IN_PROGRESS)))
						$.mobile.changePage('#' + sayIpassionsStepFourPage.id);
					else if((activityStatus_sayIpassionsStepThree_screen) && ((activityStatus_sayIpassionsStepThree_screen==SCREEN_STATUS_ACCESSIBLE)||(activityStatus_sayIpassionsStepThree_screen==SCREEN_STATUS_IN_PROGRESS)))
						$.mobile.changePage('#' + sayIpassionsStepThreePage.id);
					else if((activityStatus_sayIpassionsStepTwo_screen) && ((activityStatus_sayIpassionsStepTwo_screen==SCREEN_STATUS_ACCESSIBLE)||(activityStatus_sayIpassionsStepTwo_screen==SCREEN_STATUS_IN_PROGRESS)))
						$.mobile.changePage('#' + sayIpassionsStepTwoPage.id);
					else if (activityStatus_sayIpassionsPage_screen && !activityStatus_sayIpassionsPage_screen == '') 
						$.mobile.changePage('#' + sayIpassionsPage.id); 
				});
			});
		});
	});	
});



$(document).on("pagebeforeshow", "#" + sayISummaryPage.id, function(event) {

	getActivityStatus(sayIiSayIPage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_1_status").html(SCREEN_STATUS_ACCESSIBLE);
		} else {
			$("#sayI_1_status").html(activityStatus);
		}
	});

	getActivityStatus(sayImorningPagesPage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_2_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#sayI_2_status").html(activityStatus);
		}
	});

	getActivityStatus(sayImyLittleMePage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_3_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#sayI_3_status").html(activityStatus);
		}
	});

	getActivityStatus(sayImyLittleMePage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_4_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#sayI_4_status").html(activityStatus);
		}
	});

	getActivityStatus(sayImyBeliefsPage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_4_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#sayI_4_status").html(activityStatus);
		}
	});

	getActivityStatus(sayIotherVoicesPage.id, function(activityStatus) {
		if (!activityStatus || activityStatus == '') {
			$("#sayI_5_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#sayI_5_status").html(activityStatus);
		}
	});
	
	getActivityStatus(sayIpassionsStepTwoPage.id, function(activityStatus_sayIpassionsStepTwo_screen){
		getActivityStatus(sayIpassionsStepThreePage.id, function(activityStatus_sayIpassionsStepThree_screen){
			getActivityStatus(sayIpassionsStepFourPage.id, function(activityStatus_sayIpassionsStepFour_screen){
				getActivityStatus(sayIpassionsPage.id, function(activityStatus_sayIpassionsPage_screen) {
					if(activityStatus_sayIpassionsStepFour_screen && !activityStatus_sayIpassionsStepFour_screen == '') 
							$("#sayI_6_status").html(activityStatus_sayIpassionsStepFour_screen);
					else if(activityStatus_sayIpassionsStepThree_screen && !activityStatus_sayIpassionsStepThree_screen == '')
							$("#sayI_6_status").html(activityStatus_sayIpassionsStepThree_screen);
					else if(activityStatus_sayIpassionsStepTwo_screen && !activityStatus_sayIpassionsStepTwo_screen == '')
							$("#sayI_6_status").html(activityStatus_sayIpassionsStepTwo_screen);
					else if(activityStatus_sayIpassionsPage_screen && !activityStatus_sayIpassionsPage_screen == ''){ 
							$("#sayI_6_status").html(activityStatus_sayIpassionsPage_screen);
						 }else{
							 $("#sayI_6_status").html(SCREEN_STATUS_LOCKED);
						 }
				}); 
			});
		});
	});	

});
