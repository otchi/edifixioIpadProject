
/* JavaScript content from js/sayI/myBeliefs.js in folder common */
$(document).on("pagebeforeshow", "#" + sayImyBeliefsPage.id, function(event) {
	console.log(sayImyBeliefsPage.id + "pagebeforeshow");
	sayI_myBeliefs_SetScreenState();
});

// Click on start button
$("#sayI_myBeliefs_start_button").on("click", function(e) {

	setActivityStatus(sayImyBeliefsPage.id, SCREEN_STATUS_IN_PROGRESS, function() {

		toggleVisibility('#sayI_myBeliefs_left_bloc_samples', false);
		toggleVisibility('#sayI_myBeliefs_right_bloc_samples', false);
		toggleVisibility('#sayI_myBeliefs_start_button', false);
		toggleVisibility('#sayI_myBeliefs_valid_button', true);
		toggleVisibility('#sayI_myBeliefs_left_bloc_user', true);
		toggleVisibility('#sayI_myBeliefs_right_bloc_user', true);
	});
});

// Click on valid button
$("#sayI_myBeliefs_valid_button").on("click", function(e) {
	setActivityStatus(sayImyBeliefsPage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("sayI", 44 , function(){
			console.log(sayImyBeliefsPage.id + ' finished');
			setActivityStatus(sayIotherVoicesPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log(sayIotherVoicesPage.id + ' is now accessible');
				$.mobile.changePage("#" + sayISummaryPage.id);
			});
		});
	});
});

// On key up save current belief
$('[id^="sayI_myBeliefs_left_bloc_text_"],[id^="sayI_myBeliefs_right_bloc_text_"]').on("keyup", function(e) {
	console.log('blur event');

	var position = parseInt($(this).attr("data-position"));
	var value = $(this).val();

	sayiMyBeliefs_addAnswer(position, value, function() {
		console.log('answer added');
		sayI_myBeliefs_checkValidationButtonEnabling();
	});
});

function sayI_myBeliefs_SetScreenState() {

	// If the activity is finished, hide action buttons;
	getActivityStatus(sayImyBeliefsPage.id, function(activityStatus) {

		console.log('activityStatus = ' + activityStatus);

		if (SCREEN_STATUS_ACCESSIBLE == activityStatus) {
			toggleVisibility('#sayI_myBeliefs_left_bloc_samples', true);
			toggleVisibility('#sayI_myBeliefs_right_bloc_samples', true);
			toggleVisibility('#sayI_myBeliefs_start_button', true);
			toggleVisibility('#sayI_myBeliefs_valid_button', false);
			toggleVisibility('#sayI_myBeliefs_left_bloc_user', false);
			toggleVisibility('#sayI_myBeliefs_right_bloc_user', false);
		} else if (SCREEN_STATUS_IN_PROGRESS == activityStatus) {
			toggleVisibility('#sayI_myBeliefs_left_bloc_samples', false);
			toggleVisibility('#sayI_myBeliefs_right_bloc_samples', false);
			toggleVisibility('#sayI_myBeliefs_start_button', false);
			toggleVisibility('#sayI_myBeliefs_valid_button', true);
			sayI_myBeliefs_checkValidationButtonEnabling();
			toggleVisibility('#sayI_myBeliefs_left_bloc_user', true);
			toggleVisibility('#sayI_myBeliefs_right_bloc_user', true);
			toggleEnabling('[id^="sayI_myBeliefs_"][id*="bloc_text_"]', false);
			sayI_myBeliefs_loadAnswer();
		} else if (SCREEN_STATUS_FINISHED == activityStatus) {
			toggleVisibility('#sayI_myBeliefs_left_bloc_samples', false);
			toggleVisibility('#sayI_myBeliefs_right_bloc_samples', false);
			toggleVisibility('#sayI_myBeliefs_start_button', false);
			toggleVisibility('#sayI_myBeliefs_valid_button', false);
			toggleVisibility('#sayI_myBeliefs_left_bloc_user', true);
			toggleVisibility('#sayI_myBeliefs_right_bloc_user', true);
			toggleEnabling('[id^="sayI_myBeliefs_"][id*="bloc_text_"]', true);
			sayI_myBeliefs_loadAnswer();
		}
	});
}

function sayI_myBeliefs_loadAnswer() {
	sayiMyBeliefs_getAllAnswers(function(answerMap) {

		for ( var position in answerMap) {
			var answer = answerMap[position];

			$inputText = $('[id^="sayI_myBeliefs_"][id*="bloc_text_"][data-position="' + position + '"]');
			$inputText.val(answer);
		}

	});
}

function sayI_myBeliefs_checkValidationButtonEnabling() {
	sayiMyBeliefs_getAllAnswers(function(answerMap) {

		var nonEmptyAnswerExpected = 6;
		var nonEmptyAnswerCount = 0;

		for ( var position in answerMap) {
			var answer = answerMap[position];

			if (!isBlank(answer)) {
				nonEmptyAnswerCount++;
			}
		}

		console.log('nonEmptyAnswerCount = ' + nonEmptyAnswerCount);

		if (nonEmptyAnswerCount == nonEmptyAnswerExpected) {
			toggleEnabling('#sayI_myBeliefs_valid_button', false);
		} else {
			toggleEnabling('#sayI_myBeliefs_valid_button', true);
		}
	});
}