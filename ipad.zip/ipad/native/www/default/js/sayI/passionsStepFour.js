
/* JavaScript content from js/sayI/passionsStepFour.js in folder common */
$(document).on("pagebeforeshow", "#" + sayIpassionsStepFourPage.id, function(event) {
	console.log(sayIpassionsStepFourPage.id + "pagebeforeshow");
	sayI_passions_step4_SetScreenState(true);
});


$( "#" + sayIpassionsStepFourPage.id+" .sayI_passions_step4").keyup(function() {
	var currentAction = $(this).val();
  if ((currentAction)&&(currentAction.trim().length>0)){
      sayI_passion_setPassion_step4_key("input_action_passion_step4", currentAction);
  	  $("#" + sayIpassionsStepFourPage.id+' .passion_step4_error1').css('display','none');
  }else $("#" + sayIpassionsStepFourPage.id+' .passion_step4_error1').css('display','block');
	
});

$( "#" + sayIpassionsStepFourPage.id+" .sayI_passions_step4_how").keyup(function() {
		var currentAction = $(this).val();
	  if ((currentAction)&&(currentAction.trim().length>0)){
	      sayI_passion_setPassion_step4_key("input_action_passion_step4_how", currentAction);
	      toggleEnabling('#sayI_passion_step4_validation_bloc1', true);
	  }else{
		  toggleEnabling('#sayI_passion_step4_validation_bloc1', false);
	  }
});

$('#sayI_passion_step4_validation_bloc1').on("click", function(e) {
	sayI_passion_setPassion_step4_key("passion_step4_bloc1_validated", 'true',function(){
		$('.sayI_passions_step4_bloc1').css('display','none');
		$('.sayI_passions_step4_bloc2').css('display','block');
		$('.sayI_passion_step4_validation_bloc2').css('display','block');
		$('.sayI_passion_step4_validation_bloc1').css('display','none');
		sayI_passion_getPassion_step4("input_action_passion_step4", function(inputAction){
			$('#'+sayIpassionsStepFourPage.id+' .sayI_passions_step4_actionInput').html(inputAction);
		},null);
	});
});	

$('#sayI_passion_step4_validation_bloc2').on("click", function(e) {
	sayI_passion_setPassion_step4_key("passion_step4_bloc2_validated", 'true',function(){
		//direction vers le dashboard
		setActivityStatus(sayIpassionsStepFourPage.id, SCREEN_STATUS_FINISHED, function(){
			setActivityStatus(talentsIRecognizePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
				set_Status_Progression("sayI", 100 , function(){
					$.mobile.changePage("#" + sayISummaryPage.id);
				});
			});
		});
	});
});	

$('#sayI_passions_step4_actionDate').on("click", function(e) {
	$('#sayI_passions_step4_actionDate').datebox('open');
});

$('#'+sayIpassionsStepFourPage.id+' [data-class=next]').on("click", function(e) {
	$.mobile.changePage("#" + sayISummaryPage.id);
});
//
function sayI_passions_step4_SetScreenState(state){
if(state){
	sayI_passion_getInputPassion_step2("selectedPassion",function(selectedPassion){
		$('#'+sayIpassionsStepFourPage.id+' .passion_Selected').html(selectedPassion);
		sayI_passion_getInputPassion_step2("positionPictureSelected",function(positionPictureSelected){
			sayI_passion_getPicture_step3(positionPictureSelected, function(data){
				var image = document.createElement("img");
				image.classList.add("passion_Selected_picture_step4");
				image.setAttribute("src", "data:image/jpeg;base64," +data);
				$('#passion_Selected_picture_step4').empty();
				document.getElementById('passion_Selected_picture_step4').appendChild(image);
				$('#'+sayIpassionsStepFourPage.id +' img').css("width","300px");
				$('#'+sayIpassionsStepFourPage.id +' img').css("height","300px");
			}, null);
		},null);
	},null);
}	
	sayI_passion_getPassion_step4("input_action_passion_step4", function(inputHow){
		$( "#" + sayIpassionsStepFourPage.id+" .sayI_passions_step4").val(inputHow);
		$('#'+sayIpassionsStepFourPage.id+' .sayI_passions_step4_actionInput').html(inputHow);
	},function(){
		console.log('passion action is not setted');
	});
	
	sayI_passion_getPassion_step4("passion_step4_bloc1_validated", function(){
		
		$('.sayI_passions_step4_bloc1').css('display','none');
		$('.sayI_passions_step4_bloc2').css('display','block');
		$('.sayI_passion_step4_validation_bloc2').css('display','block');
		$('.sayI_passion_step4_validation_bloc1').css('display','none');
		
		sayI_passion_getPassion_step4("input_action_passion_step4_how", function(inputHow){
			$( "#" + sayIpassionsStepFourPage.id+" .sayI_passions_step4_how").val(inputHow);
		},function(){
			console.log('passion action plane is not setted');
		});
		
		sayI_passion_getPassion_step4_date("date_action_passion_step4",function(date) {
			$("#sayI_passions_step4_actionDate").datebox("setTheDate", date);
		}, function() {
			console.log('passion_date is not setted');
		});	
		 
		sayI_passion_getPassion_step4("passion_step4_bloc2_validated", function(){
			// la page est validée
			// redirection vers le dashbord
			getActivityStatus(sayIpassionsStepFourPage.id, function(status){
				if(status == SCREEN_STATUS_FINISHED){
					$('#'+sayIpassionsStepFourPage.id+' .sayI_passion_step4_validation_bloc2').css('display','none');
					$('#'+sayIpassionsStepFourPage.id+' [data-class=next]').css('display','block');
				}
				$("#" + sayIpassionsStepFourPage.id+" .sayI_passions_step4_how").attr("disabled","disabled");
				$("#sayI_passions_step4_actionDate").attr("disabled","disabled");
			});
		}, null);
	}, function(){
		// rien n'est validé dans la page
		
	});	
	
	//When a date is selected in the datebox, insert it in db
	$('#sayI_passions_step4_actionDate').bind('datebox', function(e, p) {
		if (p.method === 'close') {
			var dateString = $(this).val();
			if (!isBlank(dateString)) {
				var selectedDate = $(this).datebox('getTheDate');
				setCalendarDate(sayIpassionsStepFourPage.id , selectedDate, "date"+ sayIpassionsStepFourPage.id, function(){
					sayI_passion_setPassion_step4_date("date_action_passion_step4",selectedDate, function() {
		 				
		 			});	 
				});
			}	 		
		}
	});
}

