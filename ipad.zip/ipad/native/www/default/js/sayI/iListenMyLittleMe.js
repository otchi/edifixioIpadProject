
/* JavaScript content from js/sayI/iListenMyLittleMe.js in folder common */
