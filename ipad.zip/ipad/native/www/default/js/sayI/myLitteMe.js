
/* JavaScript content from js/sayI/myLitteMe.js in folder common */
$(document).on("pagebeforeshow", "#" + sayImyLittleMePage.id, function(event) {
	sayI_myLittleMe_SetScreenState();
});

$("#sayI_myLittleMe_photo_button_1").on("click", function(e) {
	$("#sayI_myLittleMe_file_1").click();
});

$("#sayI_myLittleMe_photo_button_2").on("click", function(e) {
	$("#sayI_myLittleMe_file_2").click();
});

$("#sayI_myLittleMe_photo_button_3").on("click", function(e) {
	$("#sayI_myLittleMe_file_3").click();
});

$("#sayI_myLittleMe_photo_button_4").on("click", function(e) {
	$("#sayI_myLittleMe_file_4").click();
});

$("#sayI_myLittleMe_photo_profile_button").on("click", function(e) {
	$("#sayI_myLittleMe_profile_photo_file").click();
});

// Add click event on button
$("#sayI_myLittleMe_validation_button").on("click", function(e) {
	setActivityStatus(sayImyLittleMePage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("sayI", 33 , function(){
			console.log(sayImyLittleMePage.id + ' finished');
			setActivityStatus(sayImyBeliefsPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log(sayImyBeliefsPage.id + ' is now accessible');
				$.mobile.changePage("#" + sayISummaryPage.id);
			});
		});
	});
});

// Click on start button
$("#sayI_myLittleMe_start_button").on("click", function(e) {

	setActivityStatus(sayImyLittleMePage.id, SCREEN_STATUS_IN_PROGRESS, function() {

		// Show all upload image button
		$('#' + sayImyLittleMePage.id + ' [id^="sayI_myLittleMe_photo_button_"]').each(function(index, value) {
			$(this).show();
		});
		$('#sayI_myLittleMe_photo_profile_button').show();

		// clear name and sentence text field
		$('#' + sayImyLittleMePage.id + ' [id^="sayI_myLittleMe_sentence_"]').each(function(index, value) {
			$(this).val('');
		});
		$('#' + sayImyLittleMePage.id + ' [id^="sayI_myLittleMe_name_"]').each(function(index, value) {
			$(this).val('');
		});

		// clear all images
		$('#' + sayImyLittleMePage.id + ' [id^="sayI_myLittleMe_image_"]').each(function(index, value) {
			$(this).empty();
		});

		// hide start and validation button
		toggleVisibility('#sayI_myLittleMe_start_button', false);
		toggleVisibility('#sayI_myLittleMe_validation_button', false);

		// enable name and sentence text
		toggleEnabling('[id^="sayI_myLittleMe_name_"]', false);
		toggleEnabling('[id^="sayI_myLittleMe_sentence_"]', false);
	});
});

// Image file upload
$("[id^=sayI_myLittleMe_file_]").on('change', function(event) {
	console.log("Image upload to add entering");
	var imageNumber = $(this).attr("data-position");
	var file = $(this).prop("files")[0];
	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		console.log("file type = " + file.type);

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			sayI_MyLittleMe_addImage(imageNumber, base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.setAttribute("src", base64Value);
				
				$('#sayI_myLittleMe_image_' + imageNumber).empty();
				document.getElementById('sayI_myLittleMe_image_' + imageNumber).appendChild(image);
				
				sayI_myLittleMe_checkValidationButtonVisibily();
			});
		});
	} else {
		console.log('file removed or has not a image extension');
	}
});

$("#sayI_myLittleMe_profile_photo_file").on('change', function(event) {
	console.log("Image upload to add entering");
	var file = $(this).prop("files")[0];
	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		console.log("file type = " + file.type);

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			sayI_MyLittleMe_setProfileImage(base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.setAttribute("src", base64Value);

				$('#sayI_myLittleMe_profile_photo').empty();
				document.getElementById('sayI_myLittleMe_profile_photo').appendChild(image);

				sayI_myLittleMe_checkValidationButtonVisibily();
			});
		});
	} else {
		console.log('file removed or has not a image extension');
	}
});

$('#' + sayImyLittleMePage.id + ' [type=text][id^="sayI_myLittleMe_name_"]').on("keyup", function(e) {
	var namePosition = $(this).attr("data-position");
	var value = $(this).val();

	sayI_MyLittleMe_addName(namePosition, value, function() {
		sayI_myLittleMe_checkValidationButtonVisibily();
	});
});

$('#' + sayImyLittleMePage.id + ' [type=text][id^="sayI_myLittleMe_sentence_"]').on("keyup", function(e) {
	var sentencePosition = $(this).attr("data-position");
	var value = $(this).val();

	sayI_MyLittleMe_addSentence(sentencePosition, value, function() {
		sayI_myLittleMe_checkValidationButtonVisibily();
	});
});

function sayI_myLittleMe_SetScreenState() {

	// display images
	sayI_MyLittleMe_getAllImages(function(imageMap) {
		for ( var imageId in imageMap) {
			var image = document.createElement("img");
			image.setAttribute("src", imageMap[imageId]);

			$('#sayI_myLittleMe_image_' + imageId).empty();
			document.getElementById('sayI_myLittleMe_image_' + imageId).appendChild(image);
		}
	});

	// set image profil
	sayI_MyLittleMe_getProfileImage(function(image) {
		var imageTag = document.createElement("img");
		imageTag.setAttribute("src", image);

		$('#sayI_myLittleMe_profile_photo').empty();
		document.getElementById('sayI_myLittleMe_profile_photo').appendChild(imageTag);
	}, null);

	// set names
	sayI_MyLittleMe_getAllNames(function(namesMap) {
		for ( var position in namesMap) {
			$('#sayI_myLittleMe_name_' + position).val(namesMap[position]);
		}
	});

	// set sentences
	sayI_MyLittleMe_getAllSentences(function(sentencesMap) {
		for ( var position in sentencesMap) {
			$('#sayI_myLittleMe_sentence_' + position).val(sentencesMap[position]);
		}
	});

	// If the activity is finished, hide action buttons;
	getActivityStatus(sayImyLittleMePage.id, function(activityStatus) {
		console.log("status = " + activityStatus);

		if (activityStatus == SCREEN_STATUS_FINISHED) {
			$('#sayI_myLittleMe_start_button').hide();
			$('#sayI_myLittleMe_validation_button').hide();
			$('[id^="sayI_myLittleMe_photo_button_"]').hide();
			$('#sayI_myLittleMe_photo_profile_button').hide();
			toggleEnabling('[id^="sayI_myLittleMe_name_"]', true);
			toggleEnabling('[id^="sayI_myLittleMe_sentence_"]', true);
		} else if (activityStatus == SCREEN_STATUS_ACCESSIBLE) {
			sayI_myLittleMe_displaySamples();
			toggleVisibility('#sayI_myLittleMe_start_button', true);
			toggleVisibility('#sayI_myLittleMe_validation_button', false);
			toggleVisibility('[id^="sayI_myLittleMe_photo_button_"]', false);
			toggleVisibility('#sayI_myLittleMe_photo_profile_button', false);
			toggleEnabling('[id^="sayI_myLittleMe_name_"]', true);
			toggleEnabling('[id^="sayI_myLittleMe_sentence_"]', true);
		} else if (activityStatus == SCREEN_STATUS_IN_PROGRESS) {
			$('#sayI_myLittleMe_start_button').hide();
			toggleVisibility('#sayI_myLittleMe_validation_button', false);
			sayI_myLittleMe_checkValidationButtonVisibily();
		}
	});
}

function sayI_myLittleMe_displaySamples() {

	var sampleNumberString = $.i18n.prop('sayI_myLittleMe.sample.number');

	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);

		if (sampleNumber > 4) {
			var tempArray = new Array();
			for (var i = 0; i < sampleNumber; i++) {
				tempArray.push(i + 1);
			}

			for (var i = 0; i < 4; i++) {

				var randomIndice = getRandomInt(0, tempArray.length - 1);
				var randomValue = tempArray[randomIndice];
				tempArray.splice(randomIndice, 1);

				var title = $.i18n.prop('sayI_myLittleMe.sample.' + randomValue + '.name');
				var sentence = $.i18n.prop('sayI_myLittleMe.sample.' + randomValue + '.sentence');
				var imagePath = $.i18n.prop('sayI_myLittleMe.sample.' + randomValue + '.photo');

				$('#sayI_myLittleMe_name_' + (i + 1)).val(title);
				$('#sayI_myLittleMe_sentence_' + (i + 1)).val(sentence);

				var image = document.createElement("img");
				image.setAttribute("src", imagePath);

				$('#sayI_myLittleMe_image_' + (i + 1)).empty();
				document.getElementById('sayI_myLittleMe_image_' + (i + 1)).appendChild(image);
			}

			// Hide all upload image button
			$('#' + sayImyLittleMePage.id + ' [id^="sayI_myLittleMe_photo_button_"]').each(function(index, value) {
				$(this).hide();
			});
			$('#sayI_myLittleMe_photo_profile_button').hide();

		} else {
			console.log('sample number must be superior or egal to 4');
		}
	} else {
		console.log("sayI_myLittleMe.sample.number is not a number");
	}
}

function sayI_myLittleMe_checkValidationButtonVisibily() {
	toggleVisibility('#sayI_myLittleMe_validation_button', false);

	sayI_MyLittleMe_getAllNames(function(namesMap) {
		var nonBlankNameNumber = 0;
		console.log('namesMap.length = ' + namesMap.length);
		for ( var position in namesMap) {
			if (!isBlank(namesMap[position])) {
				nonBlankNameNumber += 1;
			}
		}

		console.log('nonBlankNameNumber = ' + nonBlankNameNumber);
		if (nonBlankNameNumber == 4) {
			sayI_MyLittleMe_getAllSentences(function(sentencesMap) {
				var nonBlankSentenceNumber = 0;

				for ( var position in sentencesMap) {
					if (!isBlank(sentencesMap[position])) {
						nonBlankSentenceNumber++;
					}
				}

				console.log('nonBlankSentenceNumber = ' + nonBlankSentenceNumber);

				if (nonBlankSentenceNumber == 4) {

					sayI_MyLittleMe_getAllImages(function(imageMap) {
						var imageNumber = 0;

						for ( var imageId in imageMap) {
							imageNumber++;
						}

						if (imageNumber == 4) {
							console.log('4 images ok');
							sayI_MyLittleMe_getProfileImage(function() {
								console.log('profil image ok');
								displayValidationButton = true;
								$('#sayI_myLittleMe_validation_button').show();
							}, null);
						}
					});
				}
			});
		}
	});
}