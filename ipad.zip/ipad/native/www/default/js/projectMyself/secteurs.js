
/* JavaScript content from js/projectMyself/secteurs.js in folder common */
function Sector(id, SectorLabel) {
	this.id = id;
	this.SectorLabel = SectorLabel;
};

var sectorMap = {};

function getSectorLocalizedLabel(sectorId) {
	var sector = sectorMap[sectorId];
	if (sector && sector != null) {		
			return sector.SectorLabel;		
	}
}

function createSector(id, SectorLabel) {
	sectorMap[id] = new Sector(id, SectorLabel);
}
function createSectorMap() {
	var sampleNumberString = $.i18n.prop('projectMyself.InFiveYears.sector.number');
	
	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('projectMyself.InFiveYears.sector.'+i);	
				console.log(title);
				createSector(i, title);
			}
	} else {
		console.log("projectMyself.InFiveYears.sector.number is not a number");
	}
	
}

function createNetworkMap() {
	var sampleNumberString = $.i18n.prop('myNetwork.MyInternalNetwork.sector.number');
	
	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('myNetwork.MyInternalNetwork.sector.'+i);	
				console.log(title);
				createSector(i, title);
			}
	} else {
		console.log("myNetwork.MyInternalNetwork.sector.number is not a number");
	}
	
}