
/* JavaScript content from js/projectMyself/CardRoutesPage_step1.js in folder common */

var test =0;
var boolCible = true;
createSectorMap();
$fieldSetOption = $('#'+projectMyselfMyCardRoutesPage.id +' select');
for ( var key in sectorMap) {
	var valueLabel = getSectorLocalizedLabel(key);
	var htmlCode = '<option  class ="myCardRoutesoption_'+key+'" value="#">'+valueLabel+'</option>';
	$fieldSetOption.append(htmlCode);
}

$(document).on("pagebeforeshow", "#" + projectMyselfMyCardRoutesPage.id, function(event) {
	
	boolCible = true;
	$('#' + projectMyselfMyCardRoutesPage.id+' td').css("padding","50px");
	$('#' + projectMyselfMyCardRoutesPage.id+' td').css("border-style","solid");
	$('#' + projectMyselfMyCardRoutesPage.id+' td').css("border-width","1px");
	for(var j=1;j<4;j++){
		var projectMyselfSelect = $('#myCardRoutesServiceSelect'+j+' option');
		for(var i=0;i<projectMyselfSelect.length;i++){
			$(projectMyselfSelect[i]).attr("value",$(projectMyselfSelect[i]).text());	
		}
	}
	getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
		$('#myCardRoutesServiceSelect1 [value="'+sector1+'"]').prop('selected', true);		
		getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
			$('#myCardRoutesServiceSelect2 [value="'+sector2+'"]').prop('selected', true);
			getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
				  $('#myCardRoutesServiceSelect3 [value="'+sector3+'"]').prop('selected', true);
				  $('#myCardRoutesServiceSelect3').selectmenu('refresh');
				  $('#myCardRoutesServiceSelect2').selectmenu('refresh');
				  $('#myCardRoutesServiceSelect1').selectmenu('refresh');
				  projectMyself_MyCardRoutes_showServices();
			});
		});
	});
	getActivityStatus(projectMyselfMyCardRoutesPage.id, function(status){
		getInprojectMyselfCardRoutesKey("Target",function(rowNumber){	
			$("#" + projectMyselfMyCardRoutesPage.id+' [data-row='+rowNumber+']').html('');
			if(rowNumber && status == SCREEN_STATUS_FINISHED){
				$("#" + projectMyselfMyCardRoutesPage.id+' [data-row='+rowNumber+']').html('cible');
				boolCible = false;
			}
		});
	});
	
});

$( "#" + projectMyselfMyCardRoutesPage.id+" select" )
.change(function () {
	projectMyself_MyCardRoutes_showServices();
})
.change();


function projectMyself_MyCardRoutes_showServices(){
	var iCriteria1 = $("#myCardRoutesServiceSelect1").find(":selected").text();
	$("#" + projectMyselfMyCardRoutesPage.id+' option').removeAttr('disabled');
	for(var i=0;i<6;i++){
	   for(var j=2;j<4;j++){
		   var optionLabel = $($('#myCardRoutesServiceSelect'+j+' option')[i]).text();
		   var optionValue = $('#myCardRoutesServiceSelect'+j+' option')[i];
		   if(optionLabel==iCriteria1)$(optionValue).attr('disabled','disabled');
	   }
	}
	var iCriteria2 = $("#myCardRoutesServiceSelect2").find(":selected").text();
	for(var i=0;i<6;i++){
	   for(var j=1;j<4;j++){
		   if(j!=2){
			   var optionLabel = $($('#myCardRoutesServiceSelect'+j+' option')[i]).text();
			   var optionValue = $('#myCardRoutesServiceSelect'+j+' option')[i];
			   if(optionLabel==iCriteria2)$(optionValue).attr('disabled','disabled');
		   }
	    }
	}
	var iCriteria3 = $("#myCardRoutesServiceSelect3").find(":selected").text();
	for(var i=0;i<6;i++){
	   for(var j=1;j<4;j++){
		   if(j!=3){
			   var optionLabel = $($('#myCardRoutesServiceSelect'+j+' option')[i]).text();
			   var optionValue = $('#myCardRoutesServiceSelect'+j+' option')[i];
			   if(optionLabel==iCriteria3)$(optionValue).attr('disabled','disabled');
		   	}
	   }
	}
	if((iCriteria1 !=iCriteria2)&&(iCriteria1 !=iCriteria3)&&(iCriteria2 !=iCriteria3)){ 
		addInprojectMyselfCardRoutesKey("Sector1",iCriteria1,function(){
			addInprojectMyselfCardRoutesKey("Sector2",iCriteria2, function(){
				addInprojectMyselfCardRoutesKey("Sector3",iCriteria3, function(){
					toggleEnabling('#'+projectMyselfMyCardRoutesPage.id+' [data-id =myCardRoutesCible]',false);
					test = 1;
				});
			});
		});
	}else toggleEnabling('#'+projectMyselfMyCardRoutesPage.id+' [data-id =myCardRoutesCible]',true); 
}

$('#'+projectMyselfMyCardRoutesPage.id+' .row').on("click", function(e){
	// choix de la destination 
	if((test==1)&&(boolCible)){
		$(this).html('cible');
		boolCible = false;
		addInprojectMyselfCardRoutesKey("Target",$(this).attr("data-row"), function(){
			setActivityStatus(projectMyselfMyCardRoutesPage.id, SCREEN_STATUS_FINISHED, function(){
				setActivityStatus(GoodDirection.id, SCREEN_STATUS_ACCESSIBLE, function(){
					$.mobile.changePage("#" + GoodDirection.id);
				});
			});
		});
	}
 });
	


