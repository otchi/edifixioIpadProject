
/* JavaScript content from js/projectMyself/summary.js in folder common */


$(document).on("pagebeforeshow", "#" + projectMyselfSummaryPage.id, function(event) {
	
//	getActivityStatus(projectMyselfInFiveYearsPage.id, function(projectMyselfActivityStatus) {
//		if (!projectMyselfActivityStatus || projectMyselfActivityStatus == '') {
//			$("#projectMyself_1_status").html(SCREEN_STATUS_ACCESSIBLE);
//		} else {
//			$("#projectMyself_1_status").html(projectMyselfActivityStatus);
//		}
//	});
//	
	getActivityStatus(projectMyselfMyCardRoutesPage.id, function(statusMyCardRoutes){
		getActivityStatus(GoodDirection.id, function(statusGoodDirection){
			getActivityStatus(projectMyselfMyCardRoutesPage2.id, function(statusMyCardRoutes2){
				if(statusMyCardRoutes2){
					$("#projectMyself_2_status").html(statusMyCardRoutes2);
				}else{
					if(statusGoodDirection){
						$("#projectMyself_2_status").html(statusGoodDirection);
					}else{
						if(statusMyCardRoutes){
							$("#projectMyself_2_status").html(statusMyCardRoutes);
						}else{
							$("#projectMyself_2_status").html(SCREEN_STATUS_LOCKED);
						}
					}
				}
			});
		});
	});
	
		getActivityStatus(projectMyselfFisrtStepAction.id, function(statusFisrtStepAction){
			getActivityStatus(projectMyselfFisrtStep.id, function(statusFisrtStep){
				if(statusFisrtStepAction){
					$("#projectMyself_3_status").html(statusFisrtStepAction);
				}else{
					if(statusFisrtStep){
						$("#projectMyself_3_status").html(statusFisrtStep);
					}else{
						$("#projectMyself_3_status").html(SCREEN_STATUS_LOCKED);
					}
				}
				
			});
		});
	});


	$("#projectMyself_summary_stage_1").on("click", function(e) {
		$.mobile.changePage('#' + projectMyselfGetTheFactsPage.id);
		//projectMyselfInFiveYearsPage
		//projectMyselfInFiveYears2Page
	});
		
	$("#projectMyself_summary_stage_2").on("click", function(e) {
		getActivityStatus(projectMyselfMyCardRoutesPage.id, function(statusMyCardRoutes){
			getActivityStatus(GoodDirection.id, function(statusGoodDirection){
				getActivityStatus(projectMyselfMyCardRoutesPage2.id, function(statusMyCardRoutes2){
					if(statusMyCardRoutes2 && (statusMyCardRoutes2 == SCREEN_STATUS_ACCESSIBLE || statusMyCardRoutes2 == SCREEN_STATUS_IN_PROGRESS)){
						$.mobile.changePage('#' + projectMyselfMyCardRoutesPage2.id);
					}else{
						if(statusGoodDirection && (statusGoodDirection == SCREEN_STATUS_ACCESSIBLE || statusGoodDirection == SCREEN_STATUS_IN_PROGRESS)){
							$.mobile.changePage('#' + GoodDirection.id);
						}else{
							if(statusMyCardRoutes && (statusMyCardRoutes == SCREEN_STATUS_ACCESSIBLE || statusMyCardRoutes == SCREEN_STATUS_IN_PROGRESS)){
								$.mobile.changePage('#' + projectMyselfMyCardRoutesPage.id);
							}else{
								if(statusMyCardRoutes2 == SCREEN_STATUS_FINISHED) $.mobile.changePage('#' + projectMyselfMyCardRoutesPage2.id);
							}
						}
					}
				});
			});
		});
		
	});
	
	$("#projectMyself_summary_stage_3").on("click", function(e) {
		getActivityStatus(projectMyselfFisrtStepAction.id, function(statusFisrtStepAction){
			getActivityStatus(projectMyselfFisrtStep.id, function(statusFisrtStep){
				
				if(statusFisrtStepAction && (statusFisrtStepAction == SCREEN_STATUS_ACCESSIBLE || statusFisrtStepAction == SCREEN_STATUS_IN_PROGRESS)){
					$.mobile.changePage('#' + projectMyselfFisrtStepAction.id);
				}else{
					if(statusFisrtStep && (statusFisrtStep == SCREEN_STATUS_ACCESSIBLE || statusFisrtStep == SCREEN_STATUS_IN_PROGRESS)){
						$.mobile.changePage('#' + projectMyselfFisrtStep.id);
					}else{
						if(statusFisrtStepAction == SCREEN_STATUS_FINISHED) $.mobile.changePage('#' + projectMyselfFisrtStep.id);
					}
				}
				
			});
		});
	});
	

