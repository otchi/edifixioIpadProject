
/* JavaScript content from js/projectMyself/inFiveYears2.js in folder common */

$(document).on("pagebeforeshow", "#" + projectMyselfInFiveYears2Page.id, function(event) {
	
	getAllInFiveYearsImages(function(imagesMap) {
		for(var i=0;i<imagesMap.length;i++ ){
			var liste = new Array();
			liste = imagesMap[i];
			var image = document.createElement("img");	
			image.setAttribute("src","data:image/jpeg;base64," + liste[1]);
			$('#InFiveYears2_picture_'+liste[0]).empty();
			document.getElementById('InFiveYears2_picture_'+liste[0]).appendChild(image);	
			$('#'+projectMyselfInFiveYears2Page.id +' img').css("width","150px");
			$('#'+projectMyselfInFiveYears2Page.id +' img').css("height","150px");					
		
		}
	});
	
	getInprojectMyselfKey("WishInFiveYears", function(valueWish){
		if(valueWish){
			$('#'+projectMyselfInFiveYears2Page.id + ' [data-id ="WishInFiveYears"]').html(valueWish);	
			toggleEnabling('#'+projectMyselfInFiveYears2Page.id + ' button',valueWish.length==0);
		}
	});
});

$('#' + projectMyselfInFiveYears2Page.id+ ' [data-id =WishInFiveYears]').on("keyup", function(e) {
	var text = $(this).val();
	addInprojectMyselfKey("WishInFiveYears", $(this).val(), function (e){		 
		toggleEnabling('#'+projectMyselfInFiveYears2Page.id + ' [data-id=submit]',text.length==0);
	});
});

$('#' + projectMyselfInFiveYears2Page.id+' [data-id=submit]').on("click", function(e) {
	setActivityStatus(projectMyselfInFiveYears2Page.id, SCREEN_STATUS_FINISHED, function() {
	 	console.log('Step 2 finished');
	 	setActivityStatus(projectMyselfMyCardRoutesPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
	 		$.mobile.changePage("#" + projectMyselfSummaryPage.id); 
	 	});
	});
});


