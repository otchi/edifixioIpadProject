
/* JavaScript content from js/projectMyself/GoodDirection.js in folder common */

$(document).on("pagebeforeshow", "#" + GoodDirection.id, function(event) {
	$('#' + GoodDirection.id+' td').css("padding","10px");
	$('#' + GoodDirection.id+' td').css("border-style","solid");
	$('#' + GoodDirection.id+' td').css("border-width","1px");
	
	getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
		getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
			getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
				$("#" + GoodDirection.id + ' [data-title=sector1]').html(sector1);
				$("#" + GoodDirection.id + ' [data-title=sector2]').html(sector2);
				$("#" + GoodDirection.id + ' [data-title=sector3]').html(sector3);
			});
		});
	});
	
	getInprojectMyselfCardRoutesKey("Target",function(rowNumber){	
		$("#" + GoodDirection.id+' [data-row]').html('');
		$('[data-row='+rowNumber+']').html('cible');
	});
	
	getCompassVisionMission(function(mission){
		$("#" + GoodDirection.id +' [data-id = GoodDirectionMyMission]').val(mission);
	});
	getAllTalentIRecognize(function(talentIds) {
		var listeTalent="";
		for(var i=0;i<talentIds.length;i++){
			var talentValue = $.i18n.prop('talent.iRecognize.'+talentIds[i]);
			listeTalent =listeTalent +"  * "+  talentValue; 
		}
		$("#" + GoodDirection.id +' [data-id = GoodDirectionMyTalent]').html(listeTalent);
	});
	getImportantCriteria(function(arrayImportantCriteria) {	
		var listeValue="";
		for(var i=0;i<arrayImportantCriteria.length;i++){
			var Value = arrayImportantCriteria[i];
			listeValue = listeValue +"  * "+  Value; 
		}
		$("#" + GoodDirection.id +' [data-id = GoodDirectionMyValue]').html(listeValue);
	});
		
	getProLifeMark (function(mark){
		$('.GoodDirectionMyValue').html('note pour mes valeurs : '+$.i18n.prop('compass.Myvalue.proLifeButton.'+mark));
	});
	getMarkProLife(function(mark) {
		$('.GoodDirectionMyMission').html('note pour ma mission : '+$.i18n.prop('compass.Myvalue.proLifeButton.'+mark));
	});
});

$('#'+GoodDirection.id +' button').on("click", function(e) {
	var valueClass = $(this).attr('data-type');
	var labelMark = $(this).attr('data-id');
	if(labelMark=='not') $('.'+valueClass).html($.i18n.prop('compass.Myvalue.proLifeButton.1'));
	if(labelMark=='little') $('.'+valueClass).html($.i18n.prop('compass.Myvalue.proLifeButton.2'));
	if(labelMark=='much') $('.'+valueClass).html($.i18n.prop('compass.Myvalue.proLifeButton.3'));
	if(labelMark=='Entirely') $('.'+valueClass).html($.i18n.prop('compass.Myvalue.proLifeButton.4'));
});

$('#'+GoodDirection.id +' button[data-class=validate]').on("click", function(e) {
	setActivityStatus(GoodDirection.id, SCREEN_STATUS_FINISHED, function(){
		setActivityStatus(projectMyselfMyCardRoutesPage2.id, SCREEN_STATUS_ACCESSIBLE, function(){
			$.mobile.changePage("#" + projectMyselfMyCardRoutesPage2.id);
		});
	});
});

$('#'+GoodDirection.id +' button[data-class=cancel]').on("click", function(e) {
	setActivityStatus(projectMyselfMyCardRoutesPage.id, SCREEN_STATUS_ACCESSIBLE, function(){
		setActivityStatus(GoodDirection.id, SCREEN_STATUS_LOCKED, function(){
			$.mobile.changePage("#" + projectMyselfMyCardRoutesPage.id);
		});
	});
});


	


