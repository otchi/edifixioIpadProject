
/* JavaScript content from js/projectMyself/CardRoutesPage_step2.js in folder common */

var typeButton = null;
var listeTd = new Array();
$(document).on("pagebeforeshow", "#" + projectMyselfMyCardRoutesPage2.id, function(event) {
	

	getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
		getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
			getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
				$("#" + projectMyselfMyCardRoutesPage2.id + ' .myCardRoutesService1').html(sector1);
				$("#" + projectMyselfMyCardRoutesPage2.id + ' .myCardRoutesService2').html(sector2);
				$("#" + projectMyselfMyCardRoutesPage2.id + ' .myCardRoutesService3').html(sector3);
			});
		});
	});
	
	getInprojectMyselfCardRoutesKey("Target",function(rowNumber){	
		$("#" + projectMyselfMyCardRoutesPage2.id+' [data-row='+rowNumber+']').html('cible');
		listeTd.push(rowNumber);
	});
	getInprojectMyselfCardRoutesKey("maternity", function(value){
		if(value){
			listeTd.push(value);
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-id= maternity]').attr('disabled','disabled');
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.maternity'));
		}
	});
	getInprojectMyselfCardRoutesKey("formation", function(value){
		if(value){
			listeTd.push(value);
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-id= formation]').attr('disabled','disabled');
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.formation'));
		}
	});
	getInprojectMyselfCardRoutesKey("others", function(value){
		if(value){
			listeTd.push(value);
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-id= others]').attr('disabled','disabled');
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.others'));
		}
	});
	getInprojectMyselfCardRoutesKey("internationalMission", function(value){
		if(value){
			listeTd.push(value);
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-id= internationalMission]').attr('disabled','disabled');
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.internationalMission'));
		}
	});
	getActivityStatus(projectMyselfMyCardRoutesPage2.id, function(status){
		if(status && status == SCREEN_STATUS_FINISHED){
			toggleEnabling('#'+projectMyselfMyCardRoutesPage2.id +' [data-id = maternity]', true);
			toggleEnabling('#'+projectMyselfMyCardRoutesPage2.id +' [data-id = formation]', true);
			toggleEnabling('#'+projectMyselfMyCardRoutesPage2.id +' [data-id = others]', true);
			toggleEnabling('#'+projectMyselfMyCardRoutesPage2.id +' [data-id = internationalMission]', true);
			toggleVisibility('#'+projectMyselfMyCardRoutesPage2.id +' [data-class = validate]', false);
			$('#'+projectMyselfMyCardRoutesPage2.id +' [data-class = next]').removeAttr('style');
		}
	});
});

$('#'+projectMyselfMyCardRoutesPage2.id +' button').on("click", function(e) {
	
	typeButton = $(this).attr('data-id');
	if(typeButton){
		$('#'+projectMyselfMyCardRoutesPage2.id+' button').removeAttr('style');
		$(this).css('color','white');
		$(this).css('background-color','rgb(100, 149, 237)');
	}
	
});

$('#'+projectMyselfMyCardRoutesPage2.id +' .row').on("click", function(e) {
	var value = $(this).attr('data-row');
	if(typeButton && !listeTd.contains(value)){
		addInprojectMyselfCardRoutesKey(typeButton, value, function(){
			setActivityStatus(projectMyselfMyCardRoutesPage2.id, SCREEN_STATUS_IN_PROGRESS, function(){
				$('#'+projectMyselfMyCardRoutesPage2.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.'+typeButton));
				$('#'+projectMyselfMyCardRoutesPage2.id +' [data-id='+typeButton+']').attr('disabled','disabled');
				$('#'+projectMyselfMyCardRoutesPage2.id+' button').removeAttr('style');
				typeButton = null;
				listeTd.push(value);
			});
		});
	}
});

$('#'+projectMyselfMyCardRoutesPage2.id +' [data-class=validate]').on("click", function(e) {
	setActivityStatus(projectMyselfMyCardRoutesPage2.id, SCREEN_STATUS_FINISHED, function(){
		setActivityStatus(projectMyselfFisrtStep.id, SCREEN_STATUS_ACCESSIBLE, function(){
			$.mobile.changePage("#" + projectMyselfSummaryPage.id);
		});
	});
});

$('#'+projectMyselfMyCardRoutesPage2.id +' [data-class= next ]').on("click", function(e) {
	$.mobile.changePage("#" + projectMyselfSummaryPage.id);
});
