
/* JavaScript content from js/projectMyself/fisrtStep.js in folder common */
var nombreInputAction= 4;

$(document).on("pagebeforeshow", "#" + projectMyselfFisrtStep.id, function(event) {
	projectMyself_fisrtStep_SetScreenState(true);
});

$("#" + projectMyselfFisrtStep.id + ' textarea').on("keyup", function(e) {
	projectMyself_fisrtStep_addAction();
});

$("#" + projectMyselfFisrtStep.id +' [data-id=addPassion]').on("click", function(e) {
	projectMyself_fisrtStep_addActionEvent();
});

$("#" + projectMyselfFisrtStep.id +' [data-id=removePassion]').on("click", function(e) {
	projectMyself_fisrtStep_removeActionEvent();
});

$("#" + projectMyselfFisrtStep.id +' a[data-position]').on("click", function(e) {
	var positionAction = $(this).attr('data-position');
	getActivityStatus(projectMyselfFisrtStep.id, function(status){
		if( status == SCREEN_STATUS_ACCESSIBLE || status == SCREEN_STATUS_IN_PROGRESS){
			
			var labelAction = $("#" + projectMyselfFisrtStep.id +' [data-id='+positionAction+']').val();
			if(!$("#" + projectMyselfFisrtStep.id +' a[data-position='+positionAction+']').attr('disabled')){
				$("#" + projectMyselfFisrtStep.id +' textarea[data-id]').each(function() {
					 var labelAction =  $( this ).val().trim();
					 var positionAction =  $( this ).attr('data-id');
					 if(labelAction) projectMyself_firstStep_setAction("action", positionAction, labelAction);
				});
				projectMyself_firstStep_setKey("actionSelected", positionAction, function(){
					projectMyself_firstStep_setKey("actionlabel", labelAction , function(){
						projectMyself_firstStep_setKey("nombreInputAction", nombreInputAction,function(){
							setActivityStatus(projectMyselfFisrtStep.id, SCREEN_STATUS_FINISHED, function(){
								setActivityStatus(projectMyselfFisrtStepAction.id, SCREEN_STATUS_ACCESSIBLE, function(){
									$.mobile.changePage("#" + projectMyselfFisrtStepAction.id);
								});
							});
						});
					});
				});
			}
		}
	});
	
});

$("#" + projectMyselfFisrtStep.id +' [data-id=next]').on("click", function(e) {
	$.mobile.changePage("#" + projectMyselfFisrtStepAction.id);
});

function projectMyself_fisrtStep_SetScreenState (state){
	if(state){
		getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
			getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
				getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
					$("#" + projectMyselfFisrtStep.id + ' .myCardRoutesService1').html(sector1);
					$("#" + projectMyselfFisrtStep.id + ' .myCardRoutesService2').html(sector2);
					$("#" + projectMyselfFisrtStep.id + ' .myCardRoutesService3').html(sector3);
				});
			});
		});
		
		getInprojectMyselfCardRoutesKey("Target",function(rowNumber){	
			$("#" + projectMyselfFisrtStep.id+' [data-row='+rowNumber+']').html('cible');
			listeTd.push(rowNumber);
		});
		getInprojectMyselfCardRoutesKey("maternity", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStep.id +' [data-id= maternity]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStep.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.maternity'));
			}
		});
		getInprojectMyselfCardRoutesKey("formation", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStep.id +' [data-id= formation]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStep.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.formation'));
			}
		});
		getInprojectMyselfCardRoutesKey("others", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStep.id +' [data-id= others]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStep.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.others'));
			}
		});
		getInprojectMyselfCardRoutesKey("internationalMission", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStep.id +' [data-id= internationalMission]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStep.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.internationalMission'));
			}
		});
		projectMyself_fisrtStep_addAction();
		projectMyself_firstStep_getKey("nombreInputAction", function(nombreInput){
			projectMyself_firstStep_getKey("actionSelected", function(actionSelected){
				projectMyself_firstStep_getAction("action", function(listeAction){
					nombreInputAction = nombreInput;
					$('#'+projectMyselfFisrtStep.id+ ' textarea[data-id]').attr('disabled','disabled');
					$('#'+projectMyselfFisrtStep.id+ ' a[data-position]').css('display','none');
					$('#'+projectMyselfFisrtStep.id+ ' a[data-position='+actionSelected+']').css('display','block');
					$('#'+projectMyselfFisrtStep.id+ ' [data-id=next]').css('display','block');
					
					for(var i = 0; i < nombreInput-1; i++){
						$('#'+projectMyselfFisrtStep.id+ ' textarea[data-id='+listeAction[i][0]+']').val(listeAction[i][1]);
						$('#'+projectMyselfFisrtStep.id+ ' textarea[data-id='+listeAction[i][0]+']').css('display','block');
					}
				}, null);
			}, null);
		}, null);
		
	}
	
}

function projectMyself_fisrtStep_removeActionEvent(){
	nombreInputAction --;
	console.log(nombreInputAction);
	$("#" + projectMyselfFisrtStep.id +' [data-id='+nombreInputAction+']').val("");
	$("#" + projectMyselfFisrtStep.id +' [data-id='+nombreInputAction+']').css('display','none');
	$("#" + projectMyselfFisrtStep.id +' [data-position='+nombreInputAction+']').css('display','none');
	if(nombreInputAction == 4) 
		$("#" + projectMyselfFisrtStep.id +' [data-id=removePassion]').css('display','none');
}


function projectMyself_fisrtStep_addActionEvent(){
	//toggleVisibility('#sayI_passion_step1_left_validation', false);
	$("#" + projectMyselfFisrtStep.id +' [data-id=removePassion]').css('display','block');
	$("#" + projectMyselfFisrtStep.id +' [data-id='+nombreInputAction+']').css('display','block');
	$("#" + projectMyselfFisrtStep.id +' [data-position='+nombreInputAction+']').css('display','block');
	$("#" + projectMyselfFisrtStep.id +' [data-id=addPassion]').css('display','none');
	nombreInputAction ++;
}

function projectMyself_fisrtStep_addAction(){
	
	var addPassion = true;
	for(var i = 1; i < nombreInputAction;i++){
		var inputCurrent = ($("#" + projectMyselfFisrtStep.id + ' [data-id='+i+']').val()).trim();
		if( inputCurrent.length == 0 ) addPassion = false;
		}
	if(addPassion){
		//toggleVisibility('#sayI_passion_step1_left_validation', true);
		$('#'+ projectMyselfFisrtStep.id +' a[data-position]').removeAttr('disabled');
		if (nombreInputAction!=11) $("#" + projectMyselfFisrtStep.id +' [data-id=addPassion]').css('display','block');
		else $("#" + projectMyselfFisrtStep.id +' [data-id=addPassion]').css('display','none');
	}else{
		$('#'+ projectMyselfFisrtStep.id +' a[data-position]').attr('disabled','disabled');
		//toggleVisibility('#sayI_passion_step1_left_validation', false);
		$("#" + projectMyselfFisrtStep.id +' [data-id=addPassion]').css('display','none');
	}
	
}