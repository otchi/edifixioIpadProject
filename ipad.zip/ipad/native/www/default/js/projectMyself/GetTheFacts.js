
/* JavaScript content from js/projectMyself/GetTheFacts.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + projectMyselfGetTheFactsPage.id, function(event) {
	
	getCompassVisionMission(function(mission){
		$("#" + projectMyselfGetTheFactsPage.id +' [data-id = GetTheFactsMyMission]').val(mission);
	});
	getAllTalentIRecognize(function(talentIds) {
		var listeTalent="";
		for(var i=0;i<talentIds.length;i++){
			var talentValue = $.i18n.prop('talent.iRecognize.'+talentIds[i]);
			listeTalent =listeTalent +"  * "+  talentValue; 
		}
		$("#" + projectMyselfGetTheFactsPage.id +' [data-id = GetTheFactsMyTalent]').html(listeTalent);
	});
	getImportantCriteria(function(arrayImportantCriteria) {	
		var listeValue="";
		for(var i=0;i<arrayImportantCriteria.length;i++){
			var Value = arrayImportantCriteria[i];
			listeValue = listeValue +"  * "+  Value; 
		}
		$("#" + projectMyselfGetTheFactsPage.id +' [data-id = GetTheFactsMyValue]').html(listeValue);
	});
});

//Add click event on button
$('#'+projectMyselfGetTheFactsPage.id +' button').on("click", function(e) {
	setActivityStatus(projectMyselfGetTheFactsPage.id, SCREEN_STATUS_FINISHED, function(){
		setActivityStatus(projectMyselfInFiveYearsPage.id, SCREEN_STATUS_ACCESSIBLE, function(){
			$.mobile.changePage("#" + projectMyselfInFiveYearsPage.id);
		});
	});
});