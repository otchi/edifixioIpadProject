
/* JavaScript content from js/projectMyself/inFiveYears.js in folder common */

var imageNumberProjectMySelf = 0;

$(document).on("pagebeforeshow", "#" + projectMyselfInFiveYearsPage.id, function(event) {
	//toggleEnabling('#'+projectMyselfInFiveYearsPage.id+' button',true);
	getAllInFiveYearsImages(function(imagesMap) {
		
		for(var i=0;i<imagesMap.length;i++ ){
			var liste = new Array();
			liste = imagesMap[i];	
			var image = document.createElement("img");
			image.classList.add("VisionImage");	
			image.setAttribute("src","data:image/jpeg;base64," + liste[1]);
			$('#InFiveYears_picture_'+liste[0]).empty();
			document.getElementById('InFiveYears_picture_'+liste[0]).appendChild(image);	
			$('#'+projectMyselfInFiveYearsPage.id +' img').css("width","200px");
			$('#'+projectMyselfInFiveYearsPage.id +' img').css("height","200px");							
		}
	});	
});


$("#InFiveYears_picture_button_1").on("click", function(e) {
	$("#InFiveYears_picture_file_1").click();	
});
$("#InFiveYears_picture_button_2").on("click", function(e) {
	$("#InFiveYears_picture_file_2").click();	
});
$("#InFiveYears_picture_button_3").on("click", function(e) {
	$("#InFiveYears_picture_file_3").click();	
});
$("#InFiveYears_picture_button_4").on("click", function(e) {
	$("#InFiveYears_picture_file_4").click();	
});
$("#InFiveYears_picture_button_5").on("click", function(e) {
	$("#InFiveYears_picture_file_5").click();	
});
$("#InFiveYears_picture_button_6").on("click", function(e) {
	$("#InFiveYears_picture_file_6").click();	
});


$("#" + projectMyselfInFiveYearsPage.id +' [data-id=capturePicture]').on("click", function(e) {
	imageNumberProjectMySelf = $(this).attr("data-image");
	Camera.PictureSourceType.PHOTOLIBRARY;
    navigator.camera.getPicture(uploadPhoto2,null,{sourceType:0,quality:60,destinationType:0});
});

function uploadPhoto2(data){
		
		addImageTable(imageNumberProjectMySelf,data, function() {
			var image = document.createElement("img");
			image.classList.add("VisionImage");	
			image.setAttribute("src","data:image/jpeg;base64," + data);
			$('#InFiveYears_picture_'+imageNumberProjectMySelf).empty();
			document.getElementById('InFiveYears_picture_'+imageNumberProjectMySelf).appendChild(image);	
			$('#'+projectMyselfInFiveYearsPage.id +' img').css("width","200px");
			$('#'+projectMyselfInFiveYearsPage.id +' img').css("height","200px");
			//getAllInFiveYearsImages(function(imagesMap) {
				//if(imagesMap.length == 6){toggleEnabling('#'+projectMyselfInFiveYearsPage.id+' button',false);}		
			});
		
}





//Add click event on button
$('#'+projectMyselfInFiveYearsPage.id +' [data-id=submit]').on("click", function(e) {
	setActivityStatus(projectMyselfInFiveYearsPage.id, SCREEN_STATUS_FINISHED, function(){
		setActivityStatus(projectMyselfInFiveYears2Page.id, SCREEN_STATUS_ACCESSIBLE, function(){
			$.mobile.changePage("#" + projectMyselfInFiveYears2Page.id);
		});
	});
	
				
});
