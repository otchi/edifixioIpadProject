
/* JavaScript content from js/projectMyself/fisrtStepAction.js in folder common */

$(document).on("pagebeforeshow", "#" + projectMyselfFisrtStepAction.id, function(event) {
	projectMyself_fisrtStepAction_SetScreenState(true);
});

$("#" + projectMyselfFisrtStepAction.id+' [data-class=firstStepAction_date]').on("click", function(e) {
	$(this).datebox('open');
});

//When a date is selected in the datebox, insert it in db
$("#" + projectMyselfFisrtStepAction.id+' [data-class=firstStepAction_date]').bind('datebox', function(e, p) {
	if (p.method === 'close') {
		var dateString = $(this).val();
		setActivityStatus(projectMyselfFisrtStepAction.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log(projectMyselfFisrtStepAction.id + " is now in progress");
		});
		if (!isBlank(dateString)) {
			var selectedDate = $(this).datebox('getTheDate');
			setCalendarDate("#" + projectMyselfFisrtStepAction.id, selectedDate, "date "+ projectMyselfFisrtStepAction.id , function(){
				projectMyself_firstStepAction_setDate("firstStepAction_date",selectedDate, function() {
					projectMyself_fisrtStepAction_verifInformation();
	 			});	 
			});
		}	 		
	}
});	


$("#" + projectMyselfFisrtStepAction.id+' textarea[data-class]').on("keyup", function(e) {
	
	var value = $(this).val().trim();
	var key = $(this).attr('data-class');
	setActivityStatus(leadershipfeelingPage.id, SCREEN_STATUS_IN_PROGRESS, function(){
		if((value)||(value.length == 0))
			if(value.length == 0){
				projectMyself_firstStepAction_deleteKey(key, function(){
					projectMyself_fisrtStepAction_verifInformation();
				});
			}
			else {
				projectMyself_firstStepAction_setKey(key,value,function(){
					projectMyself_fisrtStepAction_verifInformation();
				});
			}
	});
});

$("#" + projectMyselfFisrtStepAction.id+' [data-id=validate]').on("click", function(e) {
	projectMyself_firstStepAction_setKey("firstStepAction_validate","true", function(){
		setActivityStatus(projectMyselfFisrtStepAction.id, SCREEN_STATUS_FINISHED, function(){
			$("#" + projectMyselfFisrtStepAction.id+' [data-class]').attr('disabled','disabled');
			$("#" + projectMyselfFisrtStepAction.id+' [data-id= validate]').css('display','none');
			$("#" + projectMyselfFisrtStepAction.id+' [data-id= next]').css('display','block');
			$.mobile.changePage("#" + projectMyselfSummaryPage.id);
		});
	});
});


$("#" + projectMyselfFisrtStepAction.id+' [data-id = next]').on("click", function(e) {
	$.mobile.changePage("#" + projectMyselfSummaryPage.id);
});

function projectMyself_fisrtStepAction_verifInformation(){
	$("#" + projectMyselfFisrtStepAction.id+' [data-class]').each(function( ) {
		console.log($(this).val().trim());
		if($(this).val().trim().length == 0) toggleEnabling($('#' + projectMyselfFisrtStepAction.id + ' [data-id=validate]'), true);
		else toggleEnabling($('#' + projectMyselfFisrtStepAction.id + ' [data-id=validate]'), false);
	});
}
function projectMyself_fisrtStepAction_SetScreenState (state){
	if(state){
		toggleEnabling($('#' + leadershipfeelingPage.id + ' [data-class=validate]'), true);
		getInprojectMyselfCardRoutesKey("Sector1", function(sector1){
			getInprojectMyselfCardRoutesKey("Sector2", function(sector2){
				getInprojectMyselfCardRoutesKey("Sector3", function(sector3){
					$("#" + projectMyselfFisrtStepAction.id + ' .myCardRoutesService1').html(sector1);
					$("#" + projectMyselfFisrtStepAction.id + ' .myCardRoutesService2').html(sector2);
					$("#" + projectMyselfFisrtStepAction.id + ' .myCardRoutesService3').html(sector3);
					projectMyself_fisrtStepAction_verifInformation();
				});
			});
		});
		
		getInprojectMyselfCardRoutesKey("Target",function(rowNumber){	
			$("#" + projectMyselfFisrtStepAction.id+' [data-row='+rowNumber+']').html('cible');
			listeTd.push(rowNumber);
		});
		getInprojectMyselfCardRoutesKey("maternity", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStepAction.id +' [data-id= maternity]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStepAction.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.maternity'));
			}
		});
		getInprojectMyselfCardRoutesKey("formation", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStepAction.id +' [data-id= formation]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStepAction.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.formation'));
			}
		});
		getInprojectMyselfCardRoutesKey("others", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStepAction.id +' [data-id= others]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStepAction.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.others'));
			}
		});
		getInprojectMyselfCardRoutesKey("internationalMission", function(value){
			if(value){
				listeTd.push(value);
				$('#'+projectMyselfFisrtStepAction.id +' [data-id= internationalMission]').attr('disabled','disabled');
				$('#'+projectMyselfFisrtStepAction.id +' [data-row='+value+']').html($.i18n.prop('projectMyself.myCardRoutes.internationalMission'));
			}
		});
		
		projectMyself_firstStep_getKey("actionlabel", function(actionlabel){
			$('#'+projectMyselfFisrtStepAction.id +' [data-class=firstStepAction_labelAction]').val(actionlabel);
		}, null);
		projectMyself_firstStepAction_getDate("firstStepAction_date", function(selectedDate){
			$("#" + projectMyselfFisrtStepAction.id+' [data-class=firstStepAction_date]').datebox("setTheDate", selectedDate);
		}, function(){
			console.log('date is not setted yett');
		});
		projectMyself_firstStepAction_getKey("firstStepAction_labelWhere", function(value){
			$("#" + projectMyselfFisrtStepAction.id+' [data-class=firstStepAction_labelWhere]').html(value);
		}, function(){
			console.log('labelWhere is not setted yet');
		});
		projectMyself_firstStepAction_getKey("firstStepAction_labelFirstStep", function(value){
			$("#" + projectMyselfFisrtStepAction.id+' [data-class=firstStepAction_labelFirstStep]').html(value);
		}, function(){
			console.log('labelFirstStep is not setted yet');
		});
		projectMyself_firstStepAction_getKey("firstStepAction_validate", function(value){
			$("#" + projectMyselfFisrtStepAction.id+' [data-class]').attr('disabled','disabled');
			$("#" + projectMyselfFisrtStepAction.id+' [data-id= validate]').css('display','none');
			$("#" + projectMyselfFisrtStepAction.id+' [data-id= next]').css('display','block');
		}, function(){
			console.log('firstStepActionis is not validated');
		});
		
	}
}


