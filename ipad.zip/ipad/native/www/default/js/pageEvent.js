
/* JavaScript content from js/pageEvent.js in folder common */
// for each page seen, set active page id into database
function addPageEvents() {
	$(document).on("pagebeforeshow", function(event) {
		var activePage = $.mobile.activePage;

		if (activePage) {
			var activePageId = activePage.attr("id");

			if (activePageId && activePageId != "") {
				showEditoPopup(activePageId);
				showHelpPanel(activePageId);
				insertSeenPageId(activePageId);
				setLastSeenPageId(activePageId);
			} else {
				console.log("the active page id is blank");
			}
		} else {
			console.log("unable to retrieve the active page");
		}
	});
}

// Show help panel when open first time
function showHelpPanel(activePageId) {
	console.log("showHelpPanel entering");

	hasBeenSeen(activePageId, null, function() {
		console.log(activePageId + "has never been seen");
		var page = pageMap[activePageId];

		// if first time seen page and page has help panel --> open help panel
		if (page.hasHelpText && $("#" + page.id + helpPanelId).size() > 0) {
			$("#" + page.id + helpPanelId).panel("open");
		}
	});
}

// Show edito popup when open first time
function showEditoPopup(activePageId) {
	console.log("showEditoPopup entering");

	hasBeenSeen(activePageId, null, function() {
		console.log(activePageId + " has never been seen");
		var page = pageMap[activePageId];

		// if first time seen page and page has edito popup --> open edito popup
		if (page.hasEditoText && $("#" + page.id + EDITO_POPUP_DIV_ID).size() > 0) {
			console.log("display edito");
			$("#" + page.id + EDITO_POPUP_DIV_ID).popup("open");
		}
	});
}