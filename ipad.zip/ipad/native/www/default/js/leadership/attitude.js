
/* JavaScript content from js/leadership/attitude.js in folder common */
$('#'+leadershipAttitudePage.id+' button[data-class=finish]').on("click", function(e) {
	setActivityStatus(leadershipAttitudePage.id, SCREEN_STATUS_FINISHED, function(){
		set_Status_Progression("leadership_progression", 87, function(){
			setActivityStatus(leadershipMarkAttitudePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
				$.mobile.changePage("#" + leadershipMarkAttitudePage.id);
			});
		});
	});
});

$('#'+leadershipAttitudePage.id+' button[data-class=next]').on("click", function(e) {
	$.mobile.changePage("#" + leadershipMarkAttitudePage.id);
});
$(document).on("pagebeforeshow", "#" + leadershipAttitudePage.id, function(event) {
	getActivityStatus(leadershipAttitudePage.id, function(status){
		if(status == SCREEN_STATUS_FINISHED){
			$("#" + leadershipAttitudePage.id+ " button[data-class=next]").css('display','block');
			$("#" + leadershipAttitudePage.id+ " button[data-class=finish]").css('display','none');
		}
	});
	
});