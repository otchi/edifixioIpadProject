
/* JavaScript content from js/leadership/stereotype.js in folder common */
const PREFIX_KEY_ID = "response_stereotype";
const STEREOTYPE_PROGRESS = "progress_stereotype";


$(document).on('pagebeforeshow', '#' + leadershipStereotypePage.id, function(event) {
	
	$( "#" + leadershipStereotypePage.id+" #stereotypeLeadership").load("pages/leadership/stereotype_design.html",function(){

		//-----------------------------------------------------------------------------------------------
		
		//-----------------------------------------------------------------------------------------------
	    const MAIN_CONTENT=$("#"+leadershipStereotypePage.id);
	    // prefix to recovere question radio state
	    const PREFIX_RADIO_ID = "leadership-et-stereotypes-2-radio-";
	    // question input div
	    const QUESTION_INPUT = MAIN_CONTENT.find(".radio").find("[type=radio]");
	    // question text
	    const QUESTION_TEXT= MAIN_CONTENT.find(".question-stereotype");
	    const DISPLAY_QUESTION = QUESTION_TEXT.css('display');
	    //Button to validate response
	    const VALIDATION_BUTTON = MAIN_CONTENT.find("#validation-stereotype-response");
	    const DASHBOARD= MAIN_CONTENT.find('#back-dashboard');
	    // question nuumber in activity
	    const QUESTION_STEREOTYPE_COUNT = QUESTION_TEXT.length;
	    
	    set_stereotype_progress(0,function (){console.log('reset');});
	    
//	    MAIN_CONTENT.find("[name=leadership-et-stereotypes-2-radio]").on('click',function(){
//	   
//	    	MAIN_CONTENT.find("[name=leadership-et-stereotypes-2-radio]").prop("checked",false);
//	    });
	    //------------------------------------------------------------------------------
	    // main data in this activity 
	    var activityData={
	      activity_progress :undefined, checked_responce : undefined   
	    };
	    //-----------------------------------------------------------------------------
	    // load the user activity data 
	    new LoadData();
	    // expect to the data loaded and trigrred the main function
	    var interval = setInterval(function (){
	        var next_state=undefined;
	        if(activityData.activity_progress == undefined) return;
	        var questionManager=new QuestionManager();
	        next_state = questionManager.next();
	        if(!next_state){
	        	questionManager.finish();
	        }
	        console.log("activityData.activity_progress:"+activityData.activity_progress);
	        
	        QUESTION_INPUT.on('click',function(){
	            VALIDATION_BUTTON.css('visibility','visible');
	            console.log(parseInt($(this).attr('id').charAt(PREFIX_RADIO_ID.length))-3);
	            activityData.checked_responce = parseInt($(this).attr('id').charAt(PREFIX_RADIO_ID.length))-3;
	        });
	        
	        VALIDATION_BUTTON.on('click',function(){
	            questionManager.savaData();
	            next_state = questionManager.next();
	            if(!next_state){
	            	 questionManager.finish();
	            }
	        });
	        
	        DASHBOARD.on('click',function(){
	            set_stereotype_progress(activityData.activity_progress-1,function(){console.log('finish');})
	            set_stereotype_response(activityData.activity_progress,activityData.checked_responce,
	                        function(){
	                            console.log("save:"+activityData.activity_progress+"/"+activityData.checked_responce);
	            });
	            console.log('redirect');//redirect
	            $.mobile.changePage("#"+ dashBoardPage.id);
	        });
	        
	        clearInterval(interval);
	    },10);
	    //--------------------------------------------------------------------------------
	    // function to load the activity data
	    function LoadData(){
	        
	        get_stereotype_progress(
	            function(value){
	                activityData.activity_progress=parseInt(value);
	                console.log("activityData.activity_progress:"+activityData.activity_progress);
	            },
	            function(){
	                activityData.activity_progress=0;
	                console.log("no progression");
	            });
	    }
	    //------------------------------------------------------------------------------------
	    //question manager to change question and save data 
	    function QuestionManager(){
	        QUESTION_TEXT.css('display','none');
	    }
	    
	    QuestionManager.prototype={
	    		
	        finish:function(){
	        	activityData.activity_progress=-1;
	        	set_stereotype_progress(activityData.activity_progress,function(){console.log('finish');});
	        	console.log("redirect "); //redirect
	        	set_stereotype_count(QUESTION_STEREOTYPE_COUNT,function(){return;});
	        	$.mobile.changePage("#"+ leadershipStereotypeConclusionPage.id);
	        },
	    	savaData : function(){
	            set_stereotype_response(activityData.activity_progress-1,
	                                    activityData.checked_responce,
	                function(){
	                    console.log("save num:"+activityData.activity_progress+"-->"+activityData.checked_responce);
	                
	            });
	        }, 
	        next : function(){
	        	
	            console.log("activityData.activity_progress:"+activityData.activity_progress);
	            console.log("QUESTION_STEREOTYPE_COUNT :"+QUESTION_STEREOTYPE_COUNT );
	            if( activityData.activity_progress < 0 ||  activityData.activity_progress >= QUESTION_STEREOTYPE_COUNT ) return false;
	            
	            MAIN_CONTENT.find("[name=leadership-et-stereotypes-2-radio]").prop("checked",false);
	            
	            if( activityData.activity_progress!=0){
					MAIN_CONTENT.find("#question-stereotype-"+(activityData.activity_progress-1))
	                            .css('display','none');
				}
				
	            MAIN_CONTENT.find("#question-stereotype-"+activityData.activity_progress)
	                        .find(".question-stereotype")
	                        .css('display',DISPLAY_QUESTION);
	            
				MAIN_CONTENT.find("#num-streotype-question")
	                        .text((activityData.activity_progress+1)+"/"+QUESTION_STEREOTYPE_COUNT);
	            
	            get_stereotype_response(activityData.activity_progress,function(valueReturn){
					console.log("value stereotype response : "+valueReturn);
					activityData.checked_responce= parseInt(valueReturn);
					MAIN_CONTENT.find("#"+PREFIX_RADIO_ID + (3 + activityData.checked_responce)).prop("checked", true);
				},function(){
					VALIDATION_BUTTON.css('visibility','hidden');
					console.log("no data");
				});
	            
	            activityData.activity_progress++;
	            return true;
	        }
	    }
		
	});
});
//-----------------------------------------------------------------------------------------------
function get_stereotype_response(question_num,callbackTrue,callbackFalse){
	console.log('get_stereotype_response:'+ question_num);
	leadership_stereotype_getKey(PREFIX_KEY_ID+question_num,callbackTrue,callbackFalse);
};

function set_stereotype_response(question_num,value,callback){
	leadership_stereotype_setKey(PREFIX_KEY_ID+question_num,value,callback);
};

function get_stereotype_progress(callbackTrue,callbackFalse){
	leadership_stereotype_getKey(STEREOTYPE_PROGRESS, callbackTrue, callbackFalse);
};

function set_stereotype_progress(value,callback){
	leadership_stereotype_setKey(STEREOTYPE_PROGRESS, value, callback);
};

function set_stereotype_count(value,callback){
	leadership_stereotype_setKey("count_stereotype", value, callback);
};

function get_stereotype_count(callbackTrue,callbackFalse){
	leadership_stereotype_getKey("count_stereotype", callbackTrue, callbackFalse);
};


