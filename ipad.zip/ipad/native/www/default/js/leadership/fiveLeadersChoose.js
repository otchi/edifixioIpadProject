
/* JavaScript content from js/leadership/fiveLeadersChoose.js in folder common */

$(document).on("pagebeforeshow", "#" + leadershipFiveLeadersChoosePage.id, function(event) {
	get_Status_Progression(PROGRESS_STAPE_1, function(progress){
		if(progress<1){
			set_Status_Progression(PROGRESS_STAPE_1, 1,function(){});
			}
		},
		function(){
			set_Status_Progression(PROGRESS_STAPE_1, 1,function(){});
		}
	);	
		
	get_Status_Progression(PROGRESS_STAPE_1, function(progress){
		console.log("leadership_activity1_progress : "+progress);
	});
	
	$( "#" + leadershipFiveLeadersChoosePage.id +' #main-content').css('display','none');
	$( "#" + leadershipFiveLeadersChoosePage.id +' #choose_fiveLeaders').load( "pages/leadership/fiveLeadersChoose_design.html",function(){
		
		
		
		translatePage(leadershipFiveLeadersChoosePage.id);
		var listeQualities = new Array();
		leadership_fiveLeaders_getKey("quality_response_1", function(values1){
			leadership_fiveLeaders_getKey("quality_response_2", function(values2){
				leadership_fiveLeaders_getKey("quality_response_3", function(values3){
					for(value in values1){
						listeQualities.push(values1[value][1]);
						listeQualities.push(values2[value][1]);
						listeQualities.push(values3[value][1]);
					}
					listeQualities.sort();
					leadership_fiveLeaders_reorganizeQualities(listeQualities,function(listeReorganized){
							var indice = 0;
							for(quality in listeReorganized){
								for(var i=0;i<listeReorganized[quality][1];i++){
									$($('#' + leadershipFiveLeadersChoosePage.id+' [data-quality='+indice+'] label')).html(unescape(listeReorganized[quality][0]));
									$($('#' + leadershipFiveLeadersChoosePage.id+' [data-quality='+indice+'] input')).attr('data-value',indice);
									$($('#' + leadershipFiveLeadersChoosePage.id+' [data-quality='+indice+'] input')).attr('data-compare',listeReorganized[quality][0]);
									indice ++;
								}
							}
							leadership_chooseQualities_getKey("quality", function(listeQualities){
								for(var j=0;j< listeQualities.length;j++ ){
									$($('#' + leadershipFiveLeadersChoosePage.id+' [data-quality='+listeQualities[j]+'] input')).attr('checked','checked');
								}
								leadership_fiveLeaders_checkbox();
							}, function(){
								$($("#" + leadershipFiveLeadersChoosePage.id+" [data-class=finish] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-off.png');
								console.log("qualities are not setted yet");
							});
					});
				}, null);
			}, null);
		}, null);
		
		$('#'+ leadershipFiveLeadersChoosePage.id+' [data-class=finish]').on("click", function(e) {
			var value = $('#'+ leadershipFiveLeadersChoosePage.id+' [data-class=finish] img').attr('src');
			if(value == "design/assets/img/block-img/ok-on.png" ){
				setActivityStatus(leadershipFiveLeadersChoosePage.id, SCREEN_STATUS_FINISHED, function() {
					set_Status_Progression("leadership_progression", 25 , function(){
						console.log(leadershipFiveLeadersChoosePage.id + ' activity is now finished');
						setActivityStatus(leadershipDevelopmentPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
							console.log(leadershipDevelopmentPage.id + ' activity is now accessible');
							// before change page storing that this activity is finished

//							if(localStorage.getItem("leadership_activity1_prograssion")==null){ // put to 0
//								localStorage.setItem("leadership_activity1_prograssion", 1);
//							}
						
							$.mobile.changePage("#" +transitionLeadership.id);
						});
					});
				});
			}else{
				console.log('please select 3 qualities');
			}
		});
		
		$('#'+ leadershipFiveLeadersChoosePage.id+' input[type=checkbox]').on("click", function(e) {
			var isSelected = $(this).is(':checked');
			var value = $(this).attr('data-value');
			setActivityStatus(leadershipFiveLeadersChoosePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				
				if(isSelected){
					leadership_chooseQualities_setKey("quality",value,escape($($('#'+ leadershipFiveLeadersChoosePage.id+' label')[value]).html()), function(){
						leadership_fiveLeaders_checkbox();
					});
				}else{
					leadership_chooseQualities_deleteKey(value, function(){
						leadership_fiveLeaders_checkbox();
					});
				}
			});
		});
		
		$('#'+ leadershipFiveLeadersChoosePage.id+' a[data-class=next]').on("click", function(e) {
			//alert(localStorage.getItem(	'leadership_activity1_prograssion'));

			$.mobile.changePage("#" + transitionLeadership.id);
		});
		
		
	});
});

function leadership_fiveLeaders_reorganizeQualities(listeQualities,callback){
	var listes = new Array();
	for(var i=0;i < listeQualities.length;i++){
		var listeValue = new Array();
		value = listeQualities[i];
		var cpt = 0;
		for(var j = i;j < listeQualities.length;j++){
			if(value == listeQualities[j]) {
				cpt++; 
				delete listeQualities[j];
			}
		}
		listeValue.push(value);
		listeValue.push(cpt);
		if(value)listes.push(listeValue);
	}
	callback(listes);
}


function leadership_fiveLeaders_checkbox (){
	getActivityStatus(leadershipFiveLeadersChoosePage.id, function(activityStatus_leadership_screen2){
		if(activityStatus_leadership_screen2 == SCREEN_STATUS_FINISHED){
			$('#'+ leadershipFiveLeadersChoosePage.id+' input' ).attr('disabled','disabled');
			$('#'+ leadershipFiveLeadersChoosePage.id+' [data-class=finish]').css('display','none');
			$('#'+ leadershipFiveLeadersChoosePage.id+' [data-class=next]').removeAttr('style');
			$( "#" + leadershipFiveLeadersChoosePage.id +' [data-link=back]').attr('href','#'+leadershipFiveLeadersPage.id) ;
		}else{
			$( "#" + leadershipFiveLeadersChoosePage.id +' [data-link=back]').attr('href','#'+dashBoardPage.id) ;
			if($('#'+ leadershipFiveLeadersChoosePage.id+'  [type=checkbox]:checked').length == 3) {
				$('#'+ leadershipFiveLeadersChoosePage.id+' input' ).attr('disabled','disabled');
				$('#'+ leadershipFiveLeadersChoosePage.id+' [type=checkbox]:checked').each(function(i) {
					$('#'+ leadershipFiveLeadersChoosePage.id+' input[data-value='+$(this).attr('data-value')+']').removeAttr('disabled');
				});
				$($("#" + leadershipFiveLeadersChoosePage.id+" [data-class=finish] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-on.png');
			}else{
				$('#'+ leadershipFiveLeadersChoosePage.id+' input' ).removeAttr('disabled');
				$($("#" + leadershipFiveLeadersChoosePage.id+" [data-class=finish] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-off.png');
				leadership_chooseQualities_getQuality(function(values){
					$('#'+ leadershipFiveLeadersChoosePage.id+' [type=checkbox]').each(function(i) {
						if(values.length == 1){
							if(($(this).attr('data-value') != values[0][0]) && ($(this).attr('data-compare') == values[0][1])){
								$(this).attr('disabled','disabled');
							}
						}else{
							if((($(this).attr('data-value') != values[0][0]) && ($(this).attr('data-compare') == values[0][1]))||
							(($(this).attr('data-value') != values[1][0]) && ($(this).attr('data-compare') == values[1][1])))
							{
								$(this).attr('disabled','disabled');
							}
						}
					});
				}, null);
			}
		}
	});
}

