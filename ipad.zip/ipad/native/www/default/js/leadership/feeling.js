
/* JavaScript content from js/leadership/feeling.js in folder common */
$(document).on('pagebeforeshow', '#' + leadershipfeelingPage.id, function(event) {
	
	leadership_stereotype_getKey('feeling_validate', function(value){
		$("#" + leadershipfeelingPage.id +" .fiveLeaders_feeling" ).attr('disabled','disabled');
	}, null);
	leadership_stereotype_getKey('feeling_reponse', function(value){
		$("#" + leadershipfeelingPage.id +" .fiveLeaders_feeling" ).val(value);
		toggleEnabling($('#' + leadershipfeelingPage.id + ' [data-class=finish]'), false);
	}, function(){
		toggleEnabling($('#' + leadershipfeelingPage.id + ' [data-class=finish]'), true);
	});
	getActivityStatus(leadershipfeelingPage.id, function(status){
		if(status==SCREEN_STATUS_FINISHED){
			$('#' + leadershipfeelingPage.id + ' [data-class=finish]').css('display','none');	
			$('#' + leadershipfeelingPage.id + ' [data-class=next]').css('display','block');	
		}
	});
});

$("#" + leadershipfeelingPage.id +" .fiveLeaders_feeling" ).on("keyup", function(e) {
	
	var value = $(this).val().trim();
	setActivityStatus(leadershipfeelingPage.id, SCREEN_STATUS_IN_PROGRESS, function(){
		if((value)||(value.length == 0))
			if(value.length == 0){
				leadership_stereotype_deleteKey('feeling_reponse', function(){
					toggleEnabling($('#' + leadershipfeelingPage.id + ' [data-class=finish]'), true);
				});
			}
			else {
				leadership_stereotype_setKey('feeling_reponse',value,function(){
					toggleEnabling($('#' + leadershipfeelingPage.id + ' [data-class=finish]'), false);
				});
			}
	});
});

$('#' + leadershipfeelingPage.id + ' [data-class=finish]').on("click", function(e) {
	leadership_stereotype_setKey("feeling_validate",'true',function(){
		setActivityStatus(leadershipfeelingPage.id, SCREEN_STATUS_FINISHED, function(){
			set_Status_Progression("leadership_progression", 62, function(){
				setActivityStatus(leadershipAttitudePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
					$("#" + leadershipfeelingPage.id +" .fiveLeaders_feeling" ).attr('disabled','disabled');
					$.mobile.changePage("#" + leadershipSummaryPage.id);
				});
			});
		});
		
	});
});

$('#' + leadershipfeelingPage.id + ' [data-class=next]').on("click", function(e) {
	$.mobile.changePage("#" + leadershipSummaryPage.id);
});