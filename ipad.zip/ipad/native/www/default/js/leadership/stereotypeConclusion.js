
/* JavaScript content from js/leadership/stereotypeConclusion.js in folder common */
$(document).on('pagebeforeshow', '#' + leadershipStereotypeConclusionPage.id, function(event) {
	
	const MAIN_CONTENT=$('#' + leadershipStereotypeConclusionPage.id);

	const BARRE=MAIN_CONTENT.find("#leadership-et-stereotypes-3-slider");
	BARRE.on("click",function(){console.log('cc');});
	BARRE.addClass("ui-slider ui-slider-horizontal"+
					" ui-widget ui-widget-content ui-corner-all"+
					" ui-state-disabled ui-slider-disabled");
	
	BARRE.html(BARRE.html()+"<div style='width: 74.7475%;' class='ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min'>"+
			  "</div><span style='left: 74.7475%;' class='ui-slider-handle ui-state-default ui-corner-all' tabindex='0'>"+
			  "</span>");
	
	get_stereotype_count(
			function(value){
				const COUNT_STEREOTYPE=parseInt(value);
                console.log('COUNT_STEREOTYPE: '+COUNT_STEREOTYPE); //var interval = setInterval(function (){
                	var sum=0;
                	for(var i=0;i<COUNT_STEREOTYPE;i++){
                		get_stereotype_response(i,function(value){
                           sum+=Math.abs(parseInt(value)); 
                           console.log("value:"+value);
                           console.log("sum:"+sum);
                		},function(){ console.log("stereotype data not founder at:"+i)});
                	}

                	var interval = setInterval(function (){
                		if(i<COUNT_STEREOTYPE)return;
                		
                		console.log("sum/COUNT_STEREOTYPE: "+((sum/(COUNT_STEREOTYPE*2))*100)+'%');
                		var width=(((sum/(COUNT_STEREOTYPE*2))*100))+"%";
                		console.log("width:"+width);
                		BARRE.find('div').css({"width": width});
                		BARRE.find('span').css({"width": width});
                		clearInterval(interval);
                	},10);
				return;
			},
            
			function(){ console.log("stereotype count data not  founded");
				return;});
	
		MAIN_CONTENT.find("#validation-conclusion-stereotype").on('click',function(){

		get_Status_Progression(PROGRESS_STAPE_1, function(progress){
			if(progress<4){
				set_Status_Progression(PROGRESS_STAPE_1, 4,function(){return 0;});
			}
			$.mobile.changePage("#"+transitionLeadership.id);
		},
		function(){return; }
		);
		$.mobile.changePage("#"+transitionLeadership.id);
	});
});

function get_stereotype_count(callbackTrue,callbackFalse){
	leadership_stereotype_getKey("count_stereotype", callbackTrue, callbackFalse);
};

function get_stereotype_response(question_num,callbackTrue,callbackFalse){
	console.log('get_stereotype_response:'+ question_num);
	leadership_stereotype_getKey("response_stereotype"+question_num,callbackTrue,callbackFalse);
};