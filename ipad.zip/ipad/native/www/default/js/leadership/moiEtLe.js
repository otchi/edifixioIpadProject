
/* JavaScript content from js/leadership/moiEtLe.js in folder common */
const DATA_KEY="MoiEtLeLeadership";
$(document).on('pagebeforeshow', "#"+ leadershipMoiEtLe.id, function(event) {
	
	const MAIN_CONTENT = $("#"+ leadershipMoiEtLe.id);
	const  DASHBOARD = MAIN_CONTENT.find('#back-dashboard');
	const  VALIDATION_BUTTON = MAIN_CONTENT.find(" #validation-moi-et-le");
	const MOI_ET_LE_INPUT=MAIN_CONTENT.find("#moi-et-le-input");

	get_Status_Progression(PROGRESS_STAPE_1,function(value){
		if(parseInt(value)<5){
			moiEtLE_questions_get(function(value){
				MOI_ET_LE_INPUT.val(value);
			},function(){});
			
			if(MOI_ET_LE_INPUT.val().length==0) VALIDATION_BUTTON.css('visibility','hidden');
			VALIDATION_BUTTON.on('click',function(){
				moiEtLE_questions_set(MOI_ET_LE_INPUT.val(), function(){
					console.log('save:'+MOI_ET_LE_INPUT.val());
				});
				set_Status_Progression(PROGRESS_STAPE_1,5,function(){
					$.mobile.changePage("#"+transitionLeadership.id);
				});
			});
			
			DASHBOARD .on('click',function(){
				moiEtLE_questions_set(MOI_ET_LE_INPUT.val(), function(){
					$.mobile.changePage("#"+ dashBoardPage.id);
					console.log('save:'+MOI_ET_LE_INPUT.val());
				});
			});
			
			MOI_ET_LE_INPUT.on('keyup',function(){
				if(MOI_ET_LE_INPUT.val().length>0) VALIDATION_BUTTON.css('visibility','visible');
			});
		}else{
			moiEtLE_questions_get(function(value){
				MOI_ET_LE_INPUT.val(value);
			},function(){});
			
			MOI_ET_LE_INPUT.prop('disabled', true);
			
			VALIDATION_BUTTON.on('click',function(){
				$.mobile.changePage("#"+transitionLeadership.id);
			});
			
			DASHBOARD .on('click',function(){
				$.mobile.changePage("#"+ dashBoardPage.id);
			});
		}
	},function(){
		console.log('no data of progression in moi et le activity');
	});

});

function  moiEtLE_questions_set(value, callback){
	leadership_questions_setKey(DATA_KEY,value, callback);
}

function  moiEtLE_questions_get(callbackIfTrue,callbackIfFalse){
	leadership_questions_getKey(DATA_KEY,callbackIfTrue,callbackIfFalse);
}