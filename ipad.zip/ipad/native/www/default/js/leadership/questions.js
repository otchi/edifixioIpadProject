
/* JavaScript content from js/leadership/questions.js in folder common */
var centi=0; // initialise les dixtièmes
var secon=0; //initialise les secondes
var minu=0; //initialise les minutes
var leadershipQuestionsCurrent = "1";
$(document).on("pagebeforeshow", "#" + leadershipQuestionsPage.id, function(event) {
	
	$( "#" + leadershipQuestionsPage.id +' .leadership_questions_page').load( "pages/leadership/questions_design.html",function(){
		
		
		
		translatePage(leadershipQuestionsPage.id);
		$( "#" + leadershipQuestionsPage.id +' .leadership_questions_page #main-content').css('height','100vh');
//		leadership_questions_getKey("leadership_questions_validate", function(value){
//			show_valdate_page();
//		}, function(){
//			$('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').css('visibility','visible');
//			$('#'+ leadershipQuestionsPage.id+' .leadership_questions').css('visibility','visible');
//		});
		
//		$('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').on("click", function(e) {
//			leadership_questions_setKey("question_current", "1", function(){
//			   $('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').css('visibility','hidden');
//			   $('#'+ leadershipQuestionsPage.id+' .leadership_questions').css('visibility','hidden');
//			   $('#'+ leadershipQuestionsPage.id+' .label_question').html($.i18n.prop('leadership.questions.label.1'));
//			   $('#'+ leadershipQuestionsPage.id+' .presentation_questions').css('visibility','visible');
//			   chrono();
//			});
//		});
		
//		$('#'+ leadershipQuestionsPage.id+' .presentation_questions button').on("click", function(e) {
//			leadership_questions_getKey("question_current", function(value){
//				leadershipQuestionsCurrent = parseInt(value)+1;
//				leadership_questions_setKey("question_current", leadershipQuestionsCurrent, function(){
//					$('#'+ leadershipQuestionsPage.id+' .label_question').html($.i18n.prop('leadership.questions.label.'+leadershipQuestionsCurrent));
//					if(leadershipQuestionsCurrent > 15) {
//						leadership_questions_setKey("leadership_questions_validate", "true", function(){
//							show_valdate_page();
//							clearTimeout(compte);
//						});
//					}
//					$('#' + leadershipQuestionsPage.id +' .leadership_questions_input').val('');
//				});
//			},null);
//		});
//
//		$('#'+ leadershipQuestionsPage.id+' button[data-class=finish]').on("click", function(e) {
//			setActivityStatus(leadershipQuestionsPage.id, SCREEN_STATUS_FINISHED, function(){
//				setActivityStatus(leadershipStereotypePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
//					$.mobile.changePage("#"+leadershipSummaryPage.id);
//				});
//			});
//		});
		
//		$('#'+ leadershipQuestionsPage.id+' button[data-class=next]').on("click", function(e) {
//			$.mobile.changePage("#"+leadershipSummaryPage.id);
//		});
		
	});
});









function chrono(){
	
	centi++; //incrémentation des dixièmes de 1
	if (centi>9){centi=0;secon++;} //si les dixièmes > 9, on les réinitialise à 0 et on incrémente les secondes de 1
	if (secon>59){secon=0;minu++;} //si les secondes > 59, on les réinitialise à 0 et on incrémente les minutes de 1
	$('#'+ leadershipQuestionsPage.id+' .minutes').html(minu);//on affiche les dixièmes
	$('#'+ leadershipQuestionsPage.id+' .secondes').html(secon); //on affiche les secondes
	$('#'+ leadershipQuestionsPage.id+' .miliseconde').html(centi); //on affiche les minutes
	leadership_questions_getKey("leadership_questions_validate", 
			null,function(){
		if((minu == 3)&&(secon==0)&&(centi==0)){ $('#'+ leadershipQuestionsPage.id+ ' .leadership_questions_popup [data-rel=popup]').click(); }
	});
	compte=setTimeout('chrono()',100); //la fonction est relancée tous les 100° de secondes
}

$("#" + leadershipQuestionsPage.id +" .leadership_questions_input" ).on("keyup", function(e) {
	var value = $(this).val().trim();
	if((value)||(value.length == 0)){
		if(value.length == 0)leadership_questions_deleteKey("question_response_"+leadershipQuestionsCurrent);
		else leadership_questions_setKey("question_response_"+leadershipQuestionsCurrent, value);
	}
});
function checkInput(){
	var value = $("#" + leadershipQuestionsPage.id +" .leadership_questions_input").val().trim();
	if(value.length > 0)toggleEnabling($('#' + leadershipQuestionsPage.id +' [value=validate]'),false);
	else toggleEnabling($('#' + leadershipQuestionsPage.id +' [value=validate]'),true);
	compte=setTimeout('checkInput()',1000);
}

function show_valdate_page(){
	
	$('#' + leadershipQuestionsPage.id +' [data-id=leadership_questions_step_1]').css('display','none');
	$('#' + leadershipQuestionsPage.id +' [data-id=leadership_questions_step_2]').css('display','block');
	$Questions = $('#' + leadershipQuestionsPage.id+' .leadership_Questions');
	$Questions.empty();
	for(var i=1;i<16;i++){
		var htmlCode = '<div class="leadership_reponseQuestion_question_' + i + '">' + $.i18n.prop('leadership.questions.label.'+i) + '</div>';
		$Questions.append(htmlCode);
	}
	$reponsesQuestions = $('#' + leadershipQuestionsPage.id+' .leadership_responses');
	$reponsesQuestions.empty();
	for(var i =1;i<16;i++){
		leadership_questions_getKey("question_response_"+i, function(value){
			var htmlCode = '<div class="leadership_reponseQuestion_response_' + i + '">' + value + '</div>';
			$reponsesQuestions.append(htmlCode);
		}, function(){
			var htmlCode = '<div class="leadership_reponseQuestion_reponse_1">' + $.i18n.prop('leadership.questions.empty.reponse') + '</div>';
			$reponsesQuestions.append(htmlCode);			
		});
	}
	getActivityStatus(leadershipQuestionsPage.id, function(status){
		if(status == SCREEN_STATUS_FINISHED){
			$('#' + leadershipQuestionsPage.id +' [data-class=next]').css('display','block');
			$('#' + leadershipQuestionsPage.id +' [data-class=finish]').css('display','none');
		}
	});
}