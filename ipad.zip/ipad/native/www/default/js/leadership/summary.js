
/* JavaScript content from js/leadership/summary.js in folder common */

	
$("#leadership_summary_stage_1").on("click", function(e) {

	getActivityStatus(leadershipFiveLeadersChoosePage.id, function(activityStatus_leadership_screen) {
		if((activityStatus_leadership_screen) && ((activityStatus_leadership_screen==SCREEN_STATUS_ACCESSIBLE)||(activityStatus_leadership_screen==SCREEN_STATUS_IN_PROGRESS)))
			$.mobile.changePage("#"+leadershipFiveLeadersChoosePage.id);
		else{
		  $.mobile.changePage('#' + leadershipFiveLeadersPage.id);	
		}
	});
});

$("#leadership_summary_stage_2").on("click", function(e) {
	getActivityStatus(leadershipDevelopmentPage.id, function(activityStatus_leadership_screen) {
		if (activityStatus_leadership_screen && !activityStatus_leadership_screen == '') {
			$.mobile.changePage("#"+leadershipDevelopmentPage.id);	
		} 
	});
});

$("#leadership_summary_stage_3").on("click", function(e) {
	getActivityStatus(leadershipQuestionsPage.id, function(activityStatus_leadership_screen) {
		if (activityStatus_leadership_screen && !activityStatus_leadership_screen == '') {
			$.mobile.changePage("#"+leadershipQuestionsPage.id);	
		} 
	});
});

$("#leadership_summary_stage_4").on("click", function(e) {
	getActivityStatus(leadershipStereotypePage.id, function(activityStatus_leadership_screen) {
		if (activityStatus_leadership_screen && !activityStatus_leadership_screen == '') {
			$.mobile.changePage("#"+leadershipStereotypePage.id);	
		} 
	});
});

$("#leadership_summary_stage_5").on("click", function(e) {
	getActivityStatus(leadershipfeelingPage.id, function(activityStatus_leadership_screen) {
		if (activityStatus_leadership_screen && !activityStatus_leadership_screen == '') {
			$.mobile.changePage("#"+leadershipfeelingPage.id);	
		} 
	});
});

$("#leadership_summary_stage_6").on("click", function(e) {
	getActivityStatus(leadershipAttitudePage.id, function(activityStatus_leadership_screen2) {
		getActivityStatus(leadershipMarkAttitudePage.id, function(activityStatus_leadership_screen1) {
			if((activityStatus_leadership_screen1) && ((activityStatus_leadership_screen1==SCREEN_STATUS_ACCESSIBLE)||(activityStatus_leadership_screen1==SCREEN_STATUS_IN_PROGRESS)))
				$.mobile.changePage('#' + leadershipMarkAttitudePage.id);
			else{
				if(activityStatus_leadership_screen2) 
					$.mobile.changePage("#"+leadershipAttitudePage.id);	
			} 
		});
	});
});

$(document).on("pagebeforeshow", "#" + leadershipSummaryPage.id, function(event) {
	getActivityStatus(leadershipFiveLeadersChoosePage.id, function(activityStatus_leadership_screen2) {
		getActivityStatus(leadershipFiveLeadersPage.id, function(activityStatus_leadership_screen1) {
			if(activityStatus_leadership_screen2) 
				$("#leadership_1_status").html(activityStatus_leadership_screen2);	
			else{
				if (!activityStatus_leadership_screen1 || activityStatus_leadership_screen1 == '') {
					$("#leadership_1_status").html(SCREEN_STATUS_ACCESSIBLE);	
				} else {
					$("#leadership_1_status").html(activityStatus_leadership_screen1);	
				}
			}
		});
	});

	getActivityStatus(leadershipDevelopmentPage.id, function(activityStatus_leadership_screen3) {
		if (!activityStatus_leadership_screen3 || activityStatus_leadership_screen3 == '') {
			$("#leadership_2_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#leadership_2_status").html(activityStatus_leadership_screen3);
		}
	});

	getActivityStatus(leadershipQuestionsPage.id, function(activityStatus_leadership_screen4) {
		if (!activityStatus_leadership_screen4 || activityStatus_leadership_screen4 == '') {
			$("#leadership_3_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#leadership_3_status").html(activityStatus_leadership_screen4);
		}
	});
	
	getActivityStatus(leadershipStereotypePage.id, function(activityStatus_leadership_screen5) {
		if (!activityStatus_leadership_screen5 || activityStatus_leadership_screen5 == '') {
			$("#leadership_4_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#leadership_4_status").html(activityStatus_leadership_screen5);
		}
	});
	
	getActivityStatus(leadershipfeelingPage.id, function(activityStatus_leadership_screen6) {
		if (!activityStatus_leadership_screen6 || activityStatus_leadership_screen6 == '') {
			$("#leadership_5_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#leadership_5_status").html(activityStatus_leadership_screen6);
		}
	});
	
	getActivityStatus(leadershipMarkAttitudePage.id, function(activityStatus_leadership_screen2) {
		getActivityStatus(leadershipAttitudePage.id, function(activityStatus_leadership_screen1) {
			if(activityStatus_leadership_screen2) 
				$("#leadership_6_status").html(activityStatus_leadership_screen2);	
			else{
				if (!activityStatus_leadership_screen1 || activityStatus_leadership_screen1 == '') {
					$("#leadership_6_status").html(SCREEN_STATUS_LOCKED);	
				} else {
					$("#leadership_6_status").html(activityStatus_leadership_screen1);	
				}
			}
		});
	});
	
});

