
/* JavaScript content from js/leadership/les5AttitudesLeaderIntro.js in folder common */
$(document).on('pagebeforeshow', "#"+ les5AttitudesLeaderIntro.id, function(event) {
	const MAIN_CONTENT = $("#"+ les5AttitudesLeaderIntro.id);
	const  DASHBOARD = MAIN_CONTENT.find('#back-dashboard');
	const  VALIDATION_BUTTON = MAIN_CONTENT.find(" #validation-5-attitudes-leaders-intro");
	
	VALIDATION_BUTTON.on('click',function(){
		$.mobile.changePage("#"+ les5AttitudesLeader.id);//les5AttitudesLeader
	});
	
	DASHBOARD.on('click',function(){
		$.mobile.changePage("#"+ dashBoardPage.id);
	});
});