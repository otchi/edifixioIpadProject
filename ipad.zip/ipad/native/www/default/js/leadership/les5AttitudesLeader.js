
/* JavaScript content from js/leadership/les5AttitudesLeader.js in folder common */
const MAIN_CONTENT = $('#'+les5AttitudesLeader.id); // specific for this context
const DROPABLE_SLIDE = MAIN_CONTENT.find('#les-5-attitudes-leader-anim-slider');
 const LEADERSHIP_ATTITUDE_PROGRESS="leadership_attitude_progress";   	
DROPABLE_SLIDE.addClass('ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all ui-state-disabled ui-slider-disabled ui-droppable');
DROPABLE_SLIDE.html('<div style="width: 48.6957%;" class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min"></div>'+
    			'<span style="left: 48.6957%;" class="ui-slider-handle ui-state-default ui-corner-all ui-draggable ui-draggable-handle" tabindex="0"></span>');

$(document).on('pagebeforeshow', "#"+ les5AttitudesLeader.id, function(event) {
 		

	
	    const VALIDATION_BUTTON = MAIN_CONTENT.find('#attitude-validation');
	    const BACK_DASHBOARD = MAIN_CONTENT.find('#back-to-dashboard');

	    const DRAGGABLE_CURSOR = DROPABLE_SLIDE.find('span');
	    
	    console.log(DROPABLE_SLIDE.css('width'));
	    console.log(DRAGGABLE_CURSOR.css('width'));
	    
	    console.log("DROPABLE_SLIDE.find('span').attr('class'):"+DROPABLE_SLIDE.find('span').attr('class'));
	    console.log("DRAGGABLE_CURSOR:"+DRAGGABLE_CURSOR.attr('class'));
	    
	    DRAGGABLE_CURSOR.ready(function(){
	    	DRAGGABLE_CURSOR.on('click',function(){alert('batata');});
	    });
	    //---------------------------------------------------------------------------------
	    const CURSOR_WIDTH = parseInt(DRAGGABLE_CURSOR.css('width')
	                                  .substring(DRAGGABLE_CURSOR.css('width')-2));
	    const SLIDE_WITH = parseInt(DROPABLE_SLIDE.css('width')
	                                .substring(DROPABLE_SLIDE.css('width')-2))-CURSOR_WIDTH;
	    //---------------------------------------------------------------------------------
	    const SLIDE_LEFT_POSTION = DROPABLE_SLIDE.offset().left;
	    const QUESTION_ATTITUDE =MAIN_CONTENT.find('.les-5-attitudes-leader-anim-heading');
	    const QUESTION_ATTITUDE_COUNT =QUESTION_ATTITUDE.length;
	    const NBR_INTERVALS = 10;
	    const INTERVALS = SLIDE_WITH/NBR_INTERVALS;
	    //---------------------------------------------------------------------------------
	    const QUESTION_ATTITUDE_ID_PREFIX = "question_attitude_";
	    const ATTITUDE_LEFT_ID_PREFIX = "attitude_left_";
	    const ATTITUDE_RIGHT_ID_PREFIX="attitude_right_";
	    const ATTITUDE_MIDDLE_ID_PREFIX="attitude_middle_";
	    const ATTITUDE_LEFT = MAIN_CONTENT.find(".info-text-1");
	    const ATTITUDE_MIDDLE = MAIN_CONTENT.find(".info-text-2");
	    const ATTITUDE_RIGHT = MAIN_CONTENT.find(".info-text-3");
	    //---------------------------------------------------------------------------------
	    const QUESTION_ATTITUDE_DISPLAY =
	                        MAIN_CONTENT.find('#'+QUESTION_ATTITUDE_ID_PREFIX+0)
	                                    .css('display');
	    const ATTITUDE_LEFT_DISPLAY =
	                        MAIN_CONTENT.find('#'+ATTITUDE_LEFT_ID_PREFIX+0)
	                                    .css('display');
	    const ATTITUDE_RIGHT_DISPLAY =
	                        MAIN_CONTENT.find('#'+ATTITUDE_RIGHT_ID_PREFIX+0)
	                                    .css('display');
	    const ATTITUDE_MIDDLE_DISPLAY =
	                        MAIN_CONTENT.find('#'+ATTITUDE_MIDDLE_ID_PREFIX+0)
	                                    .css('display');
	    const QUESTION_NUMBER =MAIN_CONTENT.find('#leadership-question-number-attitude');
	    //---------------------------------------------------------------------------------
	    DROPABLE_SLIDE.on('click',function(){alert('cc');});
	    //---------------------------------------------------------------------------------
	    var dataActivity={
	        activity_progress : undefined,
	        dropable_point : new Array()
	    };
	    
	    QUESTION_ATTITUDE.css('display','none');
	    ATTITUDE_LEFT.css('display','none');
	    ATTITUDE_MIDDLE.css('display','none');
	    ATTITUDE_RIGHT.css('display','none');
	    console.log("QUESTION_ATTITUDE_COUNT: "+QUESTION_ATTITUDE_COUNT)
	    
	    dataActivity.activity_progress=0;
	    QUESTION_NUMBER.text((dataActivity.activity_progress+1)+"/"+QUESTION_ATTITUDE_COUNT);
	    
	    
	    for(var i=0;i<=NBR_INTERVALS;i++){
	        dataActivity.dropable_point[i]=SLIDE_LEFT_POSTION+INTERVALS*i;
	        console.log(i+":"+dataActivity.dropable_point[i]);
	    }
	
	    DRAGGABLE_CURSOR.draggable({
	         cursor: "move",
	         axis : "x",
	         containment: "#les-5-attitudes-leader-anim-slider",
	         drag:function(){console.log('drag');}
	    });
	    
	   DROPABLE_SLIDE.droppable({
	            drop: function( event, ui ) {
	                    const DRAGGABLE_CURSOR_LEFT_POSITION= ui.draggable.offset().left;
	                    for(var i=0;i<=INTERVALS;i++){
	                        console.log("droped ini"+i);
	                        console.log("dropable_point["+i+"]:"+
	                                dataActivity.dropable_point[i]);
	                        console.log("INTERVALS:"+INTERVALS);
	                        if(Math.abs(dataActivity.dropable_point[i]
	                                - DRAGGABLE_CURSOR_LEFT_POSITION)<INTERVALS/2){
	                            DRAGGABLE_CURSOR.offset(
	                                {left:dataActivity.dropable_point[i]}); 
	                            return;
	                        }
	                    }
	                }
	    });
	    
	    VALIDATION_BUTTON.on('click',function(){
	        questionManager.nextQuestion(); // redirection
	    });
	    BACK_DASHBOARD.on('click',function(){
	    	$.mobile.changePage("#"+ dashBoardPage.id);// redirection
	    });
	    
	    function loadData(){
	        get_leadership_attitude_activity_progress(function(value){
	            console.log(value);
	            dataActivity.activity_progress=parseInt(value);
	        },function(){
	            dataActivity.activity_progress=0;
	        });
	    }
	    
	    
	    function QuestionManager(){
	    };
	    QuestionManager.prototype={
	        nextQuestion : function(){
	            if(dataActivity.activity_progress == undefined||
	                dataActivity.activity_progress < 0 ||
	                dataActivity.activity_progress >= QUESTION_ATTITUDE_COUNT )
	                return false;
	            
	            if(dataActivity.activity_progress!=0){
	                displayAttitudeActivity(dataActivity.activity_progress-1,false);
	            }
	            //console.log('ici');
	            console.log('dataActivity.activity_progress: '+
	                        dataActivity.activity_progress);
	            displayAttitudeActivity (dataActivity.activity_progress,true);
	            QUESTION_NUMBER.text((dataActivity.activity_progress+1)+"/"+QUESTION_ATTITUDE_COUNT);
	            dataActivity.activity_progress++;
	            return true;
	        }
	    };
	    
	    function displayAttitudeActivity (index,state){
	            console.log((QUESTION_ATTITUDE_ID_PREFIX+index)+":"+
	                        MAIN_CONTENT.find('#'+QUESTION_ATTITUDE_ID_PREFIX+index).text());
	            MAIN_CONTENT.find('#'+QUESTION_ATTITUDE_ID_PREFIX+index)
	                        .css('display',((state)?QUESTION_ATTITUDE_DISPLAY : 'none'));
	            MAIN_CONTENT.find('#'+ATTITUDE_LEFT_ID_PREFIX+index)
	                        .css('display',((state)?ATTITUDE_LEFT_DISPLAY:'none'));
	            MAIN_CONTENT.find('#'+ATTITUDE_RIGHT_ID_PREFIX+index)
	                        .css('display',((state)?ATTITUDE_RIGHT_DISPLAY :'none'));
	            MAIN_CONTENT.find('#'+ATTITUDE_MIDDLE_ID_PREFIX+index)
	                        .css('display',((state)?ATTITUDE_MIDDLE_DISPLAY :'none'));
	    }
	               
	    
	    var questionManager=new QuestionManager();
	    questionManager.nextQuestion();   
	    
});


function get_leadership_attitude_activity_progress(callbackTrue,callbackFalse){
	leadership_attitude_getKey(LEADERSHIP_ATTITUDE_PROGRESS,callbackTrue,callbackFalse);
};
function set_leadership_attitude_progress(value,callback){
	leadership_attitude_setKey(LEADERSHIP_ATTITUDE_PROGRESS,value,callback);
};

function get_attitude_evaluation(numAttitude,callbackTrue,callbackFalse){
	leadership_attitude_getKey(numAttitude,callbackTrue,callbackFalse);
};

function set_attitude_evaluation(numAttitude,value,callback){
	leadership_attitude_setKey(numAttitude,value,callback);
};