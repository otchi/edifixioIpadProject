
/* JavaScript content from js/leadership/leadershipQuestionsInYourHistoryIntroduction.js in folder common */


$(document).on("pagebeforeshow", "#" + leadershipQuestionsInYourHistoryIntroduction.id, function(event) {
	const MAIN_CONTENT=	$( "#" + leadershipQuestionsInYourHistoryIntroduction.id );
	MAIN_CONTENT.find('[data-id=leadershipQuestionsInYourHistoryIntroduction]')
		.load("pages/leadership/leadershipQuestionsInYourHistoryIntroduction_disign.html",function(){
		//alert("coco rico");
        translatePage(leadershipQuestionsInYourHistoryIntroduction.id);
        
        get_leadership_questions_progress(function(value){
    		console.log('activityData.activity_progress:'+value);
    		if(parseInt(value)<0){
    			alert('finish');
    			$.mobile.changePage("#"+ leadershipQuestionsInYourHistory.id);
    		}else{
    			$.mobile.changePage("#"+ leadershipQuestionsInYourHistory.id);
    		}

        },function(){
        	MAIN_CONTENT.find(".leadership_questions_page").find("#main-content").css('height','100vh');
    		
        	MAIN_CONTENT.find("[data-id=next]").on('click',function(e){
            	$.mobile.changePage("#"+ leadershipQuestionsInYourHistory.id);
            
    		});
    		
        	MAIN_CONTENT.find(" [data-id=back-dashboard]").on('click',function(e){
    			$.mobile.changePage("#"+ dashBoardPage.id);
    		});
        });

	});
});



//$("#" + leadershipQuestionsPage.id +" .leadership_questions_input" ).on("keyup", function(e) {
//	var value = $(this).val().trim();
//	if((value)||(value.length == 0)){
//		if(value.length == 0)leadership_questions_deleteKey("question_response_"+leadershipQuestionsCurrent);
//		else leadership_questions_setKey("question_response_"+leadershipQuestionsCurrent, value);
//	}
//});
//function checkInput(){
//	var value = $("#" + leadershipQuestionsPage.id +" .leadership_questions_input").val().trim();
//	if(value.length > 0)toggleEnabling($('#' + leadershipQuestionsPage.id +' [value=validate]'),false);
//	else toggleEnabling($('#' + leadershipQuestionsPage.id +' [value=validate]'),true);
//	compte=setTimeout('checkInput()',1000);
//}
//
//function show_valdate_page(){
//	
//	$('#' + leadershipQuestionsPage.id +' [data-id=leadership_questions_step_1]').css('display','none');
//	$('#' + leadershipQuestionsPage.id +' [data-id=leadership_questions_step_2]').css('display','block');
//	$Questions = $('#' + leadershipQuestionsPage.id+' .leadership_Questions');
//	$Questions.empty();
//	for(var i=1;i<16;i++){
//		var htmlCode = '<div class="leadership_reponseQuestion_question_' + i + '">' + $.i18n.prop('leadership.questions.label.'+i) + '</div>';
//		$Questions.append(htmlCode);
//	}
//	$reponsesQuestions = $('#' + leadershipQuestionsPage.id+' .leadership_responses');
//	$reponsesQuestions.empty();
//	for(var i =1;i<16;i++){
//		leadership_questions_getKey("question_response_"+i, function(value){
//			var htmlCode = '<div class="leadership_reponseQuestion_response_' + i + '">' + value + '</div>';
//			$reponsesQuestions.append(htmlCode);
//		}, function(){
//			var htmlCode = '<div class="leadership_reponseQuestion_reponse_1">' + $.i18n.prop('leadership.questions.empty.reponse') + '</div>';
//			$reponsesQuestions.append(htmlCode);			
//		});
//	}
//	getActivityStatus(leadershipQuestionsPage.id, function(status){
//		if(status == SCREEN_STATUS_FINISHED){
//			$('#' + leadershipQuestionsPage.id +' [data-class=next]').css('display','block');
//			$('#' + leadershipQuestionsPage.id +' [data-class=finish]').css('display','none');
//		}
//	});
//}
//
//




//leadership_questions_getKey("leadership_questions_validate", function(value){
//show_valdate_page();
//}, function(){
//$('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').css('visibility','visible');
//$('#'+ leadershipQuestionsPage.id+' .leadership_questions').css('visibility','visible');
//});

//$('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').on("click", function(e) {
//leadership_questions_setKey("question_current", "1", function(){
//   $('#'+ leadershipQuestionsPage.id+' [data-value=Chrono]').css('visibility','hidden');
//   $('#'+ leadershipQuestionsPage.id+' .leadership_questions').css('visibility','hidden');
//   $('#'+ leadershipQuestionsPage.id+' .label_question').html($.i18n.prop('leadership.questions.label.1'));
//   $('#'+ leadershipQuestionsPage.id+' .presentation_questions').css('visibility','visible');
//   chrono();
//});
//});

//$('#'+ leadershipQuestionsPage.id+' .presentation_questions button').on("click", function(e) {
//leadership_questions_getKey("question_current", function(value){
//	leadershipQuestionsCurrent = parseInt(value)+1;
//	leadership_questions_setKey("question_current", leadershipQuestionsCurrent, function(){
//		$('#'+ leadershipQuestionsPage.id+' .label_question').html($.i18n.prop('leadership.questions.label.'+leadershipQuestionsCurrent));
//		if(leadershipQuestionsCurrent > 15) {
//			leadership_questions_setKey("leadership_questions_validate", "true", function(){
//				show_valdate_page();
//				clearTimeout(compte);
//			});
//		}
//		$('#' + leadershipQuestionsPage.id +' .leadership_questions_input').val('');
//	});
//},null);
//});
//
//$('#'+ leadershipQuestionsPage.id+' button[data-class=finish]').on("click", function(e) {
//setActivityStatus(leadershipQuestionsPage.id, SCREEN_STATUS_FINISHED, function(){
//	setActivityStatus(leadershipStereotypePage.id, SCREEN_STATUS_ACCESSIBLE, function(){
//		$.mobile.changePage("#"+leadershipSummaryPage.id);
//	});
//});
//});

//$('#'+ leadershipQuestionsPage.id+' button[data-class=next]').on("click", function(e) {
//$.mobile.changePage("#"+leadershipSummaryPage.id);
//});