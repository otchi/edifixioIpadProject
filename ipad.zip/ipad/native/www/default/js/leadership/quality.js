
/* JavaScript content from js/leadership/quality.js in folder common */
function Quality(id, QualityLabel) {
	this.id = id;
	this.QualityLabel = QualityLabel;
};

var qualityMap = {};

function getQualityLocalizedLabel(qualityId) {
	var quality = qualityMap[qualityId];
	if (quality && quality != null) {		
			return quality.QualityLabel;		
	}
}

function createQuality(id, QualityLabel) {
	qualityMap[id] = new Quality(id, QualityLabel);
}
function createQualityMap() {
	var sampleNumberString = $.i18n.prop('leadership.fiveLeaders.quality.number');
	
	// Random
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('leadership.fiveLeaders.quality.'+i);	
				console.log(title);
				createQuality(i, title);
			}
	} else {
		console.log("leadership.fiveLeaders.quality.number is not a number");
	}
	
}