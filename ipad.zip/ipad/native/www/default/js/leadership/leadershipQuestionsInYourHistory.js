
/* JavaScript content from js/leadership/leadershipQuestionsInYourHistory.js in folder common */

const LEADERSHIP_PROGRESS = "leadership_progression";
const JOCKERS = "jockers";
const CHRONO="chrono";
const RESPONSE_DATA_KEY_PREFIX="response_";

$(document).on("pagebeforeshow", "#" + leadershipQuestionsInYourHistory.id, function(event) {

	$( "#" + leadershipQuestionsInYourHistory.id )
		.find('[data-id=leadershipQuestionsInYourHistory]')
		.load("pages/leadership/leadershipQuestionsInYourHistory_design.html",
	
	function(){
			
//--------------- a retirer (netoyage pour test)			
//	    set_leadership_questions_progress(0,function(){return;});
//	    set_leadership_questions_jocker(2,function(){return;});
//	    set_leadership_questions_time(0,function(){return;});	
		//alert("amine");
		const MAIN_CONTENT=$( "#" + leadershipQuestionsInYourHistory.id );
		const QUESTION_DATA_ID = "question_";
	    // prefix 
		const RESPONSE_DATA_ID = "response-leadership-in-your-history";
	    
	    const DISPLAY_CHRONO = MAIN_CONTENT.find("[data-id=time_activity_chrono]");
	    
	    const QUESTION_STEREOTYPE =MAIN_CONTENT.find(".question_leadership_your_history");
	    //number of question of activity
	    const QUESTION_STEREOTYPE_COUNT=QUESTION_STEREOTYPE.length;
	    //save a display CSS property of element to hidden
		const DISPLAY_QUESTION = MAIN_CONTENT.find('[data-id='+QUESTION_DATA_ID+'0'+']').css('display');
		// user interaction element 
		const DASHBOARD = MAIN_CONTENT.find('[data-id=back-dashboard]');
	    const VALIDATION_BUTTON = MAIN_CONTENT.find('[data-id=ok-on]');
		const NEXT_BUTTON =	MAIN_CONTENT.find('[data-id=check-next]');
	    const DISPLAY_OK_ON = VALIDATION_BUTTON.css('display');
	    const INPUT_RESPONSE=MAIN_CONTENT.find('[data-id='+RESPONSE_DATA_ID+']');
	    
	    
	    //-----------------------------------------------------------------------------------------
	    var activityData = {
	    	activity_progress : undefined , jockers : undefined,minute:undefined,seconde :undefined,
	    };
	    
	    //-----------------------------------------------------------------------------------------
	    new LoadData();
	    var interval=undefined;
	    //----------------------------------------------------------------------------------------
	    //  expect to all activityData filds are ready
	    interval = setInterval(
	        function(){
	            if(activityData.activity_progress == undefined || activityData.jockers == undefined || 
	               activityData.minute== undefined || activityData.seconde==undefined ) return;
	            QUESTION_STEREOTYPE.css('display','none');
	            //-----------------------------------------------------------------
	            // if activity progress is negative => activity finished => read only mode
	            if(activityData.activity_progress<0){
	                activityData.activity_progress=0;
	                var readOnlyManager=new ReadOnlyManager();
	                readOnlyManager.displayQuestion();
	                readOnlyManager.jockersDisplay();
	                DISPLAY_CHRONO.text(((activityData.minute<=9)? "0" : "")+activityData.minute+":"+
	                                    ((activityData.seconde<=9)?"0":"")+activityData.seconde); 
	                NEXT_BUTTON.on('click', function(){
	                	if(activityData.activity_progress<QUESTION_STEREOTYPE_COUNT){
	                		activityData.activity_progress++;
	                		readOnlyManager.displayQuestion();
	                	}
	                	else $.mobile.changePage("#"+transitionLeadership.id);
	                		
	                });
	                
		            DASHBOARD.on('click',function(){
		                $.mobile.changePage("#"+ dashBoardPage.id);
		            });
	                clearInterval(interval);                
	                return; 
	            }
	            //-------------------------------------------------------------------
	        
	            var questionManager=new QuestionManager();
	            var jockerManager=new JockerManager();
	            //-----------------------------
	            // create chrono with callback to display it
	            var chrono=new Chrono(
	                function(seconde,minute){
	                    DISPLAY_CHRONO.text(((minute<=9)? "0" : "")+minute+":"+((seconde<=9)?"0":"")+seconde); 
	            },activityData.seconde,activityData.minute);
	            //-----------------------------
	            questionManager.hiddenNext();
	            questionManager.displayQuestion();
	            //-----------------------------
	            jockerManager.jockersDisplay();
	            //-----------------------------
	            chrono.run();
	     
	            //----------------------------------------------------------------------------------------
	            // validate response and pass to next question
	            VALIDATION_BUTTON.on('click', function(){
	                console.log("next: "+activityData.activity_progress);
	                questionManager.hiddenNext();
	                activityData.activity_progress++;
	                var state = questionManager.displayQuestion();
	                questionManager.saveData();
	                if(!state) {
	                    activityData.activity_progress=-1;
	                    activityData.minute=chrono.getMinute();
	                    activityData.seconde=chrono.getSeconde();
	                    exitActivity();
	        			set_Status_Progression(PROGRESS_STAPE_1, 3,function(){
	        				$.mobile.changePage("#"+transitionLeadership.id);
	        			});
	        			
	        			
	                  
	                };
	            });    
	            //-------------------------------------------------------------------------
	            // next question and loose jocker
	            NEXT_BUTTON.on('click', function(){
	                console.log("next: "+activityData.activity_progress);
	                jockerManager.hiddenNext();
	                activityData.activity_progress++;
	                var state = jockerManager.displayQuestion();
	                jockerManager.jockersDisplay(
	                    function(){
	                        if(activityData.jockers>=0) 
	                            activityData.jockers--;
	                     
	                        if(activityData.jockers<0)
	                            NEXT_BUTTON.css('display','none');
	            
	                    });
	                if(!state) {
	                    activityData.activity_progress=-1;
	                    activityData.minute=chrono.getMinute();
	                    activityData.seconde=chrono.getSeconde();
	                    exitActivity();
	        			set_Status_Progression(PROGRESS_STAPE_1, 3,function(){
	        				$.mobile.changePage("#"+transitionLeadership.id);
	        			});
	                  
	                };
	            });
	            //---------------------------------------------------------------------
	            // display validation button if input is cahnged and her text is >=1
	            INPUT_RESPONSE.on('keyup', function() {
		           if((INPUT_RESPONSE.val().length)>=1) {
	                    VALIDATION_BUTTON.css('display',DISPLAY_OK_ON);
	                    questionManager.isValidable = true;
	                } else {
	                    VALIDATION_BUTTON.css('display','none');
			            questionManager.isValidable=false;
		           }
	            });
	            //---------------------------------------------------------------------
	            // exit application an go to dashboard
	            DASHBOARD.on('click',function(){
	                activityData.minute=chrono.getMinute();
                    activityData.seconde=chrono.getSeconde();
                    exitActivity();
	                $.mobile.changePage("#"+ dashBoardPage.id);
	            });
	            
	            clearInterval(interval);
	        } , 10);
	    //-----------------------------------------------------------------------------------------
	    // load saved data if exist
	    function LoadData(){
	        //-------------------------------------------------------------------------------------
	        //-------------------------------------------------------------------------------------
	        get_leadership_questions_progress(function(value){
	        		console.log('activityData.activity_progress:'+value);
	                activityData.activity_progress=parseInt(value);
	            },function(){
	            	console.log('not founded activityData.activity_progress');
	            	 activityData.activity_progress=0;
	         });
	        //------------------------------------------------------------------------------------
	        get_leadership_questions_jocker(function(value){
        		console.log('activityData.jockers:'+value);
                activityData.jockers=parseInt(value);
            },function(){
                activityData.jockers=parseInt(2);
                console.log('not founded activityData.jockers');
            });
	        //-------------------------------------------------------------------------------------
	        get_leadership_questions_time(function(value){
	        	var time=parseInt(value);
	        	console.log('time:'+time);
	            activityData.minute=Math.floor(time/60);
	            activityData.seconde=time%60;
	        },function(){
	        	console.log('time not founded');
	            activityData.minute=0;
	            activityData.seconde=0;
	        });
	    }    
	    //-------------------------------------------------------------------------------------------------
	    // question navigation and validation response
	    function QuestionManager() {
	        this.isValidable=false;
	    };
	    // 
	    QuestionManager.prototype = {
	    	hiddenNext : function(){
		        if(activityData.jockers<0)  NEXT_BUTTON.css('display','none');
		     },
		     
	        displayQuestion :  displayQuestion,
	        
	        saveData : function(){
	            saveData(this.isValidable);
	        },

	    }
	    //-------------------------------------------------------------------------------------------------
	    // manage pass question with jockers
	    function  JockerManager(){};
	    JockerManager.prototype ={
	    	hiddenNext : function(){
			      if(activityData.jockers<0)  NEXT_BUTTON.css('display','none');
			},
	        displayQuestion :  displayQuestion,
	        jockersDisplay : jockersDisplay,
	    }
	    //---------------------------------------------------------------------------------------------------
	    // read only manager (if activity is finished)
	    function ReadOnlyManager(){
	        INPUT_RESPONSE.prop('disabled', true);
	    };
	    ReadOnlyManager.prototype={
	        displayQuestion : displayQuestion,
	        jockersDisplay : jockersDisplay
	        
	    }
	                //
	     //-----------------------------------------------------------------------------------------------------
	    // function to put question 
	    function displayQuestion(){
	        VALIDATION_BUTTON.css('display','none');
	        // if we are next activity (activity_progress equal to -1 wen we finish activities)
	        if(activityData.activity_progress >= QUESTION_STEREOTYPE_COUNT) return false;
	        // hidden last question
	        if(activityData.activity_progress!=0) 
	            MAIN_CONTENT.find('[data-id='+QUESTION_DATA_ID +
	                                    ( activityData.activity_progress-1)+']').css('display','none');
	        // display a new question and change here nember x/15
	        MAIN_CONTENT.find('[data-id=' + QUESTION_DATA_ID + 
	                            ( activityData.activity_progress ) +']').css('display',DISPLAY_QUESTION);
	        MAIN_CONTENT.find('[data-id=question-number]').text((activityData.activity_progress+1)+"/"+QUESTION_STEREOTYPE_COUNT);
	        // get a aventual response that saved for this question
	        get_leadership_response ( activityData.activity_progress ,
	            function(value) {
	                console.log('index in response: '+activityData.activity_progress +"/"+ value);
	                // put response
	                INPUT_RESPONSE.val(value);
	            } ,
	            function() {
	                console.log('index in not founded: '+activityData.activity_progress);
	                // put a empty response
	                INPUT_RESPONSE.val('').css("placeholder","Ma r&eacute;ponse...");
	        });
	        return true;
	    }
	    //-----------------------------------------------------------------------------------------------------------
	    // display jockers in GUI
	    function  jockersDisplay(callback){
	         if(callback!=undefined) callback();
	        console.log("activityData.jockers:"+activityData.jockers);
	        for(var i=0;i<(2-activityData.jockers);i++){
	            MAIN_CONTENT.find('.clock-joker-histoire-one')
					        .find("img.histoire-one-joker-img")
					        .eq(i).css('visibility','hidden');
	              
	                
	        }
	    }
	    //-----------------------------------------------------------------------------------------------------------
	    // function to save data if is valide
	    function saveData(isValidable){
	        if(activityData.activity_progress>=0 && activityData.activity_progress < QUESTION_STEREOTYPE_COUNT && isValidable){
	                    set_leadership_response(activityData.activity_progress-1,INPUT_RESPONSE.val(),
	                                            function(){console.log('save :'+INPUT_RESPONSE.val())});
	        } else {
	                   if(isValidable)
	                    set_leadership_response(activityData.activity_progress-1,INPUT_RESPONSE.val(),
	                                            function(){console.log('save :'+INPUT_RESPONSE.val())});  
	                    set_leadership_questions_progress(-1,function(){console.log('finish')});
	            
	        }
	    }
	    //------------------------------------------------------------------------------------------------------------
	    // save data befor exit
	    function exitActivity(){
	        set_leadership_questions_progress(activityData.activity_progress-1,
	                            function(){console.log("leadership activity finished")});
	        set_leadership_questions_jocker(activityData.jockers,
	                            function(){console.log('finished with : '+activityData.jockers+' jockers')});
	        
	        set_leadership_questions_time(activityData.minute*60+activityData.seconde,
	                            function(){console.log('finished in : '+activityData.minute+":"+activityData.seconde);
	                            console.log('finished in : '+(activityData.minute*60+activityData.seconde))});
	    }
	    
	});
});


function Chrono(initCallback,initSeconde,initMinute) {
    
	var minute = (initMinute != undefined) ? initMinute : 0 ;
    var seconde = (initSeconde != undefined)? initSeconde :-1;
    var callback = (initCallback != undefined)? initCallback : function(){return;};
    var interval = undefined;
    
    this.getMinute = function(){return minute;};
    this.getSeconde = function(){return seconde;}
    
	this.run = function(){

           interval = setInterval(function() {
             seconde++;
            if(seconde == 59){
                minute++;
                seconde=0;
            }
		      callback( seconde , minute );
	       }, 1000);
    }
    
    this.stop = function(){
        if(interval != undefined){
            clearInterval(interval);
        }
    };
    
}
//-------------------------------------------------------------------------------------------
function get_leadership_response(question_num, callbackTrue, callbackFalse){
	console.log('get_leadership_response:'+ question_num );
	leadership_questions_getKey(RESPONSE_DATA_KEY_PREFIX+question_num, callbackTrue, callbackFalse);
};

function set_leadership_response(question_num, value, callback){
	leadership_questions_setKey(RESPONSE_DATA_KEY_PREFIX+question_num, value, callback);
};

//-------------------------------------------------------------------------------------------
function get_leadership_questions_progress(callbackTrue, callbackFalse){
	leadership_questions_getKey(LEADERSHIP_PROGRESS,callbackTrue,callbackFalse);
};

function set_leadership_questions_progress(value, callback){
	leadership_questions_setKey(LEADERSHIP_PROGRESS, value, callback);
};
//-------------------------------------------------------------------------------------------
function get_leadership_questions_jocker(callbackTrue, callbackFalse){
	leadership_questions_getKey(JOCKERS ,callbackTrue,callbackFalse);
};

function set_leadership_questions_jocker(value, callback){
	leadership_questions_setKey(JOCKERS , value, callback);
};

//-------------------------------------------------------------------------------------------
function get_leadership_questions_time(callbackTrue, callbackFalse){
	leadership_questions_getKey(CHRONO ,callbackTrue,callbackFalse);
};
function set_leadership_questions_time(value, callback){
	leadership_questions_setKey(CHRONO , value, callback);
};





