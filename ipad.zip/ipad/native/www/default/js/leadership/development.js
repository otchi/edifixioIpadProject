
/* JavaScript content from js/leadership/development.js in folder common */
//leadershipDevelopmentcheckboxCreate();
$(document).on("pagebeforeshow", "#" + leadershipDevelopmentPage.id, function(event) {
	
	$( "#" + leadershipDevelopmentPage.id +' #main-content').css('display','none');
	$( "#" + leadershipDevelopmentPage.id +' #developpement_leadership').load( "pages/leadership/developpementDesign.html",function(){
		
		
		
		translatePage(leadershipDevelopmentPage.id);
		$('#'+ leadershipDevelopmentPage.id+' .mon-dashboard-anchor').attr('href',"#"+dashBoardPage.id);
		$('#' + leadershipDevelopmentPage.id+' input[type=text][data-id]').attr('placeholder',$.i18n.prop("leadership.development.checkbox.message"));
		$('#' + leadershipDevelopmentPage.id+' input[type=checkbox][data-id]').attr('disabled','disabled');
			getActivityStatus(leadershipDevelopmentPage.id, function(status){
				if(status == SCREEN_STATUS_FINISHED){
					$('#'+ leadershipDevelopmentPage.id+' input').attr('disabled','disabled');
				}
			});
			$('#'+ leadershipDevelopmentPage.id+ ' .info-img').attr('href',"#"+leadershipDevelopmentPage.id+annotationPanelId);
			
			leadership_development_getKey("own_motivations_1", function(liste){
				for(value in liste){
					$('#' + leadershipDevelopmentPage.id +' input[value='+liste[value][0]+']').prop("checked",true);
				}
			}, function(){
				console.log('motivation left are not setted yet');
			});
			
			leadership_development_getKey("own_motivations_2", function(liste){
				for(value in liste){
					$('#' + leadershipDevelopmentPage.id +' input[type=checkbox][data-id='+liste[value][0]+']').prop("checked",true);
					$('#' + leadershipDevelopmentPage.id +' input[type=text][data-id='+liste[value][0]+']').val(liste[value][1]);
				}
				leadership_development_validatePage();
			}, function(){
				leadership_development_validatePage();
				console.log('motivation left are not setted yet');
			});
			
		
			$('#'+ leadershipDevelopmentPage.id+' [type=checkbox]').on("click", function(e) {
				var position = $(this).attr('value');
				var value = $.i18n.prop('leadership.development.checkbox.'+position);
				var isSelected = $(this).is(':checked');
				setActivityStatus(leadershipDevelopmentPage.id, SCREEN_STATUS_IN_PROGRESS, function(){
					if(isSelected){
						leadership_development_setKey("own_motivations_1",position,value);
					}else{
						leadership_development_deleteKey("own_motivations_1",position);
					}
					leadership_development_validatePage();
				});
			});
			
			$("#" + leadershipDevelopmentPage.id +" input[type=text]").on("keyup", function(e) {
				var position = $(this).attr('data-id');
				var value = $(this).val().trim();
				setActivityStatus(leadershipDevelopmentPage.id, SCREEN_STATUS_IN_PROGRESS, function(){
					if((value)||(value.length == 0)){
						if(value.length == 0){
							leadership_development_deleteKey("own_motivations_2",position,function(){
								$('#' + leadershipDevelopmentPage.id +' input[type=checkbox][data-id='+position+']').prop("checked",false);
								leadership_development_validatePage();
							});
						}
						else {
							leadership_development_setKey("own_motivations_2",position,value,function(){
								$('#' + leadershipDevelopmentPage.id +' input[type=checkbox][data-id='+position+']').prop("checked",true);
								leadership_development_validatePage();
							});
						}
					}
				});
			});
			
			$('#'+ leadershipDevelopmentPage.id+' [data-class=finish]').on("click", function(e) {
				if(($("#" + leadershipDevelopmentPage.id+" [data-class=finish] img").attr('src')) =='design/assets/img/block-img/ok-on.png'){
					leadership_development_setKey("leadership_development_validate", "1", "true", function(){
						setActivityStatus(leadershipDevelopmentPage.id, SCREEN_STATUS_FINISHED, function(){
							set_Status_Progression("leadership_progression", 37, function(){
								setActivityStatus(leadershipQuestionsPage.id, SCREEN_STATUS_ACCESSIBLE, function(){
									$.mobile.changePage("#" +transitionLeadership.id);
								});
							});
						});
					});
				} 
			});
			$('#'+ leadershipDevelopmentPage.id+' [data-class=next]').on("click", function(e) {
        			get_Status_Progression(PROGRESS_STAPE_1, function(progress){
        				if(progress<2){
        					set_Status_Progression(PROGRESS_STAPE_1, 2,function(){return 0;});
        					chrono.stop();
        				}
        				$.mobile.changePage("#"+transitionLeadership.id);
        			},
        			function(){return; }
        			);
			});
	});
});

function leadershipDevelopmentcheckboxCreate(){
	$fieldSetDevelopement = $('#' + leadershipDevelopmentPage.id+ ' .identFieldset_leadership_development_1');
	var numberCheckbox = parseInt($.i18n.prop('leadership.development.checkbox.number'));
	for(var i=1;i< numberCheckbox+1;i++){
		var htmlCode = '<label for="leadership_development_checkbox_' + i + '">' + $.i18n.prop('leadership.development.checkbox.'+i) + '</label>';
		htmlCode += '<input name="leadership_development_checkbox_' + i + '" id="leadership_development_checkbox_' + i + '" type="checkbox" data-mini="true" value="' + i + '"/>';
		$fieldSetDevelopement.append(htmlCode);
	}
	$('#' + leadershipDevelopmentPage.id+ ' textarea[placeholder]').attr('placeholder',$.i18n.prop('leadership.development.checkbox2.1'));
}





function leadership_development_validatePage(){
	getActivityStatus(leadershipDevelopmentPage.id, function(activityStatus){
		if(activityStatus == SCREEN_STATUS_FINISHED){
			$('#'+ leadershipDevelopmentPage.id+' [data-class=finish]').css('display','none');
			$('#'+ leadershipDevelopmentPage.id+' [data-class=next]').removeAttr('style');
		}else{
			var finish = true;
			
			if($('#'+ leadershipDevelopmentPage.id+'  [type=checkbox]:checked').length > 2)finish = false;
			else finish = true;
			
			if(finish){
				if($("#" + leadershipDevelopmentPage.id+" [data-class=finish] img" ).attr('src') != "design/assets/img/block-img/ok-off.png"){
					$($("#" + leadershipDevelopmentPage.id+" [data-class=finish] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-off.png');
				}
			}
			else {
				if($("#" + leadershipDevelopmentPage.id+" [data-class=finish] img" ).attr('src') != "design/assets/img/block-img/ok-on.png"){
					$($("#" + leadershipDevelopmentPage.id+" [data-class=finish] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-on.png');
				}
			}
		}
	});
	
}

