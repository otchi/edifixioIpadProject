
/* JavaScript content from js/leadership/fiveLeaders.js in folder common */

var leadershipFiveLeadersCurrent = 0;
// a l'ouverture de la page
$(document).on("pagebeforeshow", "#" + leadershipFiveLeadersPage.id, function(event) {
	$( "#" + leadershipFiveLeadersPage.id +' #main-content').css('display','none');
	$( "#" + leadershipFiveLeadersPage.id +' #developpement_fiveLeaders').load( "pages/leadership/fiveLeaders_design.html",function(){
		
		
		translatePage(leadershipFiveLeadersPage.id);
		$( "#" + leadershipFiveLeadersPage.id +' [data-link = back]').attr('href','#'+dashBoardPage.id) ;
		leadership_fiveLeaders_getKey("currentLeader", function(values){
			leadershipFiveLeadersCurrent = values[0][0];
			//selectionne le leader courant retourné precedement
			leadership_fiveLeaders_showLeader(leadershipFiveLeadersCurrent,false);
		}, function(){
			// si c'est la premiere fois qu'on ouvre la page, sauvegarde du leader comme leader courant et le selectionner
			leadership_fiveLeaders_setState_leader("leader_1", "en-cours",function(){
				leadership_fiveLeaders_showLeader("1",true);
			});
		});
		
		$('#'+leadershipFiveLeadersPage.id+' a[data-leader]').each(function(i) {
			leadership_fiveLeaders_getKeyInformation("who_response",i+1, function(value){
				$("#" + leadershipFiveLeadersPage.id+" a[data-leader="+(i+1)+"] [data-class =labelLeader]" ).html(unescape(value));
				$($('#'+leadershipFiveLeadersPage.id+' a[data-leader='+(i+1)+']').parent()).attr('class','en-pause');
			}, function(){
				console.log('who_response leader '+(i+1)+' information not setted yet');
			});
			leadership_fiveLeaders_getKeyInformation("leader_validation", i+1 , function(value){
				$("#" + leadershipFiveLeadersPage.id+" a[data-leader="+(i+1)+"] [data-class=checked_leader]").removeAttr("style");
			}, function(){
				console.log("leader "+(i+1) +" is not validate");
			});
		});
		

		$("#" + leadershipFiveLeadersPage.id +" [data-class=fiveLeaders_why]" ).on("keyup", function(e) {
			var value = $(this).val().trim();
			if((value)||(value.length == 0))
				if(value.length == 0){
					leadership_fiveLeaders_deleteKey_position("why_response",leadershipFiveLeadersCurrent);
					leadership_fiveLeaders_validateLeader();
				}
				else {
					leadership_fiveLeaders_setKey("why_response",leadershipFiveLeadersCurrent,escape(value));
					leadership_fiveLeaders_validateLeader();
				}
		});
		$("#" + leadershipFiveLeadersPage.id+" [data-class=fiveLeaders_who]" ).on("keyup", function(e) {
			var value = $(this).val().trim();
			leadership_fiveLeaders_deleteLeaderValidation(function(){
				
				if((value)||(value.length == 0))
					if(value.length == 0){
						leadership_fiveLeaders_deleteKey_position("who_response",leadershipFiveLeadersCurrent,function(){
							$("#" + leadershipFiveLeadersPage.id+" a[data-leader="+leadershipFiveLeadersCurrent+"] [data-class =labelLeader]" ).html("LEADER "+leadershipFiveLeadersCurrent);
							leadership_fiveLeaders_validateLeader();
						});
					}else{
						leadership_fiveLeaders_setKey("who_response",leadershipFiveLeadersCurrent, escape(value) ,function(){
							$("#" + leadershipFiveLeadersPage.id+" a[data-leader="+leadershipFiveLeadersCurrent+"] [data-class =labelLeader]" ).html(value);
							leadership_fiveLeaders_validateLeader();
						});
					}
			});
		});
		$('#'+leadershipFiveLeadersPage.id+' a[data-leader]').on("click", function(e) {
			var leaderPosition = leadershipFiveLeadersCurrent;
			leadershipFiveLeadersCurrent = $(this).attr("data-leader");
			if(leaderPosition != leadershipFiveLeadersCurrent){
				leadership_fiveLeaders_getKeyInformation("leader_validation", leaderPosition, function(value){
					leadership_fiveLeaders_setState_leader("leader_"+leaderPosition, "en-pause", function(){
						$($('#'+leadershipFiveLeadersPage.id+' a[data-leader='+leaderPosition+']').parent()).attr('class','en-pause');
					});
				}, function(){
					leadership_fiveLeaders_setState_leader("leader_"+leaderPosition, "en-pause", function(){
						$($('#'+leadershipFiveLeadersPage.id+' a[data-leader='+leaderPosition+']').parent()).attr('class','en-pause');
					});
				});
				leadership_fiveLeaders_showLeader(leadershipFiveLeadersCurrent,true);
			}
			
		});
		$("#" + leadershipFiveLeadersPage.id +" [data-class=quality]" ).on("keyup", function(e) {
			var numberQuality = $(this).attr("data-position"); 
			var value = $(this).val().trim();
			if((value)||(value.length == 0)){
				if(value.length == 0)
					leadership_fiveLeaders_deleteKey_position("quality_response_"+numberQuality,leadershipFiveLeadersCurrent,function(){
						if(numberQuality == 1){
							$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_2]').css("cssText", "display: block !important;");
							$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=2]').css("cssText", "display: none !important;");
							$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').css("cssText", "display: block !important;");
							$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=3]').css("cssText", "display: none !important;");
							leadership_fiveLeaders_deleteKey_position("quality_response_2",leadershipFiveLeadersCurrent,function(){
								leadership_fiveLeaders_deleteKey_position("quality_response_3",leadershipFiveLeadersCurrent,function(){
									$("#" + leadershipFiveLeadersPage.id +" [data-class=quality][data-position=2]" ).val("");
									$("#" + leadershipFiveLeadersPage.id +" [data-class=quality][data-position=3]" ).val("");
									leadership_fiveLeaders_validateLeader();
								});
							});
						}else{
							if(numberQuality == 2){
								$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').css("cssText", "display: block !important;");
								$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=3]').css("cssText", "display: none !important;");
								leadership_fiveLeaders_deleteKey_position("quality_response_3",leadershipFiveLeadersCurrent,function(){
									$("#" + leadershipFiveLeadersPage.id +" [data-class=quality][data-position=3]" ).val("");
									leadership_fiveLeaders_validateLeader();
								});
							}
						}
					});
				else {
					leadership_fiveLeaders_setKey("quality_response_"+numberQuality,leadershipFiveLeadersCurrent,escape(value));
					leadership_fiveLeaders_validateLeader();
				}
				
			}
		});
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_2]').on("click", function(e) {
			
			var value = $("#" + leadershipFiveLeadersPage.id +" [data-class=quality][data-position=1]" ).val().trim();
			if(value.length > 0){
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_2]').css("cssText", "display: none !important;");
				$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=2]').css("cssText", "display: block !important;");
			}
			$('[data-quality-postion]').css('width','30%');
			
			$('#'+leadershipFiveLeadersPage.id+' #inputqualiy2').click();
		});
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').on("click", function(e) {
			
			var value = $("#" + leadershipFiveLeadersPage.id +" [data-class=quality][data-position=2]" ).val().trim();
			if(value.length > 0){
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').css("cssText", "display: none !important;");
				$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=3]').css("cssText", "display: block !important;");
			}
			$('[data-quality-postion]').css('width','30%');
			$('#'+leadershipFiveLeadersPage.id+' #inputqualiy3').click();
			
		});
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=validate]').on("click", function(e) {
			setActivityStatus(leadershipFiveLeadersPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				var value = $('#'+ leadershipFiveLeadersPage.id+' [data-class=validate] img').attr('src');
				if(value == "design/assets/img/block-img/ok-on.png" ){
					leadership_fiveLeaders_setKey("leader_validation", leadershipFiveLeadersCurrent,"true");
					leadership_fiveLeaders_lockLeader(true);
				}
			});
		});
		
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=fiveLeaders_why]').on("keyup", function(e) {
			leadership_fiveLeaders_validateLeader();
		});
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=quality]').on("keyup", function(e) {
			leadership_fiveLeaders_validateLeader();
		});
		$('#'+leadershipFiveLeadersPage.id+' a[data-class=finish]').on("click", function(e) {
			getActivityStatus(leadershipFiveLeadersPage.id, function(status){
				if(status == SCREEN_STATUS_FINISHED) $.mobile.changePage("#"+leadershipFiveLeadersChoosePage.id);
				else{
					setActivityStatus(leadershipFiveLeadersPage.id, SCREEN_STATUS_FINISHED, function() {
						set_Status_Progression("leadership_progression", 12 , function(){
							console.log(leadershipFiveLeadersPage.id + ' activity is now finished');
							setActivityStatus(leadershipFiveLeadersChoosePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
								console.log(leadershipFiveLeadersChoosePage.id + ' activity is now accessible');
								$.mobile.changePage("#"+leadershipFiveLeadersChoosePage.id);
							});
						});
					});
				}
			});
		});
		$('#inputqualiy3, #inputqualiy2, #inputqualiy1,#'+leadershipFiveLeadersPage.id+' #who,#'+leadershipFiveLeadersPage.id+' #why').on("click", function(e) {
			$('#'+leadershipFiveLeadersPage.id+ ' #who').blur();
			$('#'+leadershipFiveLeadersPage.id+ ' #why').blur();
			$('#'+leadershipFiveLeadersPage.id+' #inputqualiy1').blur();
			$('#'+leadershipFiveLeadersPage.id+' #inputqualiy2').blur();
			$('#'+leadershipFiveLeadersPage.id+' #inputqualiy3').blur();
			$(this).focus();
		});
		
		
		$('#'+leadershipFiveLeadersPage.id+' a[data-class=next]').on("click", function(e) {
			$.mobile.changePage("#"+leadershipFiveLeadersChoosePage.id);
		});
	});
});


// fonctions utilisées :

function leadership_fiveLeaders_showWhy(position,data){
	$("#" + leadershipFiveLeadersPage.id +" [data-identification="+position+"]").val(data);
}
function leadership_fiveLeaders_showWho(position,data){
	$("#" + leadershipFiveLeadersPage.id +" [data-ident="+position+"]").val(data);
}

function leadership_fiveLeaders_showLeader(position,state) {
	
	if(state){
	leadership_fiveLeaders_deleteKey("currentLeader", function(){
		leadership_fiveLeaders_setKey("currentLeader", position , "false", function(){
			leadershipFiveLeadersCurrent = position;
		});
	});
	}
	leadership_fiveLeaders_restorInformationLeader(position);
}
function leadership_fiveLeaders_restorInformationLeader(position){
	leadership_fiveLeaders_setState_leader("leader_"+position, "en-cours", function(){
		$($('#'+leadershipFiveLeadersPage.id+' a[data-leader='+position+']').parent()).attr('class','en-cours');
	});
	$("#" + leadershipFiveLeadersPage.id+" input" ).val("");
	$("#" + leadershipFiveLeadersPage.id+" textarea" ).val("");
	leadership_fiveLeaders_getKeyInformation("who_response",position, function(value){
		$("#" + leadershipFiveLeadersPage.id+" [data-class=fiveLeaders_who]" ).val(unescape(value));
	}, function(){
		console.log("who_response information not setted yet");
	});
	leadership_fiveLeaders_getKeyInformation("why_response",position, function(value){
		$("#" + leadershipFiveLeadersPage.id+" [data-class=fiveLeaders_why]" ).val(unescape(value));
	}, function(){
		console.log("why_response information not setted yet");
	});
	leadership_fiveLeaders_getKeyInformation("quality_response_1",position, function(value){
		$("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=1]").val(unescape(value));
	}, function(){
		console.log("quality_response_1 information not setted yet");
	});
	leadership_fiveLeaders_getKeyInformation("quality_response_2",position, function(value){
		$("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=2]").val(unescape(value));
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_2]').css("cssText", "display: none !important;");
		$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=2]').css("cssText", "display: block !important;");
	}, function(){
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_2]').css("cssText", "display: block !important;");
		$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=2]').css("cssText", "display: none !important;");
		console.log("quality_response_2 information not setted yet");
	});
	leadership_fiveLeaders_getKeyInformation("quality_response_3",position, function(value){
		$("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=3]").val(unescape(value));
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').css("cssText", "display: none !important;");
		$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=3]').css("cssText", "display: block !important;");
	}, function(){
		$('#'+ leadershipFiveLeadersPage.id+' [data-class=ajoutQuality_3]').css("cssText", "display: block !important;");
		$('#'+ leadershipFiveLeadersPage.id+' [data-quality-postion=3]').css("cssText", "display: none !important;");
		console.log("quality_response_3 information not setted yet");
	});
	leadership_fiveLeaders_getState_leader(function(values){
		for(var i = 0;i<values.length;i++){
			$($('#'+leadershipFiveLeadersPage.id+' a[data-leader='+values[i][0][7]+']').parent()).attr('class',values[i][1]);
		}
	}, null);
	
	leadership_fiveLeaders_leaderValidate(position);
}
function leadership_fiveLeaders_leaderValidate(position){
	
	leadership_fiveLeaders_getKeyInformation("leader_validation", position, function(value){
		leadership_fiveLeaders_lockLeader(true);
	}, function(){
		leadership_fiveLeaders_lockLeader(false);
		console.log("leader "+position+" is not validate");
	});
}
function leadership_fiveLeaders_lockLeader(state){
	leadership_fiveLeaders_validateLeader();
	if(state){
		getActivityStatus(leadershipFiveLeadersPage.id, function(status){
			if(status == SCREEN_STATUS_FINISHED){
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=fiveLeaders_who]').attr('disabled','disabled');
				$('#'+leadershipFiveLeadersPage.id+' [data-class=next]').removeAttr("style");
				$('#'+leadershipFiveLeadersPage.id+' [data-class=validate]').css('display','none');
				$('#'+leadershipFiveLeadersPage.id+' [data-class=finish]').css('display','none');
				
			}else{
				leadership_fiveLeaders_getKey("leader_validation", function(values){
					if(values.length==5)$('#'+leadershipFiveLeadersPage.id+' [data-class=finish]').removeAttr("style");
				}, function(){
					console.log('page is not validate yet');
				});
			}
			$("#" + leadershipFiveLeadersPage.id+" a[data-leader="+leadershipFiveLeadersCurrent+"] [data-class=checked_leader]").removeAttr("style");
			$('#'+ leadershipFiveLeadersPage.id+' [data-class=quality]').attr('disabled','disabled');
			$('#'+ leadershipFiveLeadersPage.id+' [data-class=fiveLeaders_why]').attr('disabled','disabled');
			$('#'+ leadershipFiveLeadersPage.id+' [data-class=validate]').css("display", "none");
			
		});
		
	}else{
		getActivityStatus(leadershipFiveLeadersPage.id, function(status){
			if(status == SCREEN_STATUS_FINISHED){
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=fiveLeaders_who]').attr('disabled','disabled');
				$('#'+leadershipFiveLeadersPage.id+' [data-class=next]').removeAttr("style");
				$('#'+leadershipFiveLeadersPage.id+' [data-class=validate]').css('display','none');
				$('#'+leadershipFiveLeadersPage.id+' [data-class=finish]').css('display','none');
			}else{
				$("#" + leadershipFiveLeadersPage.id+" input" ).removeAttr('disabled');
				$("#" + leadershipFiveLeadersPage.id+" textarea" ).removeAttr('disabled');
			}
			$('#'+ leadershipFiveLeadersPage.id+' [data-class=validate]').removeAttr("style");
		});
	}
}
function leadership_fiveLeaders_verifCharacter(callback){
	var whoCurrent = $("#" + leadershipFiveLeadersPage.id+" a[data-leader="+leadershipFiveLeadersCurrent+"] [data-class=labelLeader]").html();
	leadership_fiveLeaders_getListeValueKey("leader_validation",function(values){
		var different = true;
		for(var i=0;i<values.length;i++){
			if(whoCurrent == ($('#' + leadershipFiveLeadersPage.id+' a[data-leader='+values[i]+'] [data-class=labelLeader]').html()))
				different = false;
		}
		callback(different);
	}, function(){
		console.log("no page leader is validated");
		callback(true);
	});
}
var leadership_fiveLeaders_t=1,
    leadership_fiveLeaders_tt = 1;
function leadership_fiveLeaders_validateLeader(){
	getActivityStatus(leadershipFiveLeadersPage.id, function(status){
		if(status != SCREEN_STATUS_FINISHED)
			setActivityStatus(leadershipFiveLeadersPage.id, SCREEN_STATUS_IN_PROGRESS);
	});
	
		var verifWho = false,
			verifWhy = false,
			verifQuality1=false,
			verifQuality2=false,
			verifQuality3=false;
		if( $("#" + leadershipFiveLeadersPage.id+" [data-class=fiveLeaders_who]" ).val().trim().length > 0 ) verifWho =true;
		else console.log("please complete who field");
		if( $("#" + leadershipFiveLeadersPage.id+" [data-class=fiveLeaders_why]" ).val().trim().length > 0 ) verifWhy =true;
		else console.log("please complete why field");
		if( $("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=1]" ).val().trim().length > 0 ) verifQuality1 =true;
		else console.log("please complete quality 1 field");
		if( $("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=2]" ).val().trim().length > 0 ) verifQuality2 =true;
		else console.log("please complete quality 2 field");
		if( $("#" + leadershipFiveLeadersPage.id+" [data-class=quality][data-position=3]" ).val().trim().length > 0 ) verifQuality3 =true;
		else console.log("please complete quality 3 field");
		
		leadership_fiveLeaders_verifCharacter(function(verifChar){
			$('[data-quality-postion]').css('width','30%');
			console.log('verifChar = '+ verifChar);
			if(leadership_fiveLeaders_t==1){
				if((verifWho)&&(verifWhy)&&(verifQuality1)&&(verifQuality2)&&(verifQuality3)&&(verifChar)){
				
					$($("#" + leadershipFiveLeadersPage.id+" [data-class=validate] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-on.png');
					leadership_fiveLeaders_tt=1;
					leadership_fiveLeaders_t = 0;
				
				}
			}
			if(leadership_fiveLeaders_tt==1){
				if((!verifWho)||(!verifWhy)||(!verifQuality1)||(!verifQuality2)||(!verifQuality3)||(!verifChar)){
					
					$($("#" + leadershipFiveLeadersPage.id+" [data-class=validate] img" ).removeAttr("src")).attr('src','design/assets/img/block-img/ok-off.png');
					leadership_fiveLeaders_t = 1;
					leadership_fiveLeaders_tt = 0;
				
				}	
			}
		});
}
function leadership_fiveLeaders_deleteLeaderValidation(callback){
	if($('[data-class=fiveLeaders_why]').attr('disabled') != null && $('[data-class=fiveLeaders_why]').attr('disabled') == 'disabled'){
		leadership_fiveLeaders_getKeyInformation("leader_validation", leadershipFiveLeadersCurrent, function(value){
		// enlever la validation
			leadership_fiveLeaders_deleteKey_position("leader_validation",leadershipFiveLeadersCurrent,function(){
				leadership_fiveLeaders_t=1,
			    leadership_fiveLeaders_tt = 1;
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=quality]').removeAttr("disabled");
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=fiveLeaders_why]').removeAttr("disabled");
				$('#'+ leadershipFiveLeadersPage.id+' [data-class=validate]').css("cssText", "display: block !important;");
				$('#'+ leadershipFiveLeadersPage.id+' [data-leader = '+leadershipFiveLeadersCurrent+'] img').css("display", "none");
				$('#'+leadershipFiveLeadersPage.id+' [data-class=finish]').css("display", "none");
				
			});
	}, function(){
		// ne rien faire
	});
	}
	if (callback && callback != '') {
		callback();
	}
}
