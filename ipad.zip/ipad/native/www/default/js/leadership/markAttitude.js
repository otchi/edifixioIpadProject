
/* JavaScript content from js/leadership/markAttitude.js in folder common */

var leadershipMarkAttitudeCurrent = "1";
$(document).on('pagebeforeshow', '#' + leadershipMarkAttitudePage.id, function(event) {
	leadership_attitude_getKey('attitude_current', function(value){
		leadershipMarkAttitudeCurrent = value;
		leadershipMarkAttitude();
	}, function(){
		leadership_attitude_setKey('attitude_current', '1',function(){
			leadershipMarkAttitude();
		});
	});
});

$('#'+ leadershipMarkAttitudePage.id+' [data-class=finish_step1]').on("click", function(e) {
	setActivityStatus(leadershipMarkAttitudePage.id, SCREEN_STATUS_IN_PROGRESS, function(){
		var MarkAttitude = parseInt($('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider').val());
		if(MarkAttitude < 0) MarkAttitude = 100 + MarkAttitude;
		leadership_attitude_getKey('attitude_current', function(value){
			leadershipMarkAttitudeCurrent = parseInt(value)+1;
			leadership_attitude_setKey('attitude_current', leadershipMarkAttitudeCurrent, function(){
				leadership_attitude_setKey('reponse_attitude_'+value, MarkAttitude, function(){
					var labelBarometre = null;
					if(MarkAttitude >= 0) labelBarometre = $.i18n.prop('leadership.attitude.mark.'+value+'.high');
					else labelBarometre = $.i18n.prop('leadership.attitude.mark.'+value+'.low');
					leadership_attitude_setKey('reponse_barometre_'+value, labelBarometre, function(){
						leadershipMarkAttitude();	
					});
				});
			});
		},null);
	});
});

$('#'+ leadershipMarkAttitudePage.id+' [data-class=finish_step2]').on("click", function(e) {
	setActivityStatus(leadershipMarkAttitudePage.id, SCREEN_STATUS_FINISHED, function(){
		set_Status_Progression("leadership_progression", 100, function(){
			$.mobile.changePage("#" + leadershipSummaryPage.id);
		});
	});
});

$('#'+ leadershipMarkAttitudePage.id+' [data-class=next]').on("click", function(e) {
	$.mobile.changePage("#" + leadershipSummaryPage.id);
});

function leadershipMarkAttitude(){
	
	$('#'+ leadershipMarkAttitudePage.id+' .leadership_markAttitude_label').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent));
	$('#'+ leadershipMarkAttitudePage.id+' .low').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.low'));
	$('#'+ leadershipMarkAttitudePage.id+' .middle').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.middle'));
	$('#'+ leadershipMarkAttitudePage.id+' .high').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.high'));
	$('#'+ leadershipMarkAttitudePage.id+' .popup_low_text').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.popup.low'));
	$('#'+ leadershipMarkAttitudePage.id+' .popup_middle_text').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.popup.middle'));
	$('#'+ leadershipMarkAttitudePage.id+' .popup_high_text').html($.i18n.prop('leadership.attitude.mark.'+leadershipMarkAttitudeCurrent+'.popup.high'));
	var finish = parseInt($.i18n.prop('leadership.attitude.mark.number'));
	$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider').val('0').slider("refresh");
	
	if(leadershipMarkAttitudeCurrent-1 == finish) {
		$('#'+ leadershipMarkAttitudePage.id+' [data-class=attitude_step_1]').css('display','none');
		$('#'+ leadershipMarkAttitudePage.id+' [data-class=attitude_step_2]').css('display','block');
		//valider la partie 1
			leadership_attitude_getKey('reponse_attitude_1', function(value){
				leadership_attitude_getKey('reponse_barometre_1', function(label){
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider_1').val(value).slider("refresh");
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_left_1').html(label);
				},null);
			}, null);
			leadership_attitude_getKey('reponse_attitude_2', function(value){
				leadership_attitude_getKey('reponse_barometre_2', function(label){
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider_2').val(value).slider("refresh");
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_left_2').html(label);
				},null);
			}, null);
			leadership_attitude_getKey('reponse_attitude_3', function(value){
				leadership_attitude_getKey('reponse_barometre_3', function(label){
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider_3').val(value).slider("refresh");
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_left_3').html(label);
				},null);
			}, null);
			leadership_attitude_getKey('reponse_attitude_4', function(value){
				leadership_attitude_getKey('reponse_barometre_4', function(label){
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider_4').val(value).slider("refresh");
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_left_4').html(label);
				},null);
			}, null);
			leadership_attitude_getKey('reponse_attitude_5', function(value){
				leadership_attitude_getKey('reponse_barometre_5', function(label){
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_slider_5').val(value).slider("refresh");
					$('#'+ leadershipMarkAttitudePage.id+' .leadership_attitude_left_5').html(label);
				},null);
			}, null);
	}
	getActivityStatus(leadershipMarkAttitudePage.id, function(status){
		if(status == SCREEN_STATUS_FINISHED){
			$('#'+ leadershipMarkAttitudePage.id+'_backpageId').attr('href','#'+leadershipAttitudePage.id);
			$('#'+leadershipMarkAttitudePage.id+' button[data-class=finish_step2]').css('display','none');
			$('#'+leadershipMarkAttitudePage.id+' button[data-class=next]').css('display','block');
		}
	});
}
