
/* JavaScript content from js/leadership/transitionLeadership.js in folder common */
$(document).on("pagebeforeshow","#" + transitionLeadership.id,function(event) {
	
		$("#" + transitionLeadership.id + ' #transitionLeadership').load("pages/leadership/transitionLeadership_disign.html",function() {
			//--------------------------------------------------------------------------------------------
			// process displaying CSS class and redirection using a  leadership_activity1_progress DB value
				get_Status_Progression(PROGRESS_STAPE_1, function(progress){
							
						console.log("leadership_activity1_progress : "+progress);
						$("#" + transitionLeadership.id+" div.nav-heading").find("p").text("Exercice "+progress+"/6");
					
						$("#" + transitionLeadership.id +" ul.list-inline").find("li") 
											.filter(function(index) {return index < progress;}) 
											.removeClass("transition-inactive-li").addClass("transition-active-li").find(".transition-inactive-block")
											.removeClass("transition-inactive-block").addClass("transition-active-block");
								
						$("#" + transitionLeadership.id +" ul.list-inline").find("li")
											.filter( function(index){return index == progress - 1;})
											.addClass("transition-active-li-end");
								
						$("#" + transitionLeadership.id +' [data-id=next]').on("click", function(e) {
								
							switch (parseInt(progress)) {
								case 1: $.mobile.changePage("#"+leadershipDevelopmentPage.id);
									break;
								case 2: $.mobile.changePage("#"+ leadershipQuestionsInYourHistoryIntroduction.id);
									break;
								case 3: $.mobile.changePage("#"+ leadershipStereotypePage.id);
									break;
								case 4: $.mobile.changePage("#"+ leadershipMoiEtLe.id);
									break;
								case 5: $.mobile.changePage("#"+ les5AttitudesLeaderIntro.id);
									break;
								default:
									break;
							}	
								
						});
						
						$("#" + transitionLeadership.id+" .list-inline").find("li").on("click",function(){
							
							var li_index=parseInt($(this).attr('id').charAt($(this).attr('id').length-1));
							console.log("li-index"+li_index);
							
							if(li_index<=progress){
								
								switch (li_index) {
									case 1: $.mobile.changePage("#"+leadershipFiveLeadersPage.id);
										break;
									case 2: $.mobile.changePage("#"+leadershipDevelopmentPage.id);
										break;
									case 3: $.mobile.changePage("#"+leadershipQuestionsInYourHistoryIntroduction.id);
										break;
									case 4: $.mobile.changePage("#"+leadershipStereotypePage.id);
										break;
									case 5: $.mobile.changePage("#"+leadershipMoiEtLe.id);
										break;
									case 6: $.mobile.changePage("#"+les5AttitudesLeaderIntro.id);
										break;
									default:
										break;
								}			
							}
							
						});
						
					}, function(){console.log("leadership_activity1_progress is not founded");
				});
						
				$("#" + transitionLeadership.id +' [data-id=back-dashboard]').on("click", function(e) {
					$.mobile.changePage("#"+dashBoardPage.id);
				});

			});
	});

