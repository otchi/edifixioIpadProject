
/* JavaScript content from js/calendar/calendar.js in folder common */

	
// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + calendarPage.id, function(event) {
	
	
});


