
/* JavaScript content from js/webSQL/projectMyself/InFiveYears_webSQL.js in folder common */
var table_projectMyself_InFiveYears_Picture = "T_PROJECTMYSELF_INFIVEYEARS_VERBS";
var table = "T_TABLE";
var table_projectMyself_InFiveYears_key = "T_PROJECTMYSELF_INFIVEYEARS_KEY"; 
var table_projectMyself_CardRoutes_key = "T_PROJECTMYSELF_CARDSROUTES_KEY";

var field_InFiveYears_PicVideo_id = "idpicture";

var field_InFiveYears_value = "Path";
var field_projectMyself_InFiveYears_key = "projectMyself_InFiveYears_key";
var field_projectMyself_InFiveYears_value= "projectMyself_InFiveYears_value";
var field_projectMyself_CardRoutes_key = "projectMyself_CardRoutes_key";
var field_projectMyself_CardRoutes_value ="projectMyself_CardRoutes_value";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_InFiveYears_Picture + ' (' + field_InFiveYears_PicVideo_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_InFiveYears_value + ' TEXT)');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_InFiveYears_Picture);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_InFiveYears_key + '(' + field_projectMyself_InFiveYears_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_projectMyself_InFiveYears_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_InFiveYears_key);
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_CardRoutes_key + '(' + field_projectMyself_CardRoutes_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_projectMyself_CardRoutes_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_CardRoutes_key);




function addImageTable(valueId, value, callback) {
	console.log('addImageTable '+valueId+' entering '+value);
	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_InFiveYears_Picture + ' (' + field_InFiveYears_PicVideo_id + ',' + field_InFiveYears_value + ') VALUES (' + valueId + ',"' + value + '")';
	console.log(query);
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllInFiveYearsImages(callback) {
	console.log('getAllVisionImages entering');
	var query = 'SELECT * FROM ' + table_projectMyself_InFiveYears_Picture;
	console.log(query);
	var imagesMap = new Array();
	

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var liste = new Array();
					var imageId = record[field_InFiveYears_PicVideo_id];
					var value = record[field_InFiveYears_value];
					liste.push(imageId);
					liste.push(value);
					imagesMap.push(liste);
				}
			} 

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}



function addInprojectMyselfKey(key,value, callback) {
	console.log('addInprojectMyselfKey entering with key = ' + key + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_InFiveYears_key + ' (' + field_projectMyself_InFiveYears_key + ',' + field_projectMyself_InFiveYears_value + ') VALUES ("' + key + '","'+ value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}


function getInprojectMyselfKey(key,callback) {
		console.log('getCompassVisionValue  entering');

		livebook_bdd.readTransaction(function(tx) {
			tx.executeSql('SELECT * FROM ' + table_projectMyself_InFiveYears_key + ' WHERE ' + field_projectMyself_InFiveYears_key + ' = ?', [ key ], function(tx, data) {

				if (data.rows && data.rows.length != 0) {
					console.log(data.rows.length);
					for (var i = 0; i < data.rows.length; i++) {
						var record = data.rows.item(i);
						var counterValue = record[field_projectMyself_InFiveYears_value];
						console.log('getCompassVisionValue text area  = ' + counterValue);
						callback(counterValue);
						}
				} else {
					console.log('getCompassProLifeResult text area  = 0');
					callback();
				}
			}, onError);
		});
	}

function addInprojectMyselfCardRoutesKey(key,value,callback) {
	console.log('addInprojectMyselfCardRoutesKey entering with key = ' + key + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_CardRoutes_key + ' (' + field_projectMyself_CardRoutes_key + ',' + field_projectMyself_CardRoutes_value + ') VALUES ("' + key + '","'+ value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getInprojectMyselfCardRoutesKey(key,callback) {
	console.log('getInprojectMyselfCardRoutesKey  entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_projectMyself_CardRoutes_key + ' WHERE ' + field_projectMyself_CardRoutes_key + ' = ?', [ key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_projectMyself_CardRoutes_value];
					console.log('getInprojectMyselfCardRoutesKey returned  ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getInprojectMyselfCardRoutesKey value = 0');
				callback();
			}
		}, onError);
	});
}



