
/* JavaScript content from js/webSQL/projectMyself/firstStep_webSQL.js in folder common */
var table_projectMyself_firstStep_action = "T_PROJECTMYSELF_FIRSTSTEP_ACTION";
var table_projectMyself_firstStep_key = "T_PROJECTMYSELF_FIRSTSTEP_KEY";
var table_projectMyself_firstStepAction_key = "T_PROJECTMYSELF_FIRSTSTEPACTION_KEY";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_firstStep_action + '(' + field_key + ' TEXT NOT NULL , ' + field_position + ' TEXT NOT NULL ,' + field_value + ' TEXT NOT NULL , PRIMARY KEY ('+field_key+','+field_position+') ); ');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_firstStep_action);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_firstStep_key + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_firstStep_key);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_projectMyself_firstStepAction_key + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_projectMyself_firstStepAction_key);

function projectMyself_firstStep_setAction(key, position,value, callback) {

var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_firstStep_action + ' (' + field_key + ',' + field_position + ',' + field_value + ') VALUES ("' + key + '","' + position + '","' + value + '")';
console.log('projectMyself_firstStep_setKey query = ' + query);

livebook_bdd.transaction(function(tx) {
	tx.executeSql(query, [], function() {
		if (callback && callback != '') {
			callback();
		}
	}, onError);
});
}

function projectMyself_firstStep_getAction(key,callbackIfTrue,callbackIfFalse) {

livebook_bdd.readTransaction(function(tx) {
tx.executeSql('SELECT * FROM ' + table_projectMyself_firstStep_action + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
	var valueReturn = new Array();
	if (data.rows && data.rows.length != 0) {
		for (var i = 0; i < data.rows.length; i++) {
			var record = data.rows.item(i);
			var value = new Array();
			value.push(record[field_position]);
			value.push(record[field_value]);
			valueReturn.push(value);
		}
		callbackIfTrue(valueReturn);
	} else {

		if (callbackIfFalse && callbackIfFalse != '') {
			callbackIfFalse();
		}
	}
}, onError);
});
}

function projectMyself_firstStep_setKey(key,value, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_firstStep_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('projectMyself_firstStep_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function projectMyself_firstStep_getKey(key,callbackIfTrue,callbackIfFalse) {

	console.log('projectMyself_firstStep_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_projectMyself_firstStep_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}


function projectMyself_firstStepAction_setDate (id,date,callback) {
	console.log('projectMyself_firstStepAction_setDate entering');
	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_firstStepAction_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + id + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function projectMyself_firstStepAction_getDate(key,callbackIfSet,callbackIfNotSet) {
	console.log('projectMyself_firstStepAction_getDate '+key+' entering');
	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_projectMyself_firstStepAction_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_value]));
					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {
				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function projectMyself_firstStepAction_setKey(key,value, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_projectMyself_firstStepAction_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('projectMyself_firstStepAction_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function projectMyself_firstStepAction_deleteKey(key,callback) {

	console.log('projectMyself_firstStepAction_deleteKey entering ');
	var query = 'DELETE FROM ' + table_projectMyself_firstStepAction_key + ' WHERE ' + field_key + ' = ' + '"'+key+'"';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function projectMyself_firstStepAction_getKey(key,callbackIfTrue,callbackIfFalse) {

	console.log('projectMyself_firstStep_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_projectMyself_firstStepAction_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

//function leadership_fiveLeaders_deleteKey(key,callback) {
//
//	console.log('leadership_fiveLeaders_deleteKey entering with current leader = ' + key);
//	var query = 'DELETE FROM ' + table_leadership_fiveLeaders_key + ' WHERE ' + field_key + ' = ' + '"'+key+'"';
//	console.log(query);
//
//	livebook_bdd.transaction(function(tx) {
//		tx.executeSql(query, [], function(tx, data) {
//			if (callback && callback != '') {
//				callback();
//			}
//		}, onError);
//	});
//}
//function leadership_fiveLeaders_deleteKey_position(key,position,callback) {
//
//	console.log('leadership_fiveLeaders_deleteKey_position entering with current leader = ' + key);
//	var query = 'DELETE FROM ' + table_leadership_fiveLeaders_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND ( '+ field_leader + ' = ' + '"'+position+'" );';
//	console.log(query);
//
//	livebook_bdd.transaction(function(tx) {
//		tx.executeSql(query, [], function(tx, data) {
//			if (callback && callback != '') {
//				callback();
//			}
//		}, onError);
//	});
//}
//
//function leadership_fiveLeaders_getKeyInformation(key,leader,callbackIfTrue,callbackIfFalse) {
//
//	console.log('leadership_fiveLeaders_deleteKey entering with current leader = ' + key);
//	var query = 'SELECT * FROM ' + table_leadership_fiveLeaders_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND ( '+ field_leader + ' = ' + '"'+leader+'" );';
//	console.log(query);
//
//	livebook_bdd.transaction(function(tx) {
//		tx.executeSql(query, [], function(tx, data) {
//			if (data.rows && data.rows.length != 0) {
//				for (var i = 0; i < data.rows.length; i++) {
//					var record = data.rows.item(i);
//					value = record[field_value];
//					callbackIfTrue(value);
//				}
//				
//			} else {
//				if (callbackIfFalse && callbackIfFalse != '') {
//					callbackIfFalse();
//				}
//			}
//		}, onError);
//	});
//}
//
