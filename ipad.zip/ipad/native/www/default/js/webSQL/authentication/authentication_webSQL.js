
/* JavaScript content from js/webSQL/authentication/authentication_webSQL.js in folder common */

var table_authentification = "T_AUTHENTIFICATION";
var table_authentification_login = "T_AUTHENTIFICATION_LOGIN";
var table_coach_userInformation ="T_COACH_USERINFORMATION";
var table_coach_userActif ="T_COACH_USERACTIF";

var field__connection_key = "id_connection";
var field_connection_value ="value_connection";
var field_chatCoach_User ="user_chatCoach";
var field__loginUser_Coach ="loginUser_Coach";
var field__nameUser_Coach ="nameUser_Coach";
var field__firstNameUser_Coach ="firstNameUser_Coach";
var field__actifUser_Coach ="actifUser_Coach";
var field__coach_userInformation_id ="coach_userInformation_id";
var field__coach_user_key = "coach_user_key";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_authentification + '(' + field__connection_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_connection_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_authentification);
	
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_authentification_login + '(' + field__connection_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_connection_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_authentification_login);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_coach_userInformation + '('+ field__coach_userInformation_id + ' TEXT NOT NULL PRIMARY KEY , ' + field__loginUser_Coach + ' TEXT NOT NULL  , '+ field__nameUser_Coach +' TEXT NOT NULL, '+ field__firstNameUser_Coach +' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_coach_userInformation);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_coach_userActif + '('+ field__coach_user_key + ' TEXT NOT NULL PRIMARY KEY ,'+ field__actifUser_Coach +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_coach_userActif);

function setGetConnection(value, callback) {
	
	console.log('connectFirstTime');
	var query = 'INSERT OR REPLACE INTO ' + table_authentification + ' (' + field__connection_key + ',' + field_connection_value + ') VALUES ("'+field__connection_key+'","' + value + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function setUserName(value, callback) {
	
	console.log('setUserName');
	var query = 'INSERT OR REPLACE INTO ' + table_authentification_login + ' (' + field__connection_key + ',' + field_connection_value + ') VALUES ("'+field__connection_key+'","' + value + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getConnectionValue(callback) {
	console.log('getConnectionValue  entering ');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_authentification + ' WHERE ' + field__connection_key + ' = ?', [ field__connection_key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_connection_value];
					console.log('getConnectionValue =  ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getConnectionValue = no');
				callback("no");
			}
		}, onError);
	});
}

function getUserNameValue(callback) {
	console.log('getUserNameValue  entering ');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_authentification_login + ' WHERE ' + field__connection_key + ' = ?', [ field__connection_key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_connection_value];
					console.log('getConnectionValue =  ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getConnectionValue = no');
				callback("no");
			}
		}, onError);
	});
}

function setIdTeam(value, callback) {
	
	console.log('setIdTeam');
	var query = 'INSERT OR REPLACE INTO ' + table_authentification_login + ' (' + field__connection_key + ',' + field_connection_value + ') VALUES ("idTeam","' + value + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}


function getUserIdTeamValue(callback) {
	console.log('getUserIdTeamValue  entering ');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_authentification_login + ' WHERE ' + field__connection_key + ' = ?', [ "idTeam" ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_connection_value];
					console.log('getConnectionValue =  ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getConnectionValue = no');
				callback("no");
			}
		}, onError);
	});
}


// sauvegarde d'information sur les diffrents user qui ont le meme coach pour le chat coach
function setChatCoachUser(id,value,value1,value2, callback) {
	
	console.log('setChatCoachUser');
	var query = 'INSERT OR REPLACE INTO ' + table_coach_userInformation + ' (' + field__coach_userInformation_id + ',' + field__loginUser_Coach + ',' + field__nameUser_Coach + ',' + field__firstNameUser_Coach + ') VALUES ("' + id + '","'+value+'","'+value1+'","' + value2 + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

//recuperation d'information sur les diffrents user qui ont le meme coach pour le chat coach
function getChatCoachUser(key,callback) {
	console.log('getChatCoachUser  entering ');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_coach_userInformation + ' WHERE ' + field__coach_userInformation_id + ' = ?', [ key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				
				for (var i = 0; i < data.rows.length; i++) {
					var arrayResult = new Array();
					var record = data.rows.item(i);
					var counterValue = record[field__loginUser_Coach];
					arrayResult.push(counterValue);
					counterValue = record[field__nameUser_Coach];
					arrayResult.push(counterValue);
					counterValue = record[field__firstNameUser_Coach];
					arrayResult.push(counterValue);
					callback(arrayResult);
					}
			} else {
				console.log('getConnectionValue = no');
				callback("no");
			}
		}, onError);
	});
}

// sauvegarde du numero du user qui est selectionné pour entrer dans le chat avec le coach
function setChatCoachUserActif(key,value, callback) {
	
	console.log('setChatCoachUser');
	var query = 'INSERT OR REPLACE INTO ' + table_coach_userActif + ' (' + field__coach_user_key + ',' + field__actifUser_Coach + ') VALUES ("' + key + '","'+value+'")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

//reperation du numero du user qui est selectionné pour entrer dans le chat avec le coach
function getChatCoachUserActif(key ,callback) {
	console.log('getChatCoachUserActif  entering ');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_coach_userActif + ' WHERE ' + field__coach_user_key + ' = ?', [ key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field__actifUser_Coach];
					console.log('getConnectionValue =  ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getChatCoachUserActif = no');
				callback("no");
			}
		}, onError);
	});
}

