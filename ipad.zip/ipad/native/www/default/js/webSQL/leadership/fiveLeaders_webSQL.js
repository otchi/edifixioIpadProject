
/* JavaScript content from js/webSQL/leadership/fiveLeaders_webSQL.js in folder common */
var table_leadership_fiveLeaders_key = "T_LEADERSHIP_FIVELEADERS_KEY";
var table_leadership_fiveLeaders_state_leader = "T_LEADERSHIP_FIVELEADERS_STATE_LEADER";

var field_leader = 'positionLeader';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_leadership_fiveLeaders_key + '(' + field_key + ' TEXT NOT NULL , ' + field_leader + ' TEXT NOT NULL ,' + field_value + ' TEXT NOT NULL , PRIMARY KEY ('+field_key+','+field_leader+') ); ');
clearTableQueries.push('DELETE FROM ' + table_leadership_fiveLeaders_key);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_leadership_fiveLeaders_state_leader + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY ,' + field_value + ' TEXT NOT NULL  )');
clearTableQueries.push('DELETE FROM ' + table_leadership_fiveLeaders_state_leader);


function leadership_fiveLeaders_setState_leader(key,value, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_leadership_fiveLeaders_state_leader + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('leadership_fiveLeaders_setState_leader query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
	}

function leadership_fiveLeaders_getState_leader(callbackIfTrue,callbackIfFalse) {

	console.log('leadership_fiveLeaders_getState_leader entering');
	var query = 'SELECT * FROM ' + table_leadership_fiveLeaders_state_leader;
	console.log(query);
	var values = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = new Array();
					value.push(record[field_key]);
					value.push(record[field_value]);
					values.push(value);
				}
				callbackIfTrue(values);
			}else{
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}



///// fonctions leader key

function leadership_fiveLeaders_setKey(key, position,value, callback) {

var query = 'INSERT OR REPLACE INTO ' + table_leadership_fiveLeaders_key + ' (' + field_key + ',' + field_leader + ',' + field_value + ') VALUES ("' + key + '","' + position + '","' + value + '")';
console.log('leadership_fiveLeaders_setKey query = ' + query);

livebook_bdd.transaction(function(tx) {
	tx.executeSql(query, [], function() {
		if (callback && callback != '') {
			callback();
		}
	}, onError);
});
}

function leadership_fiveLeaders_getKey(key,callbackIfTrue,callbackIfFalse) {

livebook_bdd.readTransaction(function(tx) {
tx.executeSql('SELECT * FROM ' + table_leadership_fiveLeaders_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
	var valueReturn = new Array();
	if (data.rows && data.rows.length != 0) {
		for (var i = 0; i < data.rows.length; i++) {
			var record = data.rows.item(i);
			var value = new Array();
			value.push(record[field_leader]);
			value.push(record[field_value]);
			valueReturn.push(value);
		}
		callbackIfTrue(valueReturn);
	} else {

		if (callbackIfFalse && callbackIfFalse != '') {
			callbackIfFalse();
		}
	}
}, onError);
});
}

function leadership_fiveLeaders_deleteKey(key,callback) {

	console.log('leadership_fiveLeaders_deleteKey entering with current leader = ' + key);
	var query = 'DELETE FROM ' + table_leadership_fiveLeaders_key + ' WHERE ' + field_key + ' = ' + '"'+key+'"';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function leadership_fiveLeaders_deleteKey_position(key,position,callback) {

	console.log('leadership_fiveLeaders_deleteKey_position entering with current leader = ' + key);
	var query = 'DELETE FROM ' + table_leadership_fiveLeaders_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND ( '+ field_leader + ' = ' + '"'+position+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function leadership_fiveLeaders_getKeyInformation(key,leader,callbackIfTrue,callbackIfFalse) {

	console.log('leadership_fiveLeaders_deleteKey entering with current leader = ' + key);
	var query = 'SELECT * FROM ' + table_leadership_fiveLeaders_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND ( '+ field_leader + ' = ' + '"'+leader+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function leadership_fiveLeaders_getListeValueKey(key,callbackIfTrue,callbackIfFalse) {

	console.log('leadership_fiveLeaders_deleteKey entering with current leader = ' + key);
	var query = 'SELECT * FROM ' + table_leadership_fiveLeaders_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				var listeValue = new Array();
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					listeValue.push(record[field_leader]);
				}
				callbackIfTrue(listeValue);
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}