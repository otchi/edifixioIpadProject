
/* JavaScript content from js/webSQL/leadership/development_webSQL.js in folder common */
var table_leadership_development_key = "T_LEADERSHIP_DEVELOPMENT_KEY";


createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_leadership_development_key + '(' + field_key + ' TEXT NOT NULL , ' + field_position + ' TEXT NOT NULL ,' + field_value + ' TEXT NOT NULL , PRIMARY KEY ('+field_key+','+field_position+') ); ');
clearTableQueries.push('DELETE FROM ' + table_leadership_development_key);


// fonction pour la partie developpement leadership
function leadership_development_deleteKey(key,position,callback) {

	console.log('leadership_fiveLeaders_deleteKey_position entering with current leader = ' + key);
	var query = 'DELETE FROM ' + table_leadership_development_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND ( '+ field_position + ' = ' + '"'+position+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function leadership_development_setKey(key, position,value, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_leadership_development_key + ' (' + field_key + ',' + field_position + ',' + field_value + ') VALUES ("' + key + '","' + position + '","' + value + '")';
	console.log('leadership_development_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function leadership_development_getKey(key,callbackIfTrue,callbackIfFalse) {

	livebook_bdd.readTransaction(function(tx) {
	tx.executeSql('SELECT * FROM ' + table_leadership_development_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
		var valueReturn = new Array();
		if (data.rows && data.rows.length != 0) {
			for (var i = 0; i < data.rows.length; i++) {
				var record = data.rows.item(i);
				var liste = new Array();
				liste.push(record[field_position]);
				liste.push(record[field_value]);
				valueReturn.push(liste);
			}
			callbackIfTrue(valueReturn);
		} else {

			if (callbackIfFalse && callbackIfFalse != '') {
				callbackIfFalse();
			}
		}
	}, onError);
	});
}