
/* JavaScript content from js/webSQL/leadership/questions_webSQL.js in folder common */
var table_leadership_questions_key = "T_LEADERSHIP_QUESTIONS_KEY";


createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_leadership_questions_key + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY ,' + field_value + ' TEXT NOT NULL  ); ');
clearTableQueries.push('DELETE FROM ' + table_leadership_questions_key);


function leadership_questions_setKey(key,value, callback) {

var query = 'INSERT OR REPLACE INTO ' + table_leadership_questions_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
console.log('leadership_questions_setKey query = ' + query);

livebook_bdd.transaction(function(tx) {
	tx.executeSql(query, [], function() {
		if (callback && callback != '') {
			callback();
		}
	}, onError);
});
}

function leadership_questions_getKey(key,callbackIfTrue,callbackIfFalse) {

livebook_bdd.readTransaction(function(tx) {
tx.executeSql('SELECT * FROM ' + table_leadership_questions_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
	
	if (data.rows && data.rows.length != 0) {
		for (var i = 0; i < data.rows.length; i++) {
			var record = data.rows.item(i);
			var valueReturn;
			valueReturn= record[field_value] ;
		}
		callbackIfTrue(valueReturn);
	} else {

		if (callbackIfFalse && callbackIfFalse != '') {
			callbackIfFalse();
		}
	}
}, onError);
});
}


function leadership_questions_deleteKey(key,callback) {

	console.log('leadership_questions_deleteKey entering ');
	var query = 'DELETE FROM ' + table_leadership_questions_key + ' WHERE ' + field_key + ' = ' + '"'+key+'"';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}



