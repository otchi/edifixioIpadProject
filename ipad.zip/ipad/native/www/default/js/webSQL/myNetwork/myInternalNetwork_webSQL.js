
/* JavaScript content from js/webSQL/myNetwork/myInternalNetwork_webSQL.js in folder common */
var table_myNetwork_myInternalNetwork_knowledge = "T_MYNETWORK_MYINTERNALNETWORK_KEY";
var table_myNetwork_myInternalNetwork_key = "T_MYNETWORK_MYINTERNALNETWORK_KNOWLEDGE";
var table_myNetwork_key = "T_MYNETWORK_KEY";

var field_number = "number";
var field_knowledge = "knowledge";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_myNetwork_myInternalNetwork_knowledge + '(' + field_key + ' TEXT NOT NULL , ' + field_position + ' TEXT NOT NULL ,' + field_number + ' TEXT NOT NULL,' + field_value + ' TEXT NOT NULL ,' + field_knowledge + ' TEXT NOT NULL , PRIMARY KEY ('+field_key+','+field_position+','+field_number+') ); ');
clearTableQueries.push('DELETE FROM ' + table_myNetwork_myInternalNetwork_knowledge);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_myNetwork_myInternalNetwork_key + '(' + field_key + ' TEXT NOT NULL , ' + field_position + ' TEXT NOT NULL ,' + field_number + ' TEXT NOT NULL, PRIMARY KEY ('+field_key+','+field_position+') ); ');
clearTableQueries.push('DELETE FROM ' + table_myNetwork_myInternalNetwork_key);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_myNetwork_key + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL ); ');
clearTableQueries.push('DELETE FROM ' + table_myNetwork_key);


function myNetwork_setKey(key,value,callback){
	
	var query = 'INSERT OR REPLACE INTO ' + table_myNetwork_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('myNetwork_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function myNetwork_getKey(key,callbackIfTrue,callbackIfFalse) {
	
	console.log('myNetwork_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_myNetwork_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function myNetwork_myInternalNetwork_setKey(key,position,number,callback){
	
	var query = 'INSERT OR REPLACE INTO ' + table_myNetwork_myInternalNetwork_key + ' (' + field_key + ',' + field_position + ',' + field_number + ') VALUES ("' + key + '","' + position + '","' + number + '")';
	console.log('myNetwork_myInternalNetwork_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function myNetwork_myInternalNetwork_getKey(key,position,callbackIfTrue,callbackIfFalse) {
	
		console.log('myNetwork_myInternalNetwork_getKey entering with current key = ' + key);
		var query = 'SELECT * FROM ' + table_myNetwork_myInternalNetwork_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" ) AND (' + field_position + ' = ' + '"'+position+'" );';
		console.log(query);
	
		livebook_bdd.transaction(function(tx) {
			tx.executeSql(query, [], function(tx, data) {
				if (data.rows && data.rows.length != 0) {
					for (var i = 0; i < data.rows.length; i++) {
						var record = data.rows.item(i);
						var value = record[field_number];
						console.log("hhhhhhhhh = "+value);
						callbackIfTrue(value);
					}
					
				} else {
					if (callbackIfFalse && callbackIfFalse != '') {
						callbackIfFalse();
					}
				}
			}, onError);
		});
	}


function myNetwork_myInternalNetwork_getAllResponse(key,callbackIfTrue,callbackIfFalse) {

	console.log('myNetwork_myInternalNetwork_getAllResponse entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_myNetwork_myInternalNetwork_knowledge + ';';
	console.log(query);
	
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				var listeResponse = new Array();
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = new Array();
					value.push( record[field_position]);
					value.push( record[field_number]);
					value.push( record[field_value]);
					value.push( record[field_knowledge]);
					listeResponse.push(value);
				}
				callbackIfTrue(listeResponse);
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function myNetwork_myInternalNetwork_setKnowledge(key, position,number,value,knowledge, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_myNetwork_myInternalNetwork_knowledge + ' (' + field_key + ',' + field_position + ',' + field_number + ',' + field_value + ',' + field_knowledge + ') VALUES ("' + key + '","' + position + '","' + number + '","' + value + '","' + knowledge + '")';
	console.log('myNetwork_myInternalNetwork_setKnowledge query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
