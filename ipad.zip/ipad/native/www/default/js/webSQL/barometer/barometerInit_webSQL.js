
/* JavaScript content from js/webSQL/barometer/barometerInit_webSQL.js in folder common */
var table_barometer_init = "T_BAROMETER_INIT";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_barometer_init + ' (' + field_criteriaNumber + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' INTEGER)');
clearTableQueries.push('DELETE FROM ' + table_barometer_init);

function addBarometerInitValue(criteriaNumber, criteriaValue, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_barometer_init + ' (' + field_criteriaNumber + ',' + field_value + ') VALUES (' + criteriaNumber + ',' + criteriaValue + ')';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getBarometerInitValues(callback) {
	console.log('getBarometerInitValues entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_barometer_init, [], function(tx, data) {
			var criterias = new Array();

			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var criteriaNumber = record[field_criteriaNumber];
					var criteriaValue = record[field_value];
					criterias.push(new criteria(criteriaNumber, criteriaValue, null));
				}
			}

			if (callback && callback != '') {
				callback(criterias);
			}

		}, onError);
	});
}