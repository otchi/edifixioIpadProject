
/* JavaScript content from js/webSQL/barometer/barometer_webSQL.js in folder common */
var table_barometer = "T_BAROMETER";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_barometer + ' (' + field_criteriaNumber + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' INTEGER, ' + field_date + ' INTEGER)');
clearTableQueries.push('DELETE FROM ' + table_barometer);

function addBarometerValue(criteriaNumber, criteriaValue, callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_barometer + ' (' + field_criteriaNumber + "," + field_value + "," + field_date + ') VALUES (' + criteriaNumber + ',' + criteriaValue + ',' + dateToUTC(new Date()) + ')';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getBarometerValues(callback) {
	console.log('getBarometerValues entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_barometer, [], function(tx, data) {
			var criterias = new Array();

			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var criteriaNumber = record[field_criteriaNumber];
					var criteriaValue = record[field_value];
					var updateDate = new Date(record[field_date]);
					criterias.push(new criteria(criteriaNumber, criteriaValue, updateDate));
				}
			}

			if (callback && callback != '') {
				callback(criterias);
			}

		}, onError);
	});
}
