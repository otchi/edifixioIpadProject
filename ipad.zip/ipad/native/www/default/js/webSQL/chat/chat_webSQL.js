
/* JavaScript content from js/webSQL/chat/chat_webSQL.js in folder common */
var table_chat_team_information = "T_CHAT_TEAM_INFORMATION";
var table_chat_coach_information = "T_CHAT_COACH_INFORMATION";

var field_chat_userName = "chatUserName";
var field_chat_idTeam ="chatIdTeam";
var field_chat_idCoach = 'chatIdCoach';
var field_chat_lastMessageTeam = 'lastMessageTeam';
var field_chat_lastMessageCoach = 'lastMessageCoach';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_chat_team_information + '(' + field_chat_userName + ' TEXT NOT NULL PRIMARY KEY, ' + field_chat_idTeam + ' TEXT,' + field_chat_lastMessageTeam + ' TEXT  ) ');
clearTableQueries.push('DELETE FROM ' + table_chat_team_information);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_chat_coach_information + '(' + field_chat_userName + ' TEXT NOT NULL PRIMARY KEY, ' + field_chat_idTeam + ' TEXT,' + field_chat_idCoach + ' TEXT ,' + field_chat_lastMessageCoach + ' TEXT ) ');
clearTableQueries.push('DELETE FROM ' + table_chat_coach_information);

function addInformationsTeam(userName,idTeam,lastMessageTeam, callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_chat_team_information + ' (' + field_chat_userName + ',' + field_chat_idTeam + ',' + field_chat_lastMessageTeam + ') VALUES ("' + userName + '","' + idTeam + '","' + lastMessageTeam + '")';
	console.log(query);
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}


function getInformationsTeam(callback) {
	console.log('getInformationsTeam entering');
	var query = 'SELECT * FROM ' + table_chat_team_information;
	console.log(query);
	var values = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				var record = data.rows.item(0);
				values.push(record[field_chat_idTeam]);
				values.push(record[field_chat_lastMessageTeam]);
			}

			if (callback && callback != '') {
				callback(values);
			}
		}, onError);
	});
}

