
/* JavaScript content from js/webSQL/talents/otherRecognize_webSQL.js in folder common */
var table_talents_other_recognize = "T_TALENTS_OTHER_RECOGNIZE";
var table_talents_other_recognize_images = "T_TALENTS_OTHER_RECOGNIZE_IMAGES";
var table_talents_other_recognize_results = "T_TALENTS_OTHER_RECOGNIZE_RESULTS";

var key_talents_other_recognize_validation = 'otherRecognizeTalentsValidated';

createTableQueries
		.push('CREATE TABLE IF NOT EXISTS ' + table_talents_other_recognize + ' (' + field_bloc_number + ' INTEGER NOT NULL, ' + field_position + ' INTEGER NOT NULL, ' + field_talentId + ' INTEGER NOT NULL, CONSTRAINT PK_TAL PRIMARY KEY (' + field_bloc_number + ',' + field_position + '))');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_other_recognize_images + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_other_recognize_results + '(' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY)');

clearTableQueries.push('DELETE FROM ' + table_talents_other_recognize);
clearTableQueries.push('DELETE FROM ' + table_talents_other_recognize_images);
clearTableQueries.push('DELETE FROM ' + table_talents_other_recognize_results);

function addTalentOtherRecognize(blocPosition, talentPosition, talentId, callback) {
	console.log('addTalentOtherRecognize entering with blocPosition = ' + blocPosition + ', talentPosition = ' + talentPosition + ', talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_other_recognize + ' (' + field_bloc_number + ',' + field_position + ',' + field_talentId + ') VALUES (' + blocPosition + ',' + talentPosition + ',' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getTalentsOtherRecognizeCount(callback) {
	var query = 'SELECT COUNT(*) AS number FROM ' + table_talents_other_recognize;
	console.log(query);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			var number = data.rows.item(0)['number'];

			if (callback && callback != '') {
				callback(number);
			}
		}, onError);
	});
}

function getTalentsOtherRecognize(blocNumber, callback) {
	var query = 'SELECT * FROM ' + table_talents_other_recognize + ' WHERE ' + field_bloc_number + ' = "' + blocNumber + '"';
	console.log(query);
	var talentMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					var position = record[field_position];
					talentMap[position] = talentId;
				}
			}

			if (callback && callback != '') {
				callback(talentMap);
			}
		}, onError);
	});
}

function getAllTalentsOtherRecognize(callback) {
	var query = 'SELECT * FROM ' + table_talents_other_recognize;
	console.log(query);
	var talentMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var blocNumber = record[field_bloc_number];
					var talentId = record[field_talentId];
					var position = record[field_position];
					var talentMaps2 = talentMap[blocNumber];

					if (talentMaps2 == null) {
						talentMaps2 = new Array();
						talentMap[blocNumber] = talentMaps2;
					}

					talentMaps2[position] = talentId;
				}
			}

			if (callback && callback != '') {
				callback(talentMap);
			}
		}, onError);
	});
}

function addTalentOtherRecognizeImage(imageId, value, callback) {
	console.log('addTalentOtherRecognizeImage entering with imageId = ' + imageId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_other_recognize_images + ' (' + field_id + ',' + field_value + ') VALUES (' + imageId + ',"' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentOtherRecognizeImages(callback) {
	console.log('getAllTalentOtherRecognizeImages entering');
	var query = 'SELECT * FROM ' + table_talents_other_recognize_images;
	console.log(query);
	var imagesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var imageId = record[field_id];
					var value = record[field_value];
					imagesMap[imageId] = value;
				}
			}

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}

function valideTalentsOtherRecognize(callback) {
	console.log("valideTalentsOtherRecognize entering");

	var query = 'INSERT OR REPLACE INTO ' + table_user_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_other_recognize_validation + '", "true")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function isTalentsOtherRecognizeValidated(callbackIfTrue, callbackIfFalse) {
	console.log('isTalentsOtherRecognizeValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_user_data + ' WHERE ' + field_key + ' = ?', [ key_talents_other_recognize_validation ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log('answers are validated');

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {
				console.log('answers aren\'t validated');

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function addTalentOtherRecognizeResult(talentId, callback) {
	console.log('addTalentOtherRecognizeResult entering with talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_other_recognize_results + ' (' + field_talentId + ') VALUES (' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeTalentOtherRecognizeResult(talentId, callback) {
	console.log('removeTalentOtherRecognizeResult entering with talentId = ' + talentId);
	var query = 'DELETE FROM ' + table_talents_other_recognize_results + ' WHERE ' + field_talentId + ' = ' + talentId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentOtherRecognizeResults(callback) {
	console.log('getAllTalentOtherRecognizeResults entering');
	var query = 'SELECT * FROM ' + table_talents_other_recognize_results;
	console.log(query);
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds);
			}
		}, onError);
	});
}