
/* JavaScript content from js/webSQL/talents/iPlay_webSQL.js in folder common */
var table_talents_i_play = "T_TALENTS_I_PLAY";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_i_play + ' (' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
clearTableQueries.push('DELETE FROM ' + table_talents_i_play);

function getAllTalentIPlay(callback) {
	console.log('getAllTalentIPlay entering');
	var query = 'SELECT * FROM ' + table_talents_i_play;
	console.log(query);

	var images = new Array();
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					var imageValue = record[field_value];
					images.push(imageValue);
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds, images);
			}
		}, onError);
	});
}

function addTalentImageIPlay(talentId, imageValue, callback) {
	console.log('addTalentImageIPlay entering with talentId = ' + talentId + ' and image value = ' + imageValue);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_play + ' (' + field_talentId + ',' + field_value + ') VALUES (' + talentId + ',\'' + imageValue + '\')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}