
/* JavaScript content from js/webSQL/talents/manifeste_webSQL.js in folder common */
var table_talents_manifeste = "T_TALENTS_MANIFESTE";
var table_talents_manifeste_results = "T_TALENTS_MANIFESTE_RESULTS";

var key_talents_manifeste_child = 'child';
var key_talents_manifeste_partner = 'partner';
var key_talents_manifeste_college = 'college';
var key_talents_manifeste_friend = 'friend';
var key_talents_manifeste_parent = 'parent';
var key_talents_manifeste_validation = 'manifesteTalentsValidated';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_manifeste + ' (' + field_talent_type + ' TEXT NOT NULL, ' + field_position + ' INTEGER NOT NULL, ' + field_talentId + ' INTEGER NOT NULL, CONSTRAINT PK_TAL PRIMARY KEY (' + field_talent_type + ',' + field_position + '))');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_manifeste_results + '(' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY)');

clearTableQueries.push('DELETE FROM ' + table_talents_manifeste);
clearTableQueries.push('DELETE FROM ' + table_talents_manifeste_results);

function addTalentManifeste(talentType, position, talentId, callback) {
	console.log('addTalentManifeste entering with talentType = ' + talentType + ', position = ' + position + ', talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_manifeste + ' (' + field_talent_type + ',' + field_position + ',' + field_talentId + ') VALUES ("' + talentType + '",' + position + ',' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getTalentsManifeste(talentType, callback) {
	var query = 'SELECT * FROM ' + table_talents_manifeste + ' WHERE ' + field_talent_type + ' = "' + talentType + '"';
	console.log(query);
	var talentMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					var position = record[field_position];
					talentMap[position] = talentId;
				}
			}

			if (callback && callback != '') {
				callback(talentMap);
			}
		}, onError);
	});
}

function getAllTalentsManifeste(callback) {
	var query = 'SELECT * FROM ' + table_talents_manifeste;
	console.log(query);
	var talentMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentType = record[field_talent_type];
					var talentId = record[field_talentId];
					var position = record[field_position];
					var talentMaps2 = talentMap[talentType];

					if (talentMaps2 == null) {
						talentMaps2 = new Array();
						talentMap[talentType] = talentMaps2;
					}

					talentMaps2[position] = talentId;
				}
			}

			if (callback && callback != '') {
				callback(talentMap);
			}
		}, onError);
	});
}

function getTalentsManifesteCount(callback) {
	var query = 'SELECT COUNT(*) AS number FROM ' + table_talents_manifeste;
	console.log(query);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			var number = data.rows.item(0)['number'];

			if (callback && callback != '') {
				callback(number);
			}
		}, onError);
	});
}

function addTalentManifestResult(talentId, callback) {
	console.log('addTalentManifestResult entering with talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_manifeste_results + ' (' + field_talentId + ') VALUES (' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeTalentManifestResult(talentId, callback) {
	console.log('removeTalentManifestResult entering with talentId = ' + talentId);
	var query = 'DELETE FROM ' + table_talents_manifeste_results + ' WHERE ' + field_talentId + ' = ' + talentId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentManifesteResults(callback) {
	console.log('getAllTalentManifesteResults entering');
	var query = 'SELECT * FROM ' + table_talents_manifeste_results;
	console.log(query);
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds);
			}
		}, onError);
	});
}

function valideTalentsManifeste(callback) {
	console.log("valideTalentsManifeste entering");

	var query = 'INSERT OR REPLACE INTO ' + table_user_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_manifeste_validation + '", "true")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function isTalentsManifesteValidated(callbackIfTrue, callbackIfFalse) {
	console.log('isTalentsManifesteValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_user_data + ' WHERE ' + field_key + ' = ?', [ key_talents_manifeste_validation ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log('answers are validated');

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {
				console.log('answers aren\'t validated');

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}