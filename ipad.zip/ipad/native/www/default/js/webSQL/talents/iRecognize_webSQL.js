
/* JavaScript content from js/webSQL/talents/iRecognize_webSQL.js in folder common */
var table_talents_i_recognize = "T_TALENTS_I_RECOGNIZE";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_i_recognize + '(' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY)');
clearTableQueries.push('DELETE FROM ' + table_talents_i_recognize);

function addTalentIRecognize(talentId, callback) {
	console.log('addTalentIRecognize entering with talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_recognize + ' (' + field_talentId + ') VALUES (' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeTalentIRecognize(talentId, callback) {
	console.log('removeTalentIRecognize entering with talentId = ' + talentId);
	var query = 'DELETE FROM ' + table_talents_i_recognize + ' WHERE ' + field_talentId + ' = ' + talentId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentIRecognize(callback) {
	console.log('getAllTalentIRecognize entering');
	var query = 'SELECT * FROM ' + table_talents_i_recognize;
	console.log(query);
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds);
			}
		}, onError);
	});
}