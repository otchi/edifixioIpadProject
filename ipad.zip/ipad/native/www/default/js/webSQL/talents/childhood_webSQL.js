
/* JavaScript content from js/webSQL/talents/childhood_webSQL.js in folder common */
var table_talents_childwood = "T_TALENTS_CHILDHOOD";
var table_talents_childhood_answers = "T_TALENTS_CHILDHOOD_ANSWERS";
var table_talents_childhood_images = "T_TALENTS_CHILDHOOD_IMAGES";

var key_talents_childhood_answers_validation = 'answersValidated';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_childwood + '(' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_childhood_answers + ' (' + field_answerId + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_childhood_images + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');

clearTableQueries.push('DELETE FROM ' + table_talents_childwood);
clearTableQueries.push('DELETE FROM ' + table_talents_childhood_answers);
clearTableQueries.push('DELETE FROM ' + table_talents_childhood_images);

function addTalentChildhood(talentId, callback) {
	console.log('addTalentChildhood entering with talentId = ' + talentId);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_childwood + ' (' + field_talentId + ') VALUES (' + talentId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeTalentChildhood(talentId, callback) {
	console.log('removeTalentChildhood entering with talentId = ' + talentId);
	var query = 'DELETE FROM ' + table_talents_childwood + ' WHERE ' + field_talentId + ' = ' + talentId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentChildhood(callback) {
	console.log('getAllTalentChildhood entering');
	var query = 'SELECT * FROM ' + table_talents_childwood;
	console.log(query);
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds);
			}
		}, onError);
	});
}

function addTalentChildhoodAnswer(answerId, value, callback) {
	console.log('addTalentChildhoodAnswer entering with answerId = ' + answerId + ' and answer = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_childhood_answers + ' (' + field_answerId + ',' + field_value + ') VALUES (' + answerId + ',"' + htmlEncode(value) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentChildhoodAnswers(callback) {
	console.log('getAllTalentChildhoodAnswers entering');
	var query = 'SELECT * FROM ' + table_talents_childhood_answers;
	console.log(query);
	var answersMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var answerId = record[field_answerId];
					var answer = htmlDecode(record[field_value]);
					answersMap[answerId] = answer;
				}
			}

			if (callback && callback != '') {
				callback(answersMap);
			}
		}, onError);
	});
}

function addTalentChildhoodImage(imageId, value, callback) {
	console.log('addTalentChildhoodImage entering with imageId = ' + imageId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_childhood_images + ' (' + field_id + ',' + field_value + ') VALUES (' + imageId + ',"' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentChildhoodImages(callback) {
	console.log('getAllTalentChildhoodImages entering');
	var query = 'SELECT * FROM ' + table_talents_childhood_images;
	console.log(query);
	var imagesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var imageId = record[field_id];
					var value = record[field_value];
					imagesMap[imageId] = value;
				}
			}

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}

function valideTalentsChildhoodAnswer(callback) {
	console.log("valideTalentChildhoodAnswer entering");

	var query = 'INSERT OR REPLACE INTO ' + table_user_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_childhood_answers_validation + '", "true")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function isTalentsChildhoodAnswerValidated(callbackIfTrue, callbackIfFalse) {
	console.log('isTalentsChildhoodAnswerValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_user_data + ' WHERE ' + field_key + ' = ?', [ key_talents_childhood_answers_validation ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log('answers are validated');

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {
				console.log('answers aren\'t validated');

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}