
/* JavaScript content from js/webSQL/talents/iEnhance_webSQL.js in folder common */
var table_talents_i_enhance = "T_TALENTS_I_ENHANCE";
var table_talents_i_enhance_data = "T_TALENTS_I_ENHANCE_DATA";
var table_talents_i_enhance_stage = "T_TALENTS_I_ENHANCE_STAGE";

var key_talents_i_enhance_validation = 'iEnhanceTalentsValidated';
var key_talents_i_enhance_talent_selected = 'iEnhanceTalentSelected';
var key_talents_i_enhance_response = 'iEnhanceTalentResponse';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_i_enhance + ' (' + field_talentId + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' INTEGER NOT NULL)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_i_enhance_data + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_talents_i_enhance_stage + ' (' + field_id + ' INTEGER PRIMARY KEY AUTOINCREMENT,' + field_name + ' TEXT NOT NULL, ' + field_date + ' INTEGER NOT NULL)');

clearTableQueries.push('DELETE FROM ' + table_talents_i_enhance);
clearTableQueries.push('DELETE FROM ' + table_talents_i_enhance_data);
clearTableQueries.push('DELETE FROM ' + table_talents_i_enhance_stage);

function getAllTalentIEnhance(callback) {
	console.log('getAllTalentIEnhance entering');
	var query = 'SELECT * FROM ' + table_talents_i_enhance;
	console.log(query);

	var notes = new Array();
	var talentIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var talentId = record[field_talentId];
					var note = record[field_value];
					notes.push(note);
					talentIds.push(talentId);
				}
			}

			if (callback && callback != '') {
				callback(talentIds, notes);
			}
		}, onError);
	});
}

function addTalentNoteIEnhance(talentId, note, callback) {
	console.log('addTalentNoteIEnhance entering with talentId = ' + talentId + ' and note value = ' + note);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_enhance + ' (' + field_talentId + ',' + field_value + ') VALUES (' + talentId + ',' + note + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function valideTalentsIEnhance(callback) {
	console.log("valideTalentsIEnhance entering");

	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_enhance_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_i_enhance_validation + '", "true")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function isTalentsIEnhanceValidated(callbackIfTrue, callbackIfFalse) {
	console.log('isTalentsOtherRecognizeValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_talents_i_enhance_data + ' WHERE ' + field_key + ' = ?', [ key_talents_i_enhance_validation ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function setSelectedTalentIEnhance(talentId, callback) {
	console.log('setSelectedTalentIEnhance entering');

	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_enhance_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_i_enhance_talent_selected + '", "' + talentId + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getSelectedTalentIEnhance(callbackIfSet, callbackIfNotSet) {
	console.log('getSelectedTalentIEnhance entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_talents_i_enhance_data + ' WHERE ' + field_key + ' = ?', [ key_talents_i_enhance_talent_selected ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var selectedTalentId = parseInt(record[field_value]);

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(selectedTalentId);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function setTalentIEnhanceResponse(response, callback) {
	console.log('setSelectedTalentIEnhance entering');

	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_enhance_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_talents_i_enhance_response + '", "' + htmlEncode(response) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getTalentIEnhanceResponse(callbackIfSet, callbackIfNotSet) {
	console.log('getSelectedTalentIEnhance entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_talents_i_enhance_data + ' WHERE ' + field_key + ' = ?', [ key_talents_i_enhance_response ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var response = htmlDecode(record[field_value]);

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(response);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function addTalentIEnhanceStage(name, date, callback) {
	console.log('addTalentNoteIEnhance entering with name = ' + name + ' and date value = ' + date);
	var query = 'INSERT OR REPLACE INTO ' + table_talents_i_enhance_stage + ' (' + field_name + ',' + field_date + ') VALUES ("' + htmlEncode(name) + '",' + dateToUTC(date) + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeTalentIEnhanceStage(stageId, callback) {
	console.log('removeTalentIEnhanceStage entering with stageId = ' + stageId);
	var query = 'DELETE FROM ' + table_talents_i_enhance_stage + ' WHERE ' + field_id + ' = ' + stageId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTalentIEnhanceStages(callback) {
	console.log('getAllTalentIEnhanceStages entering');
	var query = 'SELECT * FROM ' + table_talents_i_enhance_stage;
	console.log(query);
	var names = new Array();
	var dates = new Array();
	var ids = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var name = htmlDecode(record[field_name]);
					var date = utcToDate(record[field_date]);
					var id = record[field_id];
					names.push(name);
					dates.push(date);
					ids.push(id);
				}
			}

			if (callback && callback != '') {
				callback(ids, names, dates);
			}
		}, onError);
	});
}