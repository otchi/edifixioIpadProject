
/* JavaScript content from js/webSQL/calendar/calendar_webSQL.js in folder common */

var table_calendar = "T_CALENDAR_DATE";

var field__calendar_id ="actifUser_Coach";
var field__calendar_value ="coach_userInformation_id";
var field__calendar_explication = "coach_user_key";


createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_calendar + '('+ field__calendar_id + ' TEXT NOT NULL PRIMARY KEY , ' + field__calendar_value + ' TEXT NOT NULL  , '+ field__calendar_explication +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_calendar);


function setCalendarDate(id,value,explication, callback) {
	
	console.log('setCalendarDate');
	var query = 'INSERT OR REPLACE INTO ' + table_calendar + ' (' + field__calendar_id + ',' + field__calendar_value  + ',' + field__calendar_explication + ') VALUES ("' + id + '","' + value + '","' + explication + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getDateCalendar(callback) {
	console.log('getDateCalendar  entering ');
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_calendar , function(tx, data) {
			var listeCounterValue = new Array();
			if (data.rows && data.rows.length != 0) {
				
				for (var i = 0; i < data.rows.length; i++) {
					
					var record = data.rows.item(i);
					var liste = new Array();
					var counterValue = record[field__calendar_value];
					liste.push(id);
					liste.push(counterValue);
					counterValue = record[field__calendar_explication];
					liste.push(counterValue);
					listeCounterValue.push(liste);
					
					}
				callback(listeCounterValue);
			} else {
				console.log('getDateCalendar = no');
				callback("no");
			}
		}, onError);
	});
}

