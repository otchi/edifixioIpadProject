
/* JavaScript content from js/webSQL/sayI/passion_step4_webSQL.js in folder common */

var table_sayi_passion_stepfour_key = "T_SAYI_PASSION_STEPFOUR_KEY";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_stepfour_key + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_stepfour_key);


function sayI_passion_setPassion_step4_key(key, value, callback) {
	console.log('sayI_passion_setPassion_step2_key entering');
	
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_stepfour_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_passion_getPassion_step4(key,callbackIfTrue, callbackIfFalse) {
	console.log('sayI_passion_getPassion_step4 entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_stepfour_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
			var valueInput;
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					valueInput = record[field_value];
					console.log(valueInput);
				}
					callbackIfTrue(valueInput);
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_passion_getPassion_step4_date(key,callbackIfSet,callbackIfNotSet) {
	console.log('sayI_passion_getPassion_step4_date '+key+' entering');
	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_stepfour_key + ' WHERE ' + field_key + ' = ?', [key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_value]));

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}
function sayI_passion_setPassion_step4_date(key,date,callback) {
	console.log('sayI_passion_setPassion_step4_date entering');
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_stepfour_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}