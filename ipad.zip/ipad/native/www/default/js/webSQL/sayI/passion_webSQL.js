
/* JavaScript content from js/webSQL/sayI/passion_webSQL.js in folder common */
var table_sayi_passion_stepone = "T_SAYI_PASSION_STEPONE";
table_sayi_passion_stepone_key = "T_SAYI_PASSION_STEPONE_KEY";


createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_stepone + ' (' + field_key + ' INT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_stepone);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_stepone_key + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_stepone_key);

function sayI_passion_setPassion_step1_key(key, value, callback) {
	console.log('sayI_passion_setPassion_step1_key entering with value = ' + value);

	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_stepone_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}



function sayI_passion_deletePassion_step1(table,callback) {
	console.log('delete table '+ table);

	var query = 'DELETE FROM ' + table + ';'
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}


function sayI_passion_setPassion_step1(key, value, callback) {
	console.log('sayI_passion_setPassion_step1 entering with value = ' + value);

	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_stepone + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}



function sayI_Passion_IsBlocValidate(key,callbackIfTrue, callbackIfFalse) {
	console.log('sayI_ISayI_isBloc2Validated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_stepone_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_Passions_getPassions(callback) {
	console.log('sayI_Passions_getPassions entering');
	var query ='SELECT * FROM ' + table_sayi_passion_stepone ;
	console.log(query);	
	livebook_bdd.readTransaction(function(tx) {
				tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				var listePassion = new Array();
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var passion = new Array();
					passion.push(record[field_key]);
					console.log('getICounterValue counter value  = ' + record[field_key]);
					passion.push(record[field_value]);
					console.log('getICounterValue counter value  = ' + record[field_value]);
					listePassion.push(passion);
				}
				callback(listePassion);
			} else {
				console.log('sayI_Passions_getPassions counter value  = 0');
				callback(0);
			}
		}, onError);
	});
}

function sayI_Passions_getValue(key,callback) {
	console.log('sayI_Passions_getValue entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_stepone_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				var listePassion = new Array();
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = record[field_value];
					console.log('getICounterValue counter value  = ' + record[field_value]);
					callback(value)
				}
			} else {
				console.log('sayI_Passions_getValue counter value  = 0');
				callback(0);
			}
		}, onError);
	});
}