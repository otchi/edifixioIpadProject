
/* JavaScript content from js/webSQL/sayI/myLittleMe_webSQL.js in folder common */
var table_sayi_myLittleMe_Images = "T_SAYI_MYLITTLEME_IMAGES";
var table_sayi_myLittleMe_Names = "T_SAYI_MYLITTLEME_NAMES";
var table_sayi_myLittleMe_Sentences = "T_SAYI_MYLITTLEME_SENTENCES";
var table_sayi_myLittleMe_Data = "T_SAYI_MYLITTLEME_DATA";

var key_sayi_myLittleMe_profile_Photo = 'sayIMyLittleMeProfilPhoto';
var key_sayi_myLittleMe_Started = 'sayIMyLittleMeStarted';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_myLittleMe_Images + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_myLittleMe_Names + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_myLittleMe_Sentences + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_myLittleMe_Data + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');

clearTableQueries.push('DELETE FROM ' + table_sayi_myLittleMe_Images);
clearTableQueries.push('DELETE FROM ' + table_sayi_myLittleMe_Names);
clearTableQueries.push('DELETE FROM ' + table_sayi_myLittleMe_Sentences);
clearTableQueries.push('DELETE FROM ' + table_sayi_myLittleMe_Data);

function sayI_MyLittleMe_addImage(imageId, value, callback) {
	console.log('sayI_MyLittleMe_addImage entering with imageId = ' + imageId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_myLittleMe_Images + ' (' + field_id + ',' + field_value + ') VALUES (' + imageId + ',"' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_MyLittleMe_addName(nameId, value, callback) {
	console.log('sayI_MyLittleMe_addName entering with nameId = ' + nameId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_myLittleMe_Names + ' (' + field_id + ',' + field_value + ') VALUES (' + nameId + ',"' + htmlEncode(value) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_MyLittleMe_addSentence(sentenceId, value, callback) {
	console.log('sayI_MyLittleMe_addSentence entering with nameId = ' + sentenceId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_myLittleMe_Sentences + ' (' + field_id + ',' + field_value + ') VALUES (' + sentenceId + ',"' + htmlEncode(value) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_MyLittleMe_getAllImages(callback) {
	console.log('sayI_MyLittleMe_getAllImages entering');
	var query = 'SELECT * FROM ' + table_sayi_myLittleMe_Images;
	console.log(query);
	var imagesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var imageId = record[field_id];
					var value = record[field_value];
					imagesMap[imageId] = value;
				}
			}

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}

function sayI_MyLittleMe_getAllNames(callback) {
	console.log('sayI_MyLittleMe_getAllNames entering');
	var query = 'SELECT * FROM ' + table_sayi_myLittleMe_Names;
	console.log(query);
	var namesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var nameId = record[field_id];
					var value = htmlDecode(record[field_value]);
					namesMap[nameId] = value;
				}
			}

			if (callback && callback != '') {
				callback(namesMap);
			}
		}, onError);
	});
}

function sayI_MyLittleMe_getAllSentences(callback) {
	console.log('sayI_MyLittleMe_getAllSentences entering');
	var query = 'SELECT * FROM ' + table_sayi_myLittleMe_Sentences;
	console.log(query);
	var sentencesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var sentenceId = record[field_id];
					var value = htmlDecode(record[field_value]);
					sentencesMap[sentenceId] = value;
				}
			}

			if (callback && callback != '') {
				callback(sentencesMap);
			}
		}, onError);
	});
}

function sayI_MyLittleMe_setProfileImage(value, callback) {
	console.log('sayI_MyLittleMe_setProfileImage entering with value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_myLittleMe_Data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_myLittleMe_profile_Photo + '","' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_MyLittleMe_getProfileImage(callbackIfSet, callbackIfNotSet) {
	console.log('sayI_MyLittleMe_getProfileImage entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_myLittleMe_Data + ' WHERE ' + field_key + ' = ?', [ key_sayi_myLittleMe_profile_Photo ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				var record = data.rows.item(0);
				var image = record[field_value];

				if (callbackIfSet && callbackIfSet != '') {
					callbackIfSet(image);
				}
			} else {
				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}