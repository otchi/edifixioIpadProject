
/* JavaScript content from js/webSQL/sayI/iListenMyLittleMe_webSQL.js in folder common */
