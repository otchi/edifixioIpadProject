
/* JavaScript content from js/webSQL/sayI/iSayI_webSQL.js in folder common */
var table_sayi_isayi_data = "T_SAYI_ISAYI_DATA";

var key_sayi_i_say_i_counter_i = 'sayIIsayICounterI';
var key_sayi_i_say_i_counter_one = 'sayIIsayICounterOne';
var key_sayi_i_say_i_counter_validated = 'sayIIsayICounterValidated';
var key_sayi_i_say_i_bloc2_validated = 'sayIIsayIBloc2Validated';
var key_sayi_i_say_i_comment = 'sayIIsayIComment';
var key_sayi_i_say_i_bloc3_validated = 'sayIIsayIBloc3Validated';
var key_sayi_i_say_i_date = 'sayIIsayIDate';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_isayi_data + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_isayi_data);

function sayI_ISayI_getICounterValue(callback) {
	console.log('getICounterValue entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_counter_i ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = parseInt(record[field_value]);
					console.log('getICounterValue counter value  = ' + counterValue);
					callback(counterValue);
				}
			} else {
				console.log('getICounterValue counter value  = 0');
				callback(0);
			}
		}, onError);
	});
}

function sayI_ISayI_setICounterValue(value, callback) {
	console.log('sayI_ISayI_setICounterValue entering with value = ' + value);

	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_counter_i + '",' + value.toString() + ')';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_getOneCounterValue(callback) {
	console.log('getOneCounterValue entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_counter_one ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = parseInt(record[field_value]);
					console.log('getOneCounterValue counter value  = ' + counterValue);
					callback(counterValue);
				}
			} else {
				console.log('getICounterValue counter value  = 0');
				callback(0);
			}
		}, onError);
	});
}

function sayI_ISayI_setOneCounterValue(value, callback) {
	console.log('sayI_ISayI_setOneCounterValue entering with value = ' + value);

	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_counter_one + '",' + value.toString() + ')';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_validateCounter(callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_counter_validated + '","true")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_isCounterValidated(callbackIfTrue, callbackIfFalse) {
	console.log('isTalentsOtherRecognizeValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_counter_validated ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_ISayI_validateBloc2(callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_bloc2_validated + '","true")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_isBloc2Validated(callbackIfTrue, callbackIfFalse) {
	console.log('sayI_ISayI_isBloc2Validated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_bloc2_validated ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_ISayI_setComment(comment, callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_comment + '","' + htmlEncode(comment) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_getComment(callbackIfSet, callbackIfNotSet) {
	console.log('sayI_ISayI_getComment entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_comment ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var comment = htmlDecode(record[field_value]);

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(comment);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function sayI_ISayI_validateBloc3(callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_bloc3_validated + '","true")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_isBloc3Validated(callbackIfTrue, callbackIfFalse) {
	console.log('sayI_ISayI_isBloc3Validated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_bloc3_validated ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_ISayI_setDate(date, callback) {
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_isayi_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_i_say_i_date + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_ISayI_getDate(callbackIfSet, callbackIfNotSet) {
	console.log('sayI_ISayI_getComment entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_isayi_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_i_say_i_date ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_value]));

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}