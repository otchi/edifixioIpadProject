
/* JavaScript content from js/webSQL/sayI/otherVoices_webSQL.js in folder common */
var table_sayi_otherVoices_Images = "T_SAYI_OTHERVOICES_IMAGES";
var table_sayi_otherVoices_Descriptions = "T_SAYI_OTHERVOICES_DESCRIPTIONS";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_otherVoices_Images + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_otherVoices_Descriptions + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');

clearTableQueries.push('DELETE FROM ' + table_sayi_otherVoices_Images);
clearTableQueries.push('DELETE FROM ' + table_sayi_otherVoices_Descriptions);

function sayI_otherVoices_addImage(imageId, value, callback) {
	console.log('sayI_otherVoices_addImage entering with imageId = ' + imageId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_otherVoices_Images + ' (' + field_id + ',' + field_value + ') VALUES (' + imageId + ',"' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_otherVoices_getAllImages(callback) {
	console.log('sayI_otherVoices_getAllImages entering');
	var query = 'SELECT * FROM ' + table_sayi_otherVoices_Images;
	console.log(query);
	var imagesMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var imageId = record[field_id];
					var value = record[field_value];
					imagesMap[imageId] = value;
				}
			}

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}

function sayI_otherVoices_SetDescription(descriptionId, value, callback) {
	console.log('sayI_otherVoices_SetDescription entering with descriptionId = ' + descriptionId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_otherVoices_Descriptions + ' (' + field_id + ',' + field_value + ') VALUES (' + descriptionId + ',"' + htmlEncode(value) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_otherVoices_getAllDescriptions(callback) {
	console.log('sayI_otherVoices_getAllDescriptions entering');
	var query = 'SELECT * FROM ' + table_sayi_otherVoices_Descriptions;
	console.log(query);
	var descriptionMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var description = htmlDecode(record[field_value]);
					var position = record[field_id];
					console.log('Add to position ' + position + ' description : ' + description);
					descriptionMap[position] = description;
				}
			}

			if (callback && callback != '') {
				callback(descriptionMap);
			}
		}, onError);
	});
}