
/* JavaScript content from js/webSQL/sayI/passion_step2_webSQL.js in folder common */
var table_sayi_passion_steptwo = "T_SAYI_PASSION_STEPTWO";
var table_sayi_passion_steptwo_key = "T_SAYI_PASSION_STEPTWO_KEY";
var table_sayi_passion_steptwo_pictures = "T_SAYI_PASSION_STEPTWO_PICTURES";	

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_steptwo + ' (' + field_key + ' INT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_steptwo);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_steptwo_key + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_steptwo_key);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_passion_steptwo_pictures + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_passion_steptwo_pictures);

function sayI_passion_setPassion_step2_key(key, value, callback) {
		
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_steptwo_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_passion_setPassion_step2_pictures(key, value, callback) {
	
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_passion_steptwo_pictures + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_passion_getInputPassion_step2(key,callbackIfTrue, callbackIfFalse) {
	console.log('sayI_ISayI_isBloc2Validated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_steptwo_key + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
			var valueInput;
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					valueInput = record[field_value];
					console.log(valueInput);
				}
					callbackIfTrue(valueInput);
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_Passions_step2_getPictures(callback) {
	
	console.log('sayI_Passions_step2_getPicture entering');
	var query = 'SELECT * FROM ' + table_sayi_passion_steptwo_pictures ;
	var listePictures = new Array();
	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = record[field_value];
					var key = record[field_key];
					listePictures[key]= value;
				}
				callback(listePictures);
			} else {
				console.log('pictures are no setted ');
				callback(0);
			}
		}, onError);
	});
}

function sayI_passion_getPicture_step3(key,callbackIfTrue, callbackIfFalse) {
	console.log('sayI_ISayI_isBloc2Validated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_passion_steptwo_pictures + ' WHERE ' + field_key + ' = ?', [ key ], function(tx, data) {
			var valueInput;
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					valueInput = record[field_value];
					console.log(valueInput);
					callbackIfTrue(valueInput);
				}
					
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

