
/* JavaScript content from js/webSQL/sayI/myBeliefs_webSQL.js in folder common */
var table_sayi_myBeliefs_Answers = "T_SAYI_MYBELIEFS_ANSWERS";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_myBeliefs_Answers + ' (' + field_position + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');

clearTableQueries.push('DELETE FROM ' + table_sayi_myBeliefs_Answers);

function sayiMyBeliefs_addAnswer(position, answer, callback) {
	console.log('addAnswer entering with position = ' + position + ', answer = ' + answer);
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_myBeliefs_Answers + ' (' + field_position + ',' + field_value + ') VALUES (' + position + ',"' + htmlEncode(answer) + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayiMyBeliefs_getAllAnswers(callback) {
	var query = 'SELECT * FROM ' + table_sayi_myBeliefs_Answers;
	console.log(query);
	var answerMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var answer = htmlDecode(record[field_value]);
					var position = record[field_position];
					answerMap[position] = answer;
				}
			}

			if (callback && callback != '') {
				callback(answerMap);
			}
		}, onError);
	});
}