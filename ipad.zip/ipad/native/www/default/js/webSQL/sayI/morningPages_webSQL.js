
/* JavaScript content from js/webSQL/sayI/morningPages_webSQL.js in folder common */
var table_sayi_morningPages_data = "T_SAYI_MORNINGPAGES_DATA";

var key_sayi_morningpages_date = 'sayIMorningPagesDate';
var key_sayi_morningpages_validated = 'sayIMorningPagesValidated';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_sayi_morningPages_data + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT NOT NULL)');
clearTableQueries.push('DELETE FROM ' + table_sayi_morningPages_data);

function sayI_morningPages_setDate(date, callback) {
	console.log('sayI_morningPages_setDate entering');
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_morningPages_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_morningpages_date + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function sayI_morningPages_getDate(callbackIfSet, callbackIfNotSet) {
	console.log('sayI_monrningPages_getDate entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_morningPages_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_morningpages_date ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_value]));

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function sayI_MorningPages_isValidated(callbackIfTrue, callbackIfFalse) {
	console.log('sayI_MorningPages_isValidated entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_sayi_morningPages_data + ' WHERE ' + field_key + ' = ?', [ key_sayi_morningpages_validated ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				if (callbackIfTrue && callbackIfTrue != '') {
					callbackIfTrue();
				}
			} else {

				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function sayI_MorningPages_validate(callback) {
	console.log('sayI_MorningPages_validate entering');
	var query = 'INSERT OR REPLACE INTO ' + table_sayi_morningPages_data + ' (' + field_key + ',' + field_value + ') VALUES ("' + key_sayi_morningpages_validated + '","true")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}