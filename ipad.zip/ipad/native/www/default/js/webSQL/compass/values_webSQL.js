
/* JavaScript content from js/webSQL/compass/values_webSQL.js in folder common */
var table_compass_values = "T_COMPASS_VALUES";
var table_compass_array_Value = "T_COMPASS_ARRAY_VALUES";
var table_compass_important_Criteria = "T_COMPASS_IMPORTANT_CRITERIA";
var table_compass_mark = "T_COMPASS_MARK";
var table_compass_actions = "T_COMPASS_ACTIONS";
var table_compass_actions_temp = "T_COMPASS_ACTIONS_TEMP";

var field_compass_actions_temp = "compass_actions_temp";
var field_compass_actions_key ="key";
var key_compass_actions_date = 'compassActionsDate';
var key_compass_actions_response = 'compassActionsResponse';
var key_compass_actions_result = 'compassActionsResult';

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_values + '(' + field_valueId + ' INTEGER NOT NULL PRIMARY KEY)');
clearTableQueries.push('DELETE FROM ' + table_compass_values);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_array_Value + '(' + field_line + ' INTEGER NOT NULL , ' + field_column + ' INTEGER NOT NULL ,' + field_valueColumn + ' INTEGER NOT NULL,' + field_valueCriteria + ' TEXT NOT NULL,' + field_valueLabel + ' TEXT NOT NULL , PRIMARY KEY ('+field_line+','+field_column+') ); ');
clearTableQueries.push('DELETE FROM ' + table_compass_array_Value);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_important_Criteria + '(' + field_importantCriteria1 + ' TEXT NOT NULL PRIMARY KEY, ' + field_importantCriteria2 + ' TEXT NOT NULL ,' + field_importantCriteria3 + ' TEXT NOT NULL ) ');
clearTableQueries.push('DELETE FROM ' + table_compass_important_Criteria);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_mark + '(' + field_compass_mark + ' INTEGER NOT NULL PRIMARY KEY )');
clearTableQueries.push('DELETE FROM ' + table_compass_mark);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_actions + '(' + field_compass_actions_id + ' INTEGER NOT NULL PRIMARY KEY ,' + field_compass_actions + ' TEXT   )');
clearTableQueries.push('DELETE FROM ' + table_compass_actions);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_actions_temp + '(' + field_compass_actions_key + ' TEXT NOT NULL PRIMARY KEY ,' + field_compass_actions_temp + ' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_compass_actions_temp);

function addValueIRecognize(valueId, callback) {
	console.log('addValueIRecognize entering with valueId = ' + valueId);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_values + ' (' + field_valueId + ') VALUES (' + valueId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeValueIRecognize(valueId, callback) {
	console.log('removeValueIRecognize entering with valueId = ' + valueId);
	var query = 'DELETE FROM ' + table_compass_values + ' WHERE ' + field_valueId + ' = ' + valueId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllValueIRecognize(callback) {
	console.log('getAllValueIRecognize entering');
	var query = 'SELECT * FROM ' + table_compass_values;
	console.log(query);
	var valueIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var valueId = record[field_valueId];
					valueIds.push(valueId);
				}
			}

			if (callback && callback != '') {
				callback(valueIds);
			}
		}, onError);
	});
}

function addValueRadioArray(lineNumber,columnNumber,valueNumber,valueCriteria,valueLabel, callback) {
	console.log('addValueRadioArray entering with lineNumber = ' + lineNumber +' columnNumber = '+columnNumber+' valueNumber = '+ valueNumber +' valueCriteria = '+ valueCriteria +' valueLabel = '+ valueLabel);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_array_Value + ' (' + field_line + ',' + field_column + ',' + field_valueColumn + ',' + field_valueCriteria +',' + field_valueLabel +') VALUES (' + lineNumber +',' + columnNumber + ',' + valueNumber + ',"' + valueCriteria + '","' + valueLabel + '");';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeValueArray(valueId,callback) {
	console.log('removeValueArray with valueId = ' + valueId);
	var query = 'DELETE FROM ' + table_compass_array_Value + ' WHERE ' + field_valueColumn + ' = ' + valueId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllCompassMyValue(callback) {
	console.log('getAllCompassMyValue entering');
	var query = 'SELECT * FROM ' + table_compass_array_Value;
	console.log(query);
	var infoArray = new Array();	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var array = new Array();   
					var line = record[field_line];
					array.push(line);
					var column = record[field_column];
					array.push(column);
					var valueColumn = record[field_valueColumn];
					array.push(valueColumn);
					var valueCriteria = record[field_valueCriteria];
					array.push(valueCriteria);
					var valueLabel = record[field_valueLabel];
					array.push(valueLabel);
					infoArray.push(array);
				}
			}
			if (callback && callback != '') {
				callback(infoArray);
			}
		}, onError);
	});
}

function addImportantCriteria(importantCriteria1,importantCriteria2,importantCriteria3, callback) {
	console.log('addValueRadioArray entering with importantCriteria1 = ' + importantCriteria1 +' importantCriteria2 = '+importantCriteria2+' importantCriteria3 = '+ importantCriteria3 );
	var queryRemove  = 'DELETE FROM ' + table_compass_important_Criteria;
	var query = 'INSERT OR REPLACE INTO ' + table_compass_important_Criteria + ' (' + field_importantCriteria1 + ',' + field_importantCriteria2 + ',' + field_importantCriteria3 + ') VALUES ("' + importantCriteria1 +'","' + importantCriteria2 + '","' + importantCriteria3 + '");';
	console.log(queryRemove);
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(queryRemove, []);
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getImportantCriteria(callback) {
	console.log('getImortantCriteria entering');
	var query = 'SELECT * FROM ' + table_compass_important_Criteria;
	console.log(query);
	var ImortantCriteriaArray = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				
					var record = data.rows.item(0);
					var valueId = record[field_importantCriteria1];
					ImortantCriteriaArray.push(valueId);
					var valueId = record[field_importantCriteria2];
					ImortantCriteriaArray.push(valueId);
					var valueId = record[field_importantCriteria3];
					ImortantCriteriaArray.push(valueId);
				
			}

			if (callback && callback != '') {
				callback(ImortantCriteriaArray);
			}
		}, onError);
	});
}

function addMark(mark, callback) {
	console.log('addMark with valueId = ' + mark);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_mark + ' (' + field_compass_mark + ') VALUES (' + mark + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function  getProLifeMark(callback) {
	console.log('getProLifeMark entering');
	var query = 'SELECT * FROM ' + table_compass_mark;
	console.log(query);
	var mark = 0;

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
					mark = data.rows.item(0)[field_compass_mark];				
			}

			if (callback && callback != '') {
				callback(mark);
			}
		}, onError);
	});
}

function removeProLifeMark(callback) {
	console.log('removeProLifeMark with');
	var query = 'DELETE FROM ' + table_compass_mark ;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function addActionProLife(actionId,action, callback) {
	console.log('addActionProLife entering with action = ' + action);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_actions + ' (' + field_compass_actions_id + ',' + field_compass_actions + ') VALUES (' + actionId + ',"' + action + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function compass_Action_delete(id,callback) {

	console.log('compass_Action_delete entering ');
	var query = 'DELETE FROM ' + table_compass_actions + ' WHERE ' + field_compass_actions_id + ' = ' + id;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}


function getCompassProLifeAction(callback) {
	console.log('getCompassProLifeAction entering');
	var query = 'SELECT * FROM ' + table_compass_actions;
	console.log(query);
	var infoArray = new Array();	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i); 
					var line = record[field_compass_actions];
					var id = record[field_compass_actions_id];
					infoArray[id]=line;
				}
			}
			if (callback && callback != '') {
				callback(infoArray);
			}
		}, onError);
	});
}

function compass_actions_setDate(id,date,callback) {
	console.log('compass_actions_setDate entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_actions_temp + ' (' + field_compass_actions_key + ',' + field_compass_actions_temp + ') VALUES ("' + key_compass_actions_date+id + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function compass_actions_setResponse(id,response,callback) {
	console.log('compass_actions_setDate '+id+' entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_actions_temp + ' (' + field_compass_actions_key + ',' + field_compass_actions_temp + ') VALUES ("' + key_compass_actions_response+id + '","' + response + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getCompassProLifeDate(id,callbackIfSet,callbackIfNotSet) {
	console.log('getCompassProLifeDate '+id+' entering');
	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_actions_temp + ' WHERE ' + field_compass_actions_key + ' = ?', [ key_compass_actions_date+id ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_compass_actions_temp]));

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function getCompassProLifeResponse(id,callback) {
	console.log('getCompassProLifeResponse '+id+' entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_actions_temp + ' WHERE ' + field_compass_actions_key + ' = ?', [ key_compass_actions_response + id ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_compass_actions_temp];
					console.log('getCompassProLifeResponse text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResponse text area  = 0');
				callback("");
			}
		}, onError);
	});
}

function compass_actions_setResult(result,callback) {
	console.log('compass_actions_setResult  entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_actions_temp + ' (' + field_compass_actions_key + ',' + field_compass_actions_temp + ') VALUES ("' + key_compass_actions_result + '","' + result + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getCompassProLifeResult(callback) {
	console.log('getCompassProLifeResult  entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_actions_temp + ' WHERE ' + field_compass_actions_key + ' = ?', [ key_compass_actions_result ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_compass_actions_temp];
					console.log('getCompassProLifeResult text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResult text area  = 0');
				callback(0);
			}
		}, onError);
	});
}

function compass_actions_setValue(value1,value2,callback) {
	console.log('compass_actions_setValue');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_actions_temp + ' (' + field_compass_actions_key + ',' + field_compass_actions_temp + ') VALUES ("' + value1+ '","' + value2 + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}