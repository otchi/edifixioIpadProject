
/* JavaScript content from js/webSQL/compass/vision_webSQL.js in folder common */
var table_compass_vision_key = "T_COMPASS_VISION";
var table_compass_vision_images = "T_COMPASS_VISION_IMAGES";
var table_compass_myVision_titleImage = "T_COMPASS_VISION_TITLE_IMAGES";
var table_compass_myVision_myMissionVerbs = "T_COMPASS_VISION_MISSION_VERBS";
var table_compass_myMission_proLife_mark = "T_COMPASS_MYMISSION_MARK";
var table_compass_myMission_actions = "T_COMPASS_MYMISSION_ACTIONS";
//var table_compass_array_Value = "T_COMPASS_ARRAY_VALUES";

var field_vision_key = "key";
var field_vision_value = "value";
var field_vision_wish = "wish";
var field_vision_mission = "mission";
var field_vision_verbs = "verbs";
var field_compass_myMission_mark = "mark";
var key_compass_myMission_actions_response = "reponseAction_";
var key_compass_myMission_action_date = "dateAction";
var key_compass_myMission_action_result = "result";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_vision_key + '(' + field_vision_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_vision_value +' TEXT  )');
clearTableQueries.push('DELETE FROM ' + table_compass_vision_key);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_vision_images + ' (' + field_id + ' INTEGER NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
clearTableQueries.push('DELETE FROM ' + table_compass_vision_images);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_myVision_titleImage + ' (' + field_id + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
clearTableQueries.push('DELETE FROM ' + table_compass_myVision_titleImage);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_myVision_myMissionVerbs + ' (' + field_vision_verbs + ' INTEGER NOT NULL PRIMARY KEY )');
clearTableQueries.push('DELETE FROM ' + table_compass_myVision_myMissionVerbs);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_myMission_proLife_mark + '(' + field_compass_myMission_mark + ' INTEGER NOT NULL PRIMARY KEY )');
clearTableQueries.push('DELETE FROM ' + table_compass_myMission_proLife_mark);

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_myMission_actions + '(' + field_compass_actions_id + ' INTEGER NOT NULL PRIMARY KEY ,' + field_compass_actions + ' TEXT  )');
clearTableQueries.push('DELETE FROM ' + table_compass_myMission_actions);

//createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_compass_array_Value + '(' + field_line + ' INTEGER NOT NULL , ' + field_column + ' INTEGER NOT NULL ,' + field_valueColumn + ' INTEGER NOT NULL,' + field_valueCriteria + ' TEXT NOT NULL,' + field_valueLabel + ' TEXT NOT NULL , PRIMARY KEY ('+field_line+','+field_column+') ); ');
//clearTableQueries.push('DELETE FROM ' + table_compass_array_Value);

function compass_actions_setWish(wish,callback) {
	console.log('compass_actions_setWish  entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_key + ' (' + field_vision_key + ',' + field_vision_value + ') VALUES ("' + field_vision_wish + '","' + wish + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function getCompassVisionValue(value,callback) {
	console.log('getCompassVisionValue  entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_vision_key + ' WHERE ' + field_vision_key + ' = ?', [ value ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_vision_value];
					console.log('getCompassVisionValue text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResult text area  = 0');
				callback();
			}
		}, onError);
	});
}
function addVisionImage(imageId, value, callback) {
	console.log('addVisionImage entering with imageId = ' + imageId + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_images + ' (' + field_id + ',' + field_value + ') VALUES (' + imageId + ',"' + value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function getAllVisionImages(callback) {
	console.log('getAllVisionImages entering');
	var query = 'SELECT * FROM ' + table_compass_vision_images;
	console.log(query);
	var imagesMap = new Array();
	

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var imageId = record[field_id];
					var value = record[field_value];
					
					imagesMap[imageId]=value;
				}
			} 

			if (callback && callback != '') {
				callback(imagesMap);
			}
		}, onError);
	});
}

function compass_myVision_setTitleImage(id,title,callback) {
	console.log('compass_myVision_setTitleImage id = '+id+' and title = '+title+' entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_myVision_titleImage + ' (' + field_id + ',' + field_value + ') VALUES ("' + id + '","' + title + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllTitleImage(callback) {
	console.log('getAllTalentChildhoodImages entering');
	var query = 'SELECT * FROM ' + table_compass_myVision_titleImage;
	console.log(query);
	var imagesTitleMap = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var id = record[field_id];
					var value = record[field_value];
					imagesTitleMap[id] = value;
				}
			} 

			if (callback && callback != '') {
				callback(imagesTitleMap);
			}
		}, onError);
	});
}

function addVerbMyMission(verbId, callback) {
	console.log('addVerbMyMission entering with verbId = ' + verbId);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_myVision_myMissionVerbs + ' (' + field_vision_verbs + ') VALUES (' + verbId + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function removeVerbMyMission(verbId, callback) {
	console.log('removeVerbMyMission entering with verbId = ' + verbId);
	var query = 'DELETE FROM ' + table_compass_myVision_myMissionVerbs + ' WHERE ' + field_vision_verbs + ' = ' + verbId;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAllVerbsMyMission(callback) {
	console.log('getAllVerbsMyMission entering');
	var query = 'SELECT * FROM ' + table_compass_myVision_myMissionVerbs;
	console.log(query);
	var verbsIds = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var verbId = record[field_vision_verbs];
					verbsIds.push(verbId);
				}
			}

			if (callback && callback != '') {
				callback(verbsIds);
			}
		}, onError);
	});
}

function compass_vision_setMission(mission,callback) {
	console.log('compass_actions_setMission  entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_key + ' (' + field_vision_key + ',' + field_vision_value + ') VALUES ("' + field_vision_mission + '","' + mission + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function getCompassVisionMission(callback) {
	console.log('getCompassVisionMission  entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_vision_key + ' WHERE ' + field_vision_key + ' = ?', [ field_vision_mission ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_vision_value];
					console.log('getCompassVisionMission text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResult text area  = 0');
				callback();
			}
		}, onError);
	});
}

// opérations sur les notes
function addMarkProLife(mark, callback) {
	console.log('addMark with valueId = ' + mark);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_myMission_proLife_mark + ' (' + field_compass_myMission_mark + ') VALUES (' + mark + ')';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function  getMarkProLife(callback) {
	console.log('getProLifeMark entering');
	var query = 'SELECT * FROM ' + table_compass_myMission_proLife_mark;
	console.log(query);
	var mark = 0;

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
					mark = data.rows.item(0)[field_compass_myMission_mark];				
			}

			if (callback && callback != '') {
				callback(mark);
			}
		}, onError);
	});
}

function removeMarkProLife(callback) {
	console.log('removeProLifeMark with');
	var query = 'DELETE FROM ' + table_compass_myMission_proLife_mark ;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

// ajouter une action
function addActionMyMissionProLife(actionId,action, callback) {
	console.log('addActionMyMissionProLife entering with action = ' + action);
	var query = 'INSERT OR REPLACE INTO ' + table_compass_myMission_actions + ' (' + field_compass_actions_id + ',' + field_compass_actions + ') VALUES (' + actionId + ',"' + action + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function deleteActionMyMissionProLife(id,callback) {
	console.log('deleteActionMyMissionProLife '+id+' entering');
	var query = 'DELETE FROM ' + table_compass_myMission_actions + ' WHERE ' + field_compass_actions_id +' = '+ id ;
	console.log(query);			
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
	
}



function getActionProLife(callback) {
	console.log('getActionProLife entering');
	var query = 'SELECT * FROM ' + table_compass_myMission_actions;
	console.log(query);
	var infoArray = new Array();	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i); 
					var id = record[field_compass_actions_id];
					var line = record[field_compass_actions];
					infoArray[id]=line;
				}
			}
			if (callback && callback != '') {
				callback(infoArray);
			}
		}, onError);
	});
}

function compass_myMission_setActionResponse(id,response,callback) {
	console.log('compass_myMission_setActionResponse '+id+' entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_key + ' (' + field_vision_key + ',' + field_vision_value + ') VALUES ("' + key_compass_myMission_actions_response+id + '","' + response + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getCompassActionResponse(id,callback) {
	console.log('getCompassActionResponse '+id+' entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_vision_key + ' WHERE ' + field_vision_key + ' = ?', [ key_compass_myMission_actions_response + id ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_vision_value];
					console.log('getCompassProLifeResponse text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResponse text area  = 0');
				callback("");
			}
		}, onError);
	});
}

function compass_myMission_setActionDate(id,date,callback) {
	console.log('compass_actions_setDate entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_key + ' (' + field_vision_key + ',' + field_vision_value + ') VALUES ("' + key_compass_myMission_action_date+id + '","' + dateToUTC(date) + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getCompassActionDate(id,callbackIfSet,callbackIfNotSet) {
	console.log('getCompassProLifeDate '+id+' entering');
	
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_vision_key + ' WHERE ' + field_vision_key + ' = ?', [ key_compass_myMission_action_date+id ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var date = utcToDate(parseInt(record[field_vision_value]));

					if (callbackIfSet && callbackIfSet != '') {
						callbackIfSet(date);
					}
				}
			} else {

				if (callbackIfNotSet && callbackIfNotSet != '') {
					callbackIfNotSet();
				}
			}
		}, onError);
	});
}

function compass_myMission_setActionResult(text,callback) {
	console.log('compass_myMission_setActionResult entering');
	var query = 'INSERT OR REPLACE INTO ' + table_compass_vision_key + ' (' + field_vision_key + ',' + field_vision_value + ') VALUES ("' + key_compass_myMission_action_result + '","' + text + '")';
   
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}
function getCompassActionResult(callback) {
	console.log('getCompassActionResult  entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_compass_vision_key + ' WHERE ' + field_vision_key + ' = ?', [ key_compass_myMission_action_result ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var counterValue = record[field_vision_value];
					console.log('getCompassActionResult text area  = ' + counterValue);
					callback(counterValue);
					}
			} else {
				console.log('getCompassProLifeResponse text area  = ""');
				callback("");
			}
		}, onError);
	});
}