
/* JavaScript content from js/webSQL/progression/progression_webSQL.js in folder common */
var table_status_progression = "T_STATUS_PREGRESSION";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_status_progression + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY , ' + field_value + ' INT NOT NULL);');
clearTableQueries.push('DELETE FROM ' + table_status_progression);


function set_Status_Progression(key,value,callback){
	
	var query = 'INSERT OR REPLACE INTO ' + table_status_progression + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('setStatusProgression query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function get_Status_Progression(key,callbackIfTrue,callbackIfFalse) {

	console.log('get_Status_Progression entering with key = ' + key);
	var query = 'SELECT * FROM ' + table_status_progression + ' WHERE ' + field_key + ' = ' + '"'+key+'" ;';
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
	
}

