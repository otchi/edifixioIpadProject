
/* JavaScript content from js/webSQL/visibility/tellYou_webSQL.js in folder common */
var table_visibility_tellYou_key = "T_VISIBILITY_TELLYOU_KEY";

createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_visibility_tellYou_key + '(' + field_key + ' TEXT NOT NULL PRIMARY KEY , '+ field_value +' TEXT NOT NULL )');
clearTableQueries.push('DELETE FROM ' + table_visibility_tellYou_key);

function visibility_tellYou_setKey(key,value, callback) {

	var query = 'INSERT OR REPLACE INTO ' + table_visibility_tellYou_key + ' (' + field_key + ',' + field_value + ') VALUES ("' + key + '","' + value + '")';
	console.log('visibility_tellYou_setKey query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function visibility_tellYou_deleteKey(key,callback) {

	console.log('visibility_tellYou_deleteKey entering ');
	var query = 'DELETE FROM ' + table_visibility_tellYou_key + ' WHERE ' + field_key + ' = ' + '"'+key+'"';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function visibility_tellYou_getKey(key,callbackIfTrue,callbackIfFalse) {

	console.log('visibility_tellYou_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_visibility_tellYou_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function visibility_tellYou_getKey(key,callbackIfTrue,callbackIfFalse) {

	console.log('visibility_tellYou_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_visibility_tellYou_key + ' WHERE (' + field_key + ' = ' + '"'+key+'" );';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					value = record[field_value];
					callbackIfTrue(value);
				}
				
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}

function visibility_tellYou_getAllResponse(key,callbackIfTrue,callbackIfFalse) {

	console.log('visibility_tellYou_getKey entering with current key = ' + key);
	var query = 'SELECT * FROM ' + table_visibility_tellYou_key + ';';
	console.log(query);
	
	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {
			if (data.rows && data.rows.length != 0) {
				var listeResponse = new Array();
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var value = new Array();
					value.push( record[field_key]);
					value.push( record[field_value]);
					listeResponse.push(value);
				}
				callbackIfTrue(listeResponse);
			} else {
				if (callbackIfFalse && callbackIfFalse != '') {
					callbackIfFalse();
				}
			}
		}, onError);
	});
}
