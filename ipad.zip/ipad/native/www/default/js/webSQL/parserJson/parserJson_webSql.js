
/* JavaScript content from js/webSQL/parserJson/parserJson_webSql.js in folder common */
function getAllTableDeconnect(callback) {
	console.log('getAllTable entering');
	var query = "SELECT name FROM sqlite_master WHERE type='table'";
	console.log(query);
	var tableArray = new Array();

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {

				for (var i = 1; i < data.rows.length; i++) {
					tableArray.push(data.rows.item(i)['name']);
				}
			}
			if (callback && callback != '') {
				callback(tableArray);
			}
		}, onError);
	});
}

function getQueryTable(Table, callback) {

	//console.log('getAllTable entering');

	var query = "SELECT * FROM " + Table;
	
	if (callback && callback != '') {
		callback(query);
	}
}
function executeQuery(liste,indice,test,table,query,callback) {
	
	var tableArray = new Array();
	var tempTable="";
	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				tableArray.push(table);
				for (var i = 0; i < data.rows.length; i++) {
					tableArray.push(data.rows.item(i));
				}
				
				
				if(tableArray.length>0){
					test = '"'+tableArray[0]+'" :[';
					var t ="";
					for(var j=1;j<tableArray.length;j++){
						var val="{" ;
						for (row in tableArray[j]) {
							   val = val + ('"' + row + '" : "'+tableArray[j][row]+'",');	
							}
						val = val.substring(0, val.length-1) + '},';
						t = t + val ;
						}
					t = t.substring(0, t.length-1) + '],';
					test = test + t;
					tempTable=tableArray[0];
				}
				
			}
			if (callback && callback != '') {
				
				callback(test,indice,tempTable);
			}
		}, onError);
	});
}

function deleteTable(table, callback) {
	console.log('deleteTable entering with table = ' + table  );
	var query  = 'DELETE FROM ' + table;
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function tableNotTmpty(tables,table,callback){
	var findTable = false;
	console.log('tableNotTmpty with table = '+table );
	for(var i=0;i<tables.length;i++){
		if(tables[i]==table)findTable = true;
	}
	
	if (callback && callback != '') {
		
		callback(findTable);
	}
}

function addValueTableWithKey(key,value,table, callback) {
	console.log('addValueTableWithKey entering with key = ' + key + ' and value = ' + value);
	var query = 'INSERT OR REPLACE INTO ' + table + ' ( key ,value ) VALUES ("' + key + '","'+ value + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function addValuesTableWithKey(key,value,value1,table, callback) {
	console.log('addValuesTableWithKey entering with key = ' + key + ' and value = ' + value+ ' and value1 = ' + value1);
	var query = 'INSERT OR REPLACE INTO ' + table + ' ( id ,name,date ) VALUES ("' + key + '","'+ value + '","'+ value1 + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function addLastSeenPageId(key,value,table) {
	console.log('setLastSeenPageId entering');
	
	var query = 'INSERT OR REPLACE INTO ' + table + ' ( key ,value ) VALUES ("' + key + '","'+ value + '")';

	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query);
	});
}

function setJsonClient(name,login,jsonBdd,jsonBdd){
	
	var invocationData = {
			adapter : 'SQLAdapter',
			procedure : 'setJson',
			parameters : [name,login,jsonBdd,jsonBdd]
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadFeedsSuccessJson,
		onFailure : loadFeedsFailureJson
	});
}

function loadFeedsSuccessJson(){
	WL.Logger.debug("Feed retrieve success");
}

function loadFeedsFailureJson(){
	WL.Logger.error("Feed retrieve failure");
	
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}
