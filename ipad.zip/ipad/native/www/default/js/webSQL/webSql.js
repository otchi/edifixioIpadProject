
/* JavaScript content from js/webSQL/webSql.js in folder common */
var livebook_bdd = null;
var db_livebook = "livebook_bdd";

var table_users = "T_USERS";
var table_seenPages = "T_SEEN_PAGES";
var table_lockedPages = "T_LOCKED_PAGES";
var table_seenPages = "T_SEEN_PAGES";
var table_annotations = "T_ANNOTATIONS";
var table_user_data = "T_USER_DATA";
var table_activities_status = "T_ACTIVITIES_STATUS";

var field_id = 'id';
var field_pageId = 'pageId';
var field_criteriaNumber = 'criteriaNumber';
var field_stageNumber = 'stageNumber';
var field_annotation = 'annotation';
var field_value = 'value';
var field_status = 'status';
var field_key = 'key';
var field_date = 'date';
var field_talentId = 'talentId';
var field_screenId = 'screenId';
var field_answerId = 'answerId';
var field_talent_type = 'talentType';
var field_position = 'position';
var field_bloc_number = 'blocNumber';
var field_name = 'name';
var field_valueId = 'valueId';
var field_line = "lineNumber";
var field_column = "columnNumber";
var field_valueColumn= "valueNumber";
var field_valueCriteria = "valueCriteria";
var field_valueLabel = "valueLabel";
var field_importantCriteria1 = "importantCriteria1";
var field_importantCriteria2 = "importantCriteria2";
var field_importantCriteria3 = "importantCriteria3";
var field_compass_mark = "proLifeMark";
var field_compass_actions = "proLifeActions";
var field_compass_actions_id = "actionsId";
var field_nameId = "userName";
var field_password = "password";

var key_last_seen_page = 'lastSeenPage';

var createTableQueries = new Array();
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_seenPages + '(' + field_pageId + ' TEXT NOT NULL PRIMARY KEY)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_user_data + ' (' + field_key + ' TEXT NOT NULL PRIMARY KEY, ' + field_value + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_lockedPages + ' (' + field_pageId + ' TEXT NOT NULL PRIMARY KEY)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_annotations + ' (' + field_pageId + ' TEXT NOT NULL PRIMARY KEY, ' + field_annotation + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_activities_status + ' (' + field_screenId + ' TEXT NOT NULL PRIMARY KEY, ' + field_status + ' TEXT)');
createTableQueries.push('CREATE TABLE IF NOT EXISTS ' + table_users + ' (' + field_nameId + ' TEXT NOT NULL PRIMARY KEY, ' + field_password + ' TEXT)');


var clearTableQueries = new Array();
clearTableQueries.push('DELETE FROM ' + table_seenPages);
clearTableQueries.push('DELETE FROM ' + table_user_data);
clearTableQueries.push('DELETE FROM ' + table_lockedPages);
clearTableQueries.push('DELETE FROM ' + table_annotations);
clearTableQueries.push('DELETE FROM ' + table_activities_status);
clearTableQueries.push('DELETE FROM ' + table_users);

loadJsFile("js/webSQL/authentication/authentication_webSQL.js");
loadJsFile("js/webSQL/progression/progression_webSQL.js");
loadJsFile("js/webSQL/leadership/fiveLeaders_webSQL.js");
loadJsFile("js/webSQL/leadership/chooseQualities_webSQL.js");
loadJsFile("js/webSQL/leadership/development_webSQL.js");
loadJsFile("js/webSQL/leadership/questions_webSQL.js");
loadJsFile("js/webSQL/leadership/questionsStereotype_webSQL.js");
loadJsFile("js/webSQL/leadership/attitude_webSQL.js");

loadJsFile("js/webSQL/talents/otherRecognize_webSQL.js");
loadJsFile("js/webSQL/talents/iEnhance_webSQL.js");
loadJsFile("js/webSQL/talents/iPlay_webSQL.js");
loadJsFile("js/webSQL/talents/iSpot_webSQL.js");
loadJsFile("js/webSQL/talents/manifeste_webSQL.js");
loadJsFile("js/webSQL/talents/iRecognize_webSQL.js");
loadJsFile("js/webSQL/talents/childhood_webSQL.js");

loadJsFile("js/webSQL/sayI/iSayI_webSQL.js");
loadJsFile("js/webSQL/sayI/morningPages_webSQL.js");
loadJsFile("js/webSQL/sayI/myLittleMe_webSQL.js");
loadJsFile("js/webSQL/sayI/iListenMyLittleMe_webSQL.js");
loadJsFile("js/webSQL/sayI/myBeliefs_webSQL.js");
loadJsFile("js/webSQL/sayI/otherVoices_webSQL.js");
loadJsFile("js/webSQL/sayI/passion_webSQL.js");
loadJsFile("js/webSQL/sayI/passion_step2_webSQL.js");
loadJsFile("js/webSQL/sayI/passion_step4_webSQL.js");

loadJsFile("js/webSQL/barometer/barometer_webSQL.js");
loadJsFile("js/webSQL/barometer/barometerInit_webSQL.js");
loadJsFile("js/webSQL/compass/values_webSQL.js");
loadJsFile("js/webSQL/compass/vision_webSQL.js");

loadJsFile("js/webSQL/projectMyself/InFiveYears_webSQL.js");
loadJsFile("js/webSQL/projectMyself/firstStep_webSQL.js");

loadJsFile("js/webSQL/visibility/tellYou_webSQL.js");

loadJsFile("js/webSQL/myNetwork/myInternalNetwork_webSQL.js");


loadJsFile("js/webSQL/parserJson/parserJson_webSql.js");

loadJsFile("js/webSQL/calendar/calendar_webSQL.js");
loadJsFile("js/webSQL/chat/chat_webSQL.js");



function initDB(callback) {
	console.log("initDB entering");

	try {
		if (window.openDatabase) {
			livebook_bdd = openDatabase(db_livebook, '1.0', 'Store user data', 20 * 1024 * 1024);
			createTables(0, callback);
		} else {
			console.log('not supported');
		}
	} catch (e) {
		console.log("Error creating/retrieving the database : " + e);
	}
}

function createTables(index, callback) {

	if (index < createTableQueries.length) {
		var query = createTableQueries[index];
		console.log("query = " + query);

		livebook_bdd.transaction(function(tx) {
			tx.executeSql(query, null, createTables(index + 1, callback), onError);
		});
	} else {
		getAllTable();

		if (callback && callback != '') {
			callback();
		}
	}
}

function getAllTable() {
	console.log('getAllTable entering');
	var query = "SELECT tbl_name, sql from sqlite_master WHERE type = 'table'";

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					var tbl_name = record['tbl_name'];
					console.log('tbl_name = ' + tbl_name);
				}
			} else {
				console.log('no result');
			}
		}, onError);
	});
}

function setLastSeenPageId(activePageId) {
	console.log('setLastSeenPageId entering with activePageId = ' + activePageId);

	var query = 'INSERT OR REPLACE INTO ' + table_user_data + ' (' + field_key + "," + field_value + ') VALUES ("' + key_last_seen_page + '", "' + activePageId + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query);
	});
}

function getLastSeenPageId(callback) {
	console.log('getLastSeenPageId entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_user_data + ' WHERE ' + field_key + ' = ?', [ key_last_seen_page ], function(tx, data) {
			var lastSeenPageId = '';

			if (data.rows && data.rows.length != 0) {
				lastSeenPageId = data.rows.item(0)[field_value];
			}

			console.log('getLastSeenPageId lastSeenPageId = ' + lastSeenPageId);

			if (callback && callback != '') {
				callback(lastSeenPageId);
			}
		}, onError);
	});
}

function insertSeenPageId(pageId) {
	console.log('addSeenPageId entering');

	livebook_bdd.transaction(function(tx) {
		tx.executeSql('INSERT OR REPLACE INTO ' + table_seenPages + ' (' + field_pageId + ') VALUES ("' + pageId + '")', [], onSuccessExecuteSql, onError);
	});
}

function hasBeenSeen(pageId, presentCallBack, missingCallBack) {
	console.log('hasBeenSeen entering');

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_seenPages + ' WHERE ' + field_pageId + ' = ?', [ pageId ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log(pageId + ' is present in the table ' + table_seenPages);

				if (presentCallBack && presentCallBack != '') {
					presentCallBack(pageId);
				}
			} else {
				console.log(pageId + ' is not present in the table ' + table_seenPages);

				if (missingCallBack && missingCallBack != '') {
					missingCallBack(pageId);
				}
			}
		}, onError);
	});
}

function addLockedPage(pageId, callback) {
	console.log('addLockedPage entering with pageId = ' + pageId);

	var query = 'INSERT OR REPLACE INTO ' + table_lockedPages + ' (' + field_pageId + ') VALUES ("' + pageId + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], callback(), onError);
	});
}

function isLockedPage(pageId, callbackIfLocked, callbackIfNotLocked) {
	console.log('getAnnotation entering with pageId = ' + pageId);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_lockedPages + ' WHERE ' + field_pageId + ' = ?', [ pageId ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log("this page is locked");

				if (callbackIfLocked && callbackIfLocked != '') {
					callbackIfLocked();
				}
			} else {
				console.log("This page is not locked");

				if (callbackIfNotLocked && callbackIfNotLocked != '') {
					callbackIfNotLocked();
				}
			}
		}, onError);
	});
}

function getAnnotation(pageId, callback) {
	console.log('getAnnotation entering with pageId = ' + pageId);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql('SELECT * FROM ' + table_annotations + ' WHERE ' + field_pageId + ' = ?', [ pageId ], function(tx, data) {

			if (data.rows && data.rows.length != 0) {
				console.log("There is annotations for this page");
				var annotation = data.rows.item(0)[field_annotation];
				callback(htmlDecode(annotation));
			} else {
				console.log("No annotations for this page");
				callback('');
			}
		}, onError);
	});
}

function setAnnotation(pageId, annotation, callback) {
	console.log('setAnnotation entering with pageId = ' + pageId + " and annotation = " + annotation);

	var query = 'INSERT OR REPLACE INTO ' + table_annotations + ' (' + field_pageId + "," + field_annotation + ') VALUES ("' + pageId + '", "' + htmlEncode(annotation) + '")';
	console.log('query = ' + query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], callback(), onError);
	});
}

function getActivityStatus(screenId, callback) {
	console.log('getActivityStatus entering with screenId = ' + screenId);
	var query = 'SELECT * FROM ' + table_activities_status + ' WHERE ' + field_screenId + ' = \'' + screenId + '\'';
	console.log(query);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			var activityStatus = '';
			if (data.rows && data.rows.length != 0) {
				activityStatus = data.rows.item(0)[field_status];
				console.log("status for screen id " + screenId + " : " + activityStatus);
			}
			callback(activityStatus);
		}, onError);
	});
}

function setActivityStatus(screenId, activityStatus, callback) {
	console.log('setActivityStatus entering with screenId = ' + screenId + ' and activityStatus = ' + activityStatus);
	var query = 'INSERT OR REPLACE INTO ' + table_activities_status + ' (' + field_screenId + ', ' + field_status + ') VALUES ("' + screenId + '", "' + activityStatus + '")';
	console.log(query);

	livebook_bdd.transaction(function(tx) {
		tx.executeSql(query, [], function() {

			if (callback && callback != '') {
				callback();
			}
		}, onError);
	});
}

function getAccessibleOrInProgressActivity(callback) {
	console.log('getAccessibleOrInProgressActivity entering');
	var query = 'SELECT * FROM ' + table_activities_status + ' WHERE ' + field_status + ' = \'' + SCREEN_STATUS_ACCESSIBLE + '\' OR ' + field_status + ' = \'' + SCREEN_STATUS_IN_PROGRESS + '\'';
	console.log(query);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			var activityId = '';

			if (data.rows && data.rows.length != 0) {
				activityId = data.rows.item(0)[field_screenId];
				console.log("getAccessibleOrInProgressActivity - activity id : " + activityId);
			} else {
				console.log('getAccessibleOrInProgressActivity : no activity in progress or accessible');
			}

			callback(activityId);
		}, onError);
	});
}

function getAllFinishedActivities(callback) {
	console.log('getAllFinishedActivities entering');
	var query = 'SELECT * FROM ' + table_activities_status + ' WHERE ' + field_status + ' = \'' + SCREEN_STATUS_FINISHED + '\'';
	console.log(query);

	livebook_bdd.readTransaction(function(tx) {
		tx.executeSql(query, [], function(tx, data) {

			var activities = new Array();

			if (data.rows && data.rows.length != 0) {

				for (var i = 0; i < data.rows.length; i++) {
					var record = data.rows.item(i);
					activityId = record[field_screenId];
					activities.push(activityId);
					console.log("getAllFinishedActivities - activity id : " + activityId + ' is finished');
				}
			} else {
				console.log('getAllFinishedActivities : no activity finished');
			}

			callback(activities);
		}, onError);
	});
}

// **********************//
// -- Generic function --//
// **********************//
function clearTables(index, callback) {
	console.log("clearTables entering");

	if (index < clearTableQueries.length) {
		var query = clearTableQueries[index];
		console.log("query = " + query);

		livebook_bdd.transaction(function(tx) {
			tx.executeSql(query, null, clearTables(index + 1, callback), onError);
		});
	} else {
		if (callback && callback != '') {
			callback();
		}
	}
}

function onError(tx, err) {
	console.log(err.message);
}

function onSuccessExecuteSql(tx, results) {
	console.log('Execute SQL completed');
}