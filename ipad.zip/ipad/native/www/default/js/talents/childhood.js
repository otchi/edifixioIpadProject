
/* JavaScript content from js/talents/childhood.js in folder common */
// On lost focus save current answer
$('#' + talentsChildhoodPage.id + ' [type=text][name^="talents_childhood_"][name*="_answer_"]').on("blur", function(e) {
	var answerId = parseInt($(this).attr("data-answer"));
	var value = $(this).val();

	addTalentChildhoodAnswer(answerId, value, function() {
		console.log('answer added');
		setActivityStatus(talentsChildhoodPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log("Activity 2 is now ion progress");
		});
	});
});

// On key press check answer and display talents bloc if all text are field
$('#' + talentsChildhoodPage.id + ' [type=text][name^="talents_childhood_"][name*="_answer_"]').on("keyup", function(e) {
	var displayAnswerValidButton = true;
	$('#' + talentsChildhoodPage.id + ' [type=text][name^="talents_childhood_"][name*="_answer_"]').each(function(index, value) {
		var value = $(this).val();

		if (isBlank(value)) {
			displayAnswerValidButton = false;
		}
	});
	toggleEnabling('#talents_childhood_answers_validation', !displayAnswerValidButton);
});

$(document).on("pagebeforeshow", "#" + talentsChildhoodPage.id, function(event) {
	getAllTalentChildhoodAnswers(function(answerMap) {
		var nonBlankAnswerNumber = 0;
		for ( var key in answerMap) {
			var answer = answerMap[key];
			$inputText = $('#' + talentsChildhoodPage.id + ' [type=text][name^="talents_childhood_"][name*="_answer_"][data-answer="' + key + '"]');
			$inputText.val(answer);

			if (!isBlank(answer)) {
				nonBlankAnswerNumber++;
			}
		}
		console.log('nonBlankAnswerNumber = ' + nonBlankAnswerNumber);
		toggleEnabling('#talents_childhood_answers_validation', nonBlankAnswerNumber != 10);
	});

	isTalentsChildhoodAnswerValidated(function() {
		disableAllInputText();
		toggleVisibility('#talents_childhood_bloc', true);
		toggleEnabling('#talents_childhood_talents_validation', true);
		toggleVisibility('#talents_childhood_answers_validation', false);
	}, function() {
		toggleVisibility('#talents_childhood_bloc', false);
	});

	// display selected talents
	setSelectedTalents();

	// If the activity is locked, hide action buttons;
	getActivityStatus(talentsChildhoodPage.id, function(activityStatus) {
		console.log("status = " + activityStatus);
		if (activityStatus == SCREEN_STATUS_FINISHED) {
			$('#talents_childhood_add_talent').hide();
			$('#talents_childhood_talents_validation').hide();
		}
	});

	getAllTalentChildhoodImages(function(imagesMap) {
		for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("talentsChildhoodImage");
			image.setAttribute("src", imagesMap[imageId]);

			$('#talents_childhood_image_' + imageId).empty();
			document.getElementById('talents_childhood_image_' + imageId).appendChild(image);
		}
	});
});

$('#talents_childhood_answers_validation').on("click", function(e) {
	disableAllInputText();
	valideTalentsChildhoodAnswer(function() {
		console.log('answers validated');
		toggleVisibility('#talents_childhood_bloc', true);
		toggleEnabling('#talents_childhood_answers_validation', true);
		toggleEnabling('#talents_childhood_talents_validation', true);
	});
});

function disableAllInputText() {
	console.log('disableAllInputText entering');

	$('#' + talentsChildhoodPage.id + ' [type=text][name^="talents_childhood_"][name*="_answer_"]').each(function(index, value) {
		toggleEnabling('#' + $(this).attr('id'), true);
		$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
	});
}

// load list of talents into the popup
var aClass = 'a';
var bClass = 'b';
var cClass = 'c';
var dClass = 'd';
var currentClass = 'a';

for ( var key in talentMap) {
	var talentLabel = getTalentLocalizedLabel(key);

	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<label for="talents_childhood_checkbox_' + key + '">' + talentLabel + '</label>';
	htmlCode += '<input name="talents_childhood_checkbox_' + key + '" id="talents_childhood_checkbox_' + key + '" type="checkbox" data-mini="true" value="' + key + '"/>';
	htmlCode += '</div>';

	$('#talents_childhood_talent_list').append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}

// On popup open
$("#talents_childhood_talent_popup").on("popupbeforeposition", function(e, ui) {
	console.log('popup open');

	// uncheck all checkbox
	$("#" + talentsChildhoodPage.id + " [type='checkbox']").each(function(i) {
		$(this).attr('checked', false).checkboxradio("refresh");
	});

	// check chekbox from database
	getAllTalentChildhood(function(talentIds) {
		for (var i = 0; i < talentIds.length; i++) {
			$("#" + talentsChildhoodPage.id + " [type='checkbox'][value='" + talentIds[i] + "']").prop("checked", true).checkboxradio("refresh");
		}

		if (talentIds.length == 3) {
			lockCheckboxes();
		} else {
			unlockCheckboxes();
		}
	});
});

// On close set selected talents
$("#talents_childhood_talent_popup").on("popupafterclose", function(e, ui) {
	setSelectedTalents();
});

// Add click event on each checkbox
$("#" + talentsChildhoodPage.id + " [type='checkbox']").on("click", function(e) {
	var talentId = parseInt($(this).attr("value"));
	var isSelected = $(this).is(':checked');

	if (isSelected) {
		addTalentChildhood(talentId, function() {
			console.log('talent added');
		});
	} else if (!isSelected) {
		removeTalentChildhood(talentId, function() {
			console.log('talent removed');
		});
	}

	if ($("#" + talentsChildhoodPage.id + " [type='checkbox']:checked").length == 3) {
		lockCheckboxes();
	} else {
		unlockCheckboxes();
	}
});

function lockCheckboxes() {
	console.log('disableUncheckedCheckboxes entering');

	// Disabling all checkboxes
	$("#" + talentsChildhoodPage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', true);
		$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});

	// Enabling checked checkboxes
	$("#" + talentsChildhoodPage.id + " [type='checkbox']:checked").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

function unlockCheckboxes() {
	$("#" + talentsChildhoodPage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

function setSelectedTalents() {
	getAllTalentChildhood(function(talentIds) {
		$("#talents_childhood_talent_1").html('');
		$("#talents_childhood_talent_2").html('');
		$("#talents_childhood_talent_3").html('');

		for (var i = 0; i < talentIds.length; i++) {
			$("#talents_childhood_talent_" + (i + 1)).html(getTalentLocalizedLabel(talentIds[i]));
		}

		if (talentIds.length == 3) {
			toggleEnabling('#talents_childhood_talents_validation', false);
		} else {
			toggleEnabling('#talents_childhood_talents_validation', true);
		}
	});
}

// Add click event on button
$("#talents_childhood_talents_validation").on("click", function(e) {
	setActivityStatus(talentsChildhoodPage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression('talent', 28, function(){
			console.log('activity 2 finished');
			setActivityStatus(talentsManifestePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 3 is now accessible');
				$.mobile.changePage("#" + talentsManifestePage.id);
			});
		});
	});
});

$("#talents_childhood_photo_button_1").on("click", function(e) {
	$("#talents_childhood_file_1").click();
});

$("#talents_childhood_photo_button_2").on("click", function(e) {
	$("#talents_childhood_file_2").click();
});

// File upload
$("#" + talentsChildhoodPage.id + " input[type=file]").on('change', function(event) {
	var imageNumber = $(this).attr("data-image");
	var file = $(this).prop("files")[0];
	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		console.log("file type = " + file.type);

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			addTalentChildhoodImage(imageNumber, base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.classList.add("talentsChildhoodImage");
				image.setAttribute("src", base64Value);

				$('#talents_childhood_image_' + imageNumber).empty();
				document.getElementById('talents_childhood_image_' + imageNumber).appendChild(image);
			});
		});

		/*
		 * } else { console.log('Not a image'); }
		 */
	} else {
		console.log('file removed or has not a image extension');
	}
});
