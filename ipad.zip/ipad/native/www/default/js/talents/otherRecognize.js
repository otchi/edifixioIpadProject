
/* JavaScript content from js/talents/otherRecognize.js in folder common */
// load list of talents into the popup
var aClass = 'a';
var bClass = 'b';
var cClass = 'c';
var dClass = 'd';
var currentClass = 'a';

for ( var key in talentMap) {
	var talentLabel = getTalentLocalizedLabel(key);
	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<input name="talents_otherrecognize_radio" id="talents_otherrecognize_radio_' + key + '" type="radio" data-mini="true" value="' + key + '"/>';
	htmlCode += '<label for="talents_otherrecognize_radio_' + key + '">' + talentLabel + '</label>';
	htmlCode += '</div>';

	$('#talents_otherrecognize_talent_list').append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}

var otherRecognizeTalentBlocNumber = null;
var otherRecognizeTalentPosition = null;
var otherRecognizeSpanToUpdate = null;

// Add event on + button click
$("#" + talentsOtherRecognizePage.id + " [id^='talents_otherrecognize_add_talent_']").on("click", function(e) {
	otherRecognizeTalentBlocNumber = parseInt($(this).parent().attr('data-talent-bloc-number'));
	otherRecognizeTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	otherRecognizeSpanToUpdate = $("#" + talentsOtherRecognizePage.id + " li[data-talent-bloc-number='" + otherRecognizeTalentBlocNumber + "'][data-talent-number='" + otherRecognizeTalentPosition + "'] span");
	setActivity4InProgress();
});

// Add event on each radio in popup button click
$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_popup [type='radio']").on("click", function(e) {
	var talentId = parseInt($(this).attr("value"));

	addTalentOtherRecognize(otherRecognizeTalentBlocNumber, otherRecognizeTalentPosition, talentId, function() {
		console.log('talent added in base');
		otherRecognizeSpanToUpdate.html(getTalentLocalizedLabel(talentId));
		console.log('otherRecognizeSpanToUpdate = ' + otherRecognizeSpanToUpdate.html());

		getTalentsOtherRecognizeCount(function(number) {
			if (number == 12) {
				toggleEnabling("#talents_otherrecognize_talents_validation_1", false);
			} else {
				toggleEnabling("#talents_otherrecognize_talents_validation_1", true);
			}

			// close the popup
			$('#talents_otherrecognize_talent_popup').popup("close");
		});
	});
});

function setActivity4InProgress() {
	setActivityStatus(talentsOtherRecognizePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log("Activity 4 is now in progress");
	});
}

// On popup open
$("#talents_otherrecognize_talent_popup").on("popupbeforeposition", function(e, ui) {
	getTalentsOtherRecognize(otherRecognizeTalentBlocNumber, function(talentMap) {

		// unckeck and enable all radio button
		$("#talents_otherrecognize_talent_popup [type=radio]").each(function(i) {
			$(this).removeAttr("checked").prop("checked", false).checkboxradio("enable").checkboxradio("refresh");
		});

		for ( var talentPosition in talentMap) {
			if (talentPosition == otherRecognizeTalentPosition) {
				$("#talents_otherrecognize_talent_popup [type='radio'][value='" + talentMap[talentPosition] + "']").prop("checked", true).checkboxradio("refresh");
			} else {
				// disable value for this talent type
				$("#talents_otherrecognize_talent_popup [type='radio'][value='" + talentMap[talentPosition] + "']").checkboxradio("disable").checkboxradio("refresh");
			}
		}
	});
});

$(document).on("pagebeforeshow", "#" + talentsOtherRecognizePage.id, function(event) {

	getAllTalentsOtherRecognize(function(talentsMap) {
		for ( var keyBlocNumber in talentsMap) {
			var talentsMap2 = talentsMap[keyBlocNumber];

			for ( var keyTalentPosition in talentsMap2) {
				var talentId = talentsMap2[keyTalentPosition];
				var talentLabel = getTalentLocalizedLabel(talentId);

				$("#" + talentsOtherRecognizePage.id + " li[data-talent-bloc-number='" + keyBlocNumber + "'][data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
			}
		}
	});

	getTalentsOtherRecognizeCount(function(number) {
		if (number == 12) {
			toggleEnabling("#talents_otherrecognize_talents_validation_1", false);
		} else {
			toggleEnabling("#talents_otherrecognize_talents_validation_1", true);
		}
	});

	// Load and display images
	getAllTalentOtherRecognizeImages(function(imagesMap) {
		for ( var imageId in imagesMap) {
			var image = document.createElement("img");
			image.classList.add("talentsOtherRecognizeImage");
			image.setAttribute("src", imagesMap[imageId]);

			$('#talents_otherrecognize_image_' + imageId).empty();
			document.getElementById('talents_otherrecognize_image_' + imageId).appendChild(image);
		}
	});

	isTalentsOtherRecognizeValidated(function() {
		// hide all add talent button
		$('a[id^="talents_otherrecognize_add_talent_"]').hide();

		// hide validation button 1
		toggleVisibility('#talents_otherrecognize_talents_validation_1', false);

		// show bloc
		toggleVisibility("#talents_otherrecognize_bloc", true);

		// show add talent results button
		$('a[id="talents_otherrecognize_add_talent_result"]').show();
	}, function() {
		toggleVisibility("#talents_otherrecognize_bloc", false);

		getTalentsOtherRecognizeCount(function(number) {
			if (number == 12) {
				toggleEnabling("#talents_otherrecognize_talents_validation_1", false);
			} else {
				toggleEnabling("#talents_otherrecognize_talents_validation_1", true);
			}
		});
	});

	getAllTalentOtherRecognizeResults(function(talentIds) {
		// clear content
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_1").html('');
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_2").html('');
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_3").html('');

		// Set selected talents
		for (var i = 0; i < talentIds.length; i++) {
			$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_" + (i + 1)).html(getTalentLocalizedLabel(talentIds[i]));
		}

		if (talentIds.length == 3) {
			toggleEnabling("#talents_otherrecognize_talents_validation_2", false);
		} else {
			toggleEnabling("#talents_otherrecognize_talents_validation_2", true);
		}
	});

	// If the activity is finished, hide action buttons;
	getActivityStatus(talentsOtherRecognizePage.id, function(activityStatus) {
		console.log("status = " + activityStatus);

		if (activityStatus == SCREEN_STATUS_FINISHED) {
			$('[id^="talents_otherrecognize_add_talent_"]').hide();
			$('#talents_otherrecognize_talents_validation_1').hide();
			$('#talents_otherrecognize_talents_validation_2').hide();
		}
	});
});

// Hide input type="file" for photo
/*
 * $("#talents_otherrecognize_file_1").hide();
 * $("#talents_otherrecognize_file_2").hide();
 * $("#talents_otherrecognize_file_3").hide();
 * $("#talents_otherrecognize_file_4").hide();
 */

$("#talents_otherrecognize_photo_button_1").on("click", function(e) {
	$("#talents_otherrecognize_file_1").click();
});

$("#talents_otherrecognize_photo_button_2").on("click", function(e) {
	$("#talents_otherrecognize_file_2").click();
});

$("#talents_otherrecognize_photo_button_3").on("click", function(e) {
	$("#talents_otherrecognize_file_3").click();
});

$("#talents_otherrecognize_photo_button_4").on("click", function(e) {
	$("#talents_otherrecognize_file_4").click();
});

// File upload
$("#" + talentsOtherRecognizePage.id + " input[type=file]").on('change', function(event) {
	var imageNumber = $(this).attr("data-image");
	var file = $(this).prop("files")[0];

	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			addTalentOtherRecognizeImage(imageNumber, base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.classList.add("talentsOtherRecognizeImage");
				image.setAttribute("src", base64Value);

				$('#talents_otherrecognize_image_' + imageNumber).empty();
				document.getElementById('talents_otherrecognize_image_' + imageNumber).appendChild(image);
			});
		});

		/*
		 * } else { console.log('Not a image'); }
		 */
	} else {
		console.log('file removed or has not a image extension');
	}
});

// Add click event on validation button 1
$("#talents_otherrecognize_talents_validation_1").on("click", function(e) {
	valideTalentsOtherRecognize(function() {
		// hide all add talent button
		$('a[id^="talents_otherrecognize_add_talent_"]').hide();

		// hide validation button 1
		toggleVisibility('#talents_otherrecognize_talents_validation_1', false);

		// show bloc
		toggleVisibility('#talents_otherrecognize_bloc', true);

		// show add talent results button
		$('a[id="talents_otherrecognize_add_talent_result"]').show();

		// disable validation button 2
		toggleEnabling("#talents_otherrecognize_talents_validation_2", true);
	});
});

// On result popup open
$("#talents_otherrecognize_talent_result_popup").on("popupbeforeposition", function(e, ui) {
	// Retrieve all talents selected in the screen
	currentClass = 'a';

	getAllTalentsOtherRecognize(function(talentMap) {
		var talentSet = new Array();

		// Build a set of selected talent ids
		for (talentBlocKey in talentMap) {
			var talentMap2 = talentMap[talentBlocKey];

			for (talentPositionKey in talentMap2) {
				var talentId = talentMap2[talentPositionKey];

				if ($.inArray(talentId, talentSet) == -1) {
					talentSet.push(talentId);
				}
			}
		}

		// Clear listcontent
		$('#talents_otherrecognize_talent_result_list').html('');

		// Set popup content
		for (var i = 0; i < talentSet.length; i++) {
			var talentId = talentSet[i];
			var talentLabel = getTalentLocalizedLabel(talentId);

			var htmlCode = '<div class="ui-block-' + currentClass + '">';
			htmlCode += '<label for="talents_otherrecognize_checkbox_' + talentId + '">' + talentLabel + '</label>';
			htmlCode += '<input name="talents_otherrecognize_checkbox_' + talentId + '" id="talents_otherrecognize_checkbox_' + talentId + '" type="checkbox" data-mini="true" value="' + talentId + '"/>';
			htmlCode += '</div>';

			$('#talents_otherrecognize_talent_result_list').append(htmlCode);

			if (currentClass == aClass) {
				currentClass = bClass;
			} else if (currentClass == bClass) {
				currentClass = cClass;
			} else if (currentClass == cClass) {
				currentClass = dClass;
			} else if (currentClass == dClass) {
				currentClass = aClass;
			}
		}

		// add click event on each checkbox
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_result_popup [type='checkbox']").each(function(i) {
			$(this).checkboxradio().checkboxradio("refresh");

			$(this).on("click", function() {
				var isSelected = $(this).is(':checked');
				var talentId = parseInt($(this).attr("value"));

				if (isSelected) {
					addTalentOtherRecognizeResult(talentId, function() {
						console.log('talent added');
					});
				} else if (!isSelected) {
					removeTalentOtherRecognizeResult(talentId, function() {
						console.log('talent removed');
					});
				}

				getAllTalentOtherRecognizeResults(function(talentIds) {
					if (talentIds.length == 3) {
						talentOtherRecognize_LockCheckboxes();
					} else {
						talentOtherRecognize_unlockCheckboxes();
					}
				});
			});
		});

		// check checkboxes
		getAllTalentOtherRecognizeResults(function(talentIds) {
			for (var i = 0; i < talentIds.length; i++) {
				$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_result_popup [type='checkbox'][value='" + talentIds[i] + "']").prop("checked", true).checkboxradio("refresh");
			}

			if (talentIds.length == 3) {
				talentOtherRecognize_LockCheckboxes();
			} else {
				talentOtherRecognize_unlockCheckboxes();
			}
		});
	});
});

function talentOtherRecognize_LockCheckboxes() {
	console.log('talentOtherRecognize_LockCheckboxes entering');

	// Disabling all checkboxes
	$("#" + talentsOtherRecognizePage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', true);
		$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});

	// Enabling checked checkboxes
	$("#" + talentsOtherRecognizePage.id + " [type='checkbox']:checked").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

function talentOtherRecognize_unlockCheckboxes() {
	console.log('talentOtherRecognize_unlockCheckboxes entering');

	$("#" + talentsOtherRecognizePage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

// On result popup close
$("#talents_otherrecognize_talent_result_popup").on("popupafterclose", function(e, ui) {

	getAllTalentOtherRecognizeResults(function(talentIds) {
		// clear content
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_1").html('');
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_2").html('');
		$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_3").html('');

		// Set selected talents
		for (var i = 0; i < talentIds.length; i++) {
			$("#" + talentsOtherRecognizePage.id + " #talents_otherrecognize_talent_" + (i + 1)).html(getTalentLocalizedLabel(talentIds[i]));
		}

		if (talentIds.length == 3) {
			toggleEnabling("#talents_otherrecognize_talents_validation_2", false);
		} else {
			toggleEnabling("#talents_otherrecognize_talents_validation_2", true);
		}
	});
});

// Add click event on validation button 2
$("#talents_otherrecognize_talents_validation_2").on("click", function(e) {
	setActivityStatus(talentsOtherRecognizePage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 57, function(){
			console.log('activity 4 finished');
			setActivityStatus(talentsISpotPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 5 is now accessible');
				$.mobile.changePage("#" + talentsISpotPage.id);
			});
		});
	});
});
