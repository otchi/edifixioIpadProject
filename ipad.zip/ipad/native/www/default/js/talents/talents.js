
/* JavaScript content from js/talents/talents.js in folder common */
function Talent(id, talentLabel) {
	this.id = id;
	this.talentLabel = talentLabel;
};

var talentMap = {};
/*
createTalent(1, 'talent one', 'talent un');
createTalent(2, 'talent two', 'talent deux');
createTalent(3, 'talent three', 'talent trois');
createTalent(4, 'talent four', 'talent quatre');
createTalent(5, 'talent five', 'talent cinq');
createTalent(6, 'talent six', 'talent six');
createTalent(7, 'talent seven', 'talent sept');
createTalent(8, 'talent height', 'talent huit');
createTalent(9, 'talent nine', 'talent neuf');
createTalent(10, 'talent ten', 'talent dix');
createTalent(11, 'talent eleven', 'talent onze');
createTalent(12, 'talent twelve', 'talent douze');

*/

function getTalentLocalizedLabel(talentId) {
	var talent = talentMap[talentId];

	if (talent && talent != null) {

		
			return talent.talentLabel;
		
	}
}

function createTalent(id, talentLabel) {
	talentMap[id] = new Talent(id, talentLabel);
}

function createTalentMap() {
	var sampleNumberString = $.i18n.prop('talent.iRecognize.number');
		
	if (!isNaN(sampleNumberString)) {
		var sampleNumber = parseInt(sampleNumberString);
		console.log('sampleNumber = ' + sampleNumber);
		
			for (var i = 1; i < sampleNumber+1; i++) {	
				var title = $.i18n.prop('talent.iRecognize.'+i);	
				createTalent(i, title);
			}
	} else {
		console.log("talent.iRecognize.number is not a number");
	}
	
}