
/* JavaScript content from js/talents/iPlay.js in folder common */
// Add on click for each photo button
$('a[id^=talents_iplay_photo_button_]').each(function(index, value) {
	$(this).on("click", function() {
		setActivityStatus(talentsIPlayPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
			console.log("Activity is now in progress");
		});

		var position = parseInt($(this).attr("data-rel"));
		$('#talents_iplay_file_' + position).click();
	});
});

// on page show
$(document).on("pagebeforeshow", "#" + talentsIPlayPage.id, function(event) {
	talentIPlay_SetScreenState(true);
});

// File upload
$("#" + talentsIPlayPage.id + " input[type=file]").on('change', function(event) {
	var talentId = parseInt($(this).attr("data-talent-id"));
	console.log('file upload : talentId = ' + $(this).attr("data-talent-id"));
	var position = parseInt($(this).attr("data-rel"));

	var file = $(this).prop("files")[0];

	var fileName = file.name;

	if (file && hasImageExtension(fileName)) {

		// Only process image files.
		// if (file.type.match('image.*')) {
		encodeToBase64(file, function(base64Value) {
			addTalentImageIPlay(talentId, base64Value, function() {
				console.log('image added');
				var image = document.createElement("img");
				image.setAttribute("src", base64Value);

				$('#talents_iplay_image_' + position).empty();
				document.getElementById('talents_iplay_image_' + position).appendChild(image);

				talentIPlay_SetScreenState(false);
			});
		});
		/*
		 * } else { console.log('Not a image'); }
		 */
	} else {
		console.log('file removed or has not a image extension');
	}
});

function talentIPlay_SetScreenState(initState) {

	if (initState) {
		getActivityStatus(talentsIPlayPage.id, function(activityStatus) {
			if (activityStatus == SCREEN_STATUS_FINISHED) {
				// Hide validation button
				toggleVisibility('#talents_iplay_validation', false);

				// Hide buttons to add image
				$('a[id^=talents_iplay_photo_button_]').each(function(index, value) {
					$(this).hide();
				});
			}
		});

		getAllTalentISpot(function(talentISpotIds) {
			getAllTalentIPlay(function(talentIPlayIds, images) {
				console.log('images.length = ' + images.length);

				if (talentIPlayIds.length == 5) {
					toggleEnabling('#talents_iplay_validation', false);
				} else {
					toggleEnabling('#talents_iplay_validation', true);
				}

				for (var i = 0; i < talentISpotIds.length; i++) {
					var talentId = talentISpotIds[i];
					var talentLabel = getTalentLocalizedLabel(talentId);
					var stringIndice = (i + 1).toString();
					console.log('talentIPlay_SetScreenState : talentLabel = ' + talentLabel + ', talentId = ' + talentId);

					$('#talents_iplay_label_' + stringIndice).html(talentLabel);
					$("#talents_iplay_file_" + stringIndice).attr("data-talent-id", talentId);

					var position = $.inArray(talentId, talentIPlayIds);

					if (position != -1) {
						var image = document.createElement("img");
						image.setAttribute("src", images[position]);

						$('#talents_iplay_image_' + stringIndice).empty();
						$('#talents_iplay_image_' + stringIndice).append(image);
					}

				}
			});
		});
	} else {
		getAllTalentIPlay(function(talentIds, images) {
			if (images.length == 5) {
				toggleEnabling('#talents_iplay_validation', false);
			} else {
				toggleEnabling('#talents_iplay_validation', true);
			}
		});
	}

}

// Add click event on validation button
$("#talents_iplay_validation").on("click", function(e) {
	setActivityStatus(talentsIPlayPage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 85, function(){
			console.log('activity 6 finished');
			setActivityStatus(talentsIEnhancePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 7 is now accessible');
				$.mobile.changePage("#" + talentsIEnhancePage.id);
			});
		});
	});
});
