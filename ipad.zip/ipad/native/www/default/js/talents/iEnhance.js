
/* JavaScript content from js/talents/iEnhance.js in folder common */
$(document).on("pagebeforeshow", "#" + talentsIEnhancePage.id, function(event) {
	talentIEnhance_SetScreenState(true);
});

// add click event on each radio button for notation
$("#" + talentsIEnhancePage.id + " [type='radio'][id^=talents_ienhance_note_]").on("click", function(e) {
	var talentId = parseInt($(this).attr('data-talent-id'));
	var value = parseInt($(this).attr('value'));

	addTalentNoteIEnhance(talentId, value, function() {
		console.log('note added : ' + talentId + '=' + value);
		talentIEnhance_SetScreenState(false);
	});

	setActivity7InProgress();
});

// add click event on each radio button for selected talent
$("#" + talentsIEnhancePage.id + " [type='radio'][id^=talents_ienhance_bloc_talent_list_]").on("click", function(e) {
	var talentId = parseInt($(this).attr('data-talent-id'));

	setSelectedTalentIEnhance(talentId, function() {
		console.log('set selected talent with talentId = ' + talentId);
		talentIEnhance_SetScreenState(false);
	});
});

// Add event on validation button
$("#talents_ienhance_validation_1").on("click", function(e) {
	valideTalentsIEnhance(function() {
		talentIEnhance_SetScreenState(false);
	});
});

// Add event on validation button 2
$("#talents_ienhance_validation_2").on("click", function(e) {
	setActivityStatus(talentsIEnhancePage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 100, function(){
			console.log(talentsIEnhancePage.id + ' finished');
			setActivityStatus(compassMyValuesPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				$.mobile.changePage("#" + overviewPage.id);
			});
		});
	});
});

$("#talents_ienhance_bloc_textarea").on("keyup", function(e) {
	var response = $(this).val();

	setTalentIEnhanceResponse(response, function() {
		console.log('response added');
		talentIEnhance_SetScreenState(false);
	});
});

function setActivity7InProgress() {
	setActivityStatus(talentsIEnhancePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log("talentsIEnhancePage.id is now in progress");
	});
}

// On popup open clear stage name and date
$("#talents_ienhance_popup").on("popupbeforeposition", function(e, ui) {
	talentIEnhance_SetPopupState(true);
});

// Open datebox on text field click
$('#talents_ienhance_popup_date').on("click", function(e) {
	$('#talents_ienhance_popup_date').datebox('open');
});

// When a date is selected in the datebox
$('#talents_ienhance_popup_date').bind('datebox', function(e, p) {
	if (p.method === 'close') {
		talentIEnhance_SetPopupState(false);
	}
});

$("#talents_ienhance_popup_textarea").on("keyup", function(e) {
	talentIEnhance_SetPopupState(false);
});

// Add event on add stage button
$("#talents_ienhance_add_stage").on("click", function(e) {
	var stageDate = $('#talents_ienhance_popup_date').datebox('getTheDate');
	var stageName = $("#talents_ienhance_popup_textarea").val();
	setCalendarDate(talentsIEnhancePage.id +" "+stageName, stageDate, "date"+ talentsIEnhancePage.id +" stage", function(){

		addTalentIEnhanceStage(stageName, stageDate, function() {
			console.log('stage added');
			$('#talents_ienhance_popup').popup("close");
			talentIEnhance_SetScreenState(false);
		});
	});
});

// Set screen state
function talentIEnhance_SetScreenState(initState) {

	if (initState) {

		getAllTalentISpot(function(talentISpotIds) {

			// Display talent label for notation
			for (var i = 0; i < talentISpotIds.length; i++) {
				var talentId = talentISpotIds[i];
				var talentLabel = getTalentLocalizedLabel(talentId);
				var stringIndice = (i + 1).toString();

				$('#talents_ienhance_label_' + stringIndice).html(talentLabel + '&nbsp;:&nbsp;');

				$('[id^=talents_ienhance_note_' + stringIndice + ']').each(function(i) {
					$(this).attr('data-talent-id', talentId);
				});
			}

			// Display talent list for selected talent
			$('[id^=talents_ienhance_bloc_talent_list_]').each(function(i) {
				var value = parseInt($(this).attr('value'));
				var talentId = talentISpotIds[value - 1];

				$(this).attr('data-talent-id', talentId);
				$('label[for=talents_ienhance_bloc_talent_list_' + value.toString() + ']').html(getTalentLocalizedLabel(talentId));
			});
		});

		// Display selected talent
		getSelectedTalentIEnhance(function(selectedTalentId) {
			$('[name=talents_ienhance_bloc_talent_list][data-talent-id=' + selectedTalentId.toString() + ']').checkboxradio().prop("checked", true).checkboxradio("refresh");
		}, function() {
			console.log('Selected talent is not set');
		});

		// Set response text
		getTalentIEnhanceResponse(function(response) {
			console.log('response to put is ' + response);
			$("#talents_ienhance_bloc_textarea").html(response);
		}, function() {
			console.log("response has never been set");
		});
	}

	// Enable/disable first validation button
	isTalentsIEnhanceValidated(function() {
		toggleVisibility('#talents_ienhance_validation_1', false);
		toggleVisibility('#talents_ienhance_bloc', true);

		// disable all radio button for notation
		$("#" + talentsIEnhancePage.id + " [type='radio'][id^=talents_ienhance_note_]").each(function(i) {
			$(this).attr('disabled', true);
			$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
			$(this).checkboxradio("refresh");
		});
	}, function() {
		toggleVisibility('#talents_ienhance_validation_1', true);
		toggleVisibility('#talents_ienhance_bloc', false);
	});

	getAllTalentIEnhance(function(talentIds, notes) {

		if (initState) {

			// Activate radio button
			for (var i = 0; i < talentIds.length; i++) {
				var talentId = talentIds[i];
				var note = notes[i];
				$('[id^=talents_ienhance_note_][data-talent-id=' + talentId.toString() + '][value=' + note.toString() + ']').checkboxradio().prop("checked", true).checkboxradio("refresh");
			}
		}

		if (talentIds.length == 5) {
			toggleEnabling('#talents_ienhance_validation_1', false);
		} else {
			toggleEnabling('#talents_ienhance_validation_1', true);
		}
	});

	// Display stage
	talentIEnhance_RefreshStage();

	// Enable/disable second validation button
	getTalentIEnhanceResponse(function(response) {

		if (!isBlank(response)) {
			console.log('enableSecondValidationButton::response = ' + response);
			getAllTalentIEnhanceStages(function(names, dates) {

				if (names.length > 0 && dates.length > 0) {
					console.log('enableSecondValidationButton::names.length && dates.length = ' + names.length);

					getSelectedTalentIEnhance(function(selectedTalentId) {
						console.log('enableSecondValidationButton::All conditions are OK. Show validation button');
						toggleEnabling('#talents_ienhance_validation_2', false);
					}, function() {
						console.log('enableSecondValidationButton::Selected talent is not set. Don\'t show validation button');
						toggleEnabling('#talents_ienhance_validation_2', true);
					});
				} else {
					console.log('enableSecondValidationButton::names.length = 0 and/or dates.length = 0. Don\'t show validation button');
					toggleEnabling('#talents_ienhance_validation_2', true);
				}
			});
		} else {
			console.log('enableSecondValidationButton::response is set but is blank. Don\'t show validation button');
			toggleEnabling('#talents_ienhance_validation_2', true);
		}
	}, function() {
		console.log('enableSecondValidationButton::response is not set. Don\'t show validation button');
		toggleEnabling('#talents_ienhance_validation_2', true);
	});

	// if activity is finished, disable all checkbox
	getActivityStatus(talentsIEnhancePage.id, function(activityStatus) {
		if (activityStatus == SCREEN_STATUS_FINISHED) {

			// hide add stage button, remove stage buttons and validation button
			toggleVisibility('#talents_ienhance_open_popup_add_stage', false);
			toggleVisibility('#talents_ienhance_validation_2', false);
			$("#" + talentsIEnhancePage.id + " [id^=talents_ienhance_remove_stage_]").each(function(i) {
				$(this).hide();
			});

			// disable textarea
			toggleEnabling("#talents_ienhance_bloc_textarea", true);

			// disable first talent to enhance radio button
			$("#" + talentsIEnhancePage.id + " [type='radio'][id^=talents_ienhance_bloc_talent_list_]").each(function(i) {
				$(this).attr('disabled', true);
				$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
				$(this).checkboxradio("refresh");
			});
		}
	});
}

// Set popup state
function talentIEnhance_SetPopupState(initState) {
	console.log('talentIEnhance_SetPopupState entering');

	if (initState) {
		$('#talents_ienhance_popup_date').val('');
		$("#talents_ienhance_popup_textarea").val('');
		toggleEnabling('#talents_ienhance_add_stage', true);
	}

	if (!initState) {
		var dateString = $('#talents_ienhance_popup_date').val();
		var stageName = $("#talents_ienhance_popup_textarea").val();

		if (dateString != '' && !isBlank(stageName)) {
			toggleEnabling('#talents_ienhance_add_stage', false);
		} else {
			toggleEnabling('#talents_ienhance_add_stage', true);
		}
	}

}

function talentIEnhance_RefreshStage() {
	getAllTalentIEnhanceStages(function(ids, names, dates) {
		var htmlCode = '';

		for (var i = 0; i < names.length; i++) {
			var name = names[i].replace(/\n/g, '<br />');
			var date = dates[i];
			var id = ids[i];
			htmlCode += '<li>' + name + ' : ' + displayDate(date, isFrench);
			htmlCode += '<a class="ui-btn ui-btn-inline ui-icon-delete ui-btn-icon-notext ui-corner-all" id="talents_ienhance_remove_stage_' + id + '" onclick="talentIEnhance_deleteStage(' + id + ')"></a>';
			htmlCode += '</li>';
		}

		$('#talents_ienhance_stage_list').html(htmlCode);
	});
}

function talentIEnhance_deleteStage(stageId) {
	console.log('talentIEnhance_deleteStage entering');
	removeTalentIEnhanceStage(stageId, function() {
		console.log('stage removed');
		talentIEnhance_RefreshStage();
	});
}