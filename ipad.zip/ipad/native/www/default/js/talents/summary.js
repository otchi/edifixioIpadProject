
/* JavaScript content from js/talents/summary.js in folder common */
$("#talents_summary_stage_1").on("click", function(e) {
	getActivityStatus(talentsIRecognizePage.id, function(talentActivityStatus) {
		if (talentActivityStatus && !talentActivityStatus == '') {
			$.mobile.changePage('#' + talentsIRecognizePage.id);
		}
	});
});
$("#talents_summary_stage_2").on("click", function(e) {
	getActivityStatus(talentsChildhoodPage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsChildhoodPage.id);
		}
	});
});
$("#talents_summary_stage_3").on("click", function(e) {
	getActivityStatus(talentsManifestePage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsManifestePage.id);
		}
	});
});
$("#talents_summary_stage_4").on("click", function(e) {
	getActivityStatus(talentsOtherRecognizePage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsOtherRecognizePage.id);
		}
	});
});
$("#talents_summary_stage_5").on("click", function(e) {
	getActivityStatus(talentsISpotPage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsISpotPage.id);
		}
	});
});
$("#talents_summary_stage_6").on("click", function(e) {
	getActivityStatus(talentsIPlayPage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsIPlayPage.id);
		}
	});
});
$("#talents_summary_stage_7").on("click", function(e) {
	getActivityStatus(talentsIEnhancePage.id, function(talentActivityStatus) {
		if (talentActivityStatus && talentActivityStatus != '') {
			$.mobile.changePage('#' + talentsIEnhancePage.id);
		}
	});
});

$(document).on("pagebeforeshow", "#" + talentsSummaryPage.id, function(event) {

	getActivityStatus(talentsIRecognizePage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_1_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_1_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsChildhoodPage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_2_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_2_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsManifestePage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_3_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_3_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsOtherRecognizePage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_4_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_4_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsISpotPage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_5_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_5_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsIPlayPage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_6_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_6_status").html(talentActivityStatus);
		}
	});
	getActivityStatus(talentsIEnhancePage.id, function(talentActivityStatus) {
		if (!talentActivityStatus || talentActivityStatus == '') {
			$("#talent_7_status").html(SCREEN_STATUS_LOCKED);
		} else {
			$("#talent_7_status").html(talentActivityStatus);
		}
	});
	
});
