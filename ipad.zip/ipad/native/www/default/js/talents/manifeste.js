
/* JavaScript content from js/talents/manifeste.js in folder common */
// load list of talents into the popup
var aClass = 'a';
var bClass = 'b';
var cClass = 'c';
var dClass = 'd';
var currentClass = 'a';

for ( var key in talentMap) {
	var talentLabel = getTalentLocalizedLabel(key);
	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<input name="talents_manifeste_radio" id="talents_manifeste_radio_' + key + '" type="radio" data-mini="true" value="' + key + '"/>';
	htmlCode += '<label for="talents_manifeste_radio_' + key + '">' + talentLabel + '</label>';
	htmlCode += '</div>';

	$('#talents_manifeste_talent_list').append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}

var manifesteTalentType = null;
var manifesteTalentPosition = null;
var manifesteSpanToUpdate = null;

$("#" + talentsManifestePage.id + " [id^='talents_manifeste_add_talent_colleges_']").on("click", function(e) {
	manifesteTalentType = key_talents_manifeste_college;
	manifesteTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	manifesteSpanToUpdate = $("#" + talentsManifestePage.id + " #manifeste_selected_talent_colleges li[data-talent-number='" + manifesteTalentPosition + "'] span");
	setActivity3InProgress();
});

$("#" + talentsManifestePage.id + " [id^='talents_manifeste_add_talent_parents_']").on("click", function(e) {
	manifesteTalentType = key_talents_manifeste_parent;
	manifesteTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	manifesteSpanToUpdate = $("#" + talentsManifestePage.id + " #manifeste_selected_talent_parents li[data-talent-number='" + manifesteTalentPosition + "'] span");
	setActivity3InProgress();
});

$("#" + talentsManifestePage.id + " [id^='talents_manifeste_add_talent_children_']").on("click", function(e) {
	manifesteTalentType = key_talents_manifeste_child;
	manifesteTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	manifesteSpanToUpdate = $("#" + talentsManifestePage.id + " #manifeste_selected_talent_children li[data-talent-number='" + manifesteTalentPosition + "'] span");
	setActivity3InProgress();
});

$("#" + talentsManifestePage.id + " [id^='talents_manifeste_add_talent_friends_']").on("click", function(e) {
	manifesteTalentType = key_talents_manifeste_friend;
	manifesteTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	manifesteSpanToUpdate = $("#" + talentsManifestePage.id + " #manifeste_selected_talent_friends li[data-talent-number='" + manifesteTalentPosition + "'] span");
	setActivity3InProgress();
});

$("#" + talentsManifestePage.id + " [id^='talents_manifeste_add_talent_partner_']").on("click", function(e) {
	manifesteTalentType = key_talents_manifeste_partner;
	manifesteTalentPosition = parseInt($(this).parent().attr('data-talent-number'));
	manifesteSpanToUpdate = $("#" + talentsManifestePage.id + " #manifeste_selected_talent_partner li[data-talent-number='" + manifesteTalentPosition + "'] span");
	setActivity3InProgress();
});

function setActivity3InProgress() {
	setActivityStatus(talentsManifestePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log("Activity 3 is now in progress");
	});
}

// Add event on each radio button in popup click
$("#" + talentsManifestePage.id + " #talents_manifeste_talent_list [type='radio']").on("click", function(e) {
	var talentId = parseInt($(this).attr("value"));

	addTalentManifeste(manifesteTalentType, manifesteTalentPosition, talentId, function() {
		console.log('talent added in base');
		manifesteSpanToUpdate.html(getTalentLocalizedLabel(talentId));

		getTalentsManifesteCount(function(number) {
			if (number == 11) {
				toggleEnabling("#talents_manifeste_talents_validation_1", false);
			} else {
				toggleEnabling("#talents_manifeste_talents_validation_1", true);
			}
			
			//close the popup
			$('#talents_manifeste_talent_popup').popup("close");
		});
	});
});

$(document).on("pagebeforeshow", "#" + talentsManifestePage.id, function(event) {

	getAllTalentsManifeste(function(talentsMap) {
		for ( var keyTalentType in talentsMap) {
			var talentsMap2 = talentsMap[keyTalentType];

			for ( var keyTalentPosition in talentsMap2) {
				var talentId = talentsMap2[keyTalentPosition];
				var talentLabel = getTalentLocalizedLabel(talentId);

				if (keyTalentType == key_talents_manifeste_child) {
					$("#" + talentsManifestePage.id + " #manifeste_selected_talent_children li[data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
				} else if (keyTalentType == key_talents_manifeste_college) {
					$("#" + talentsManifestePage.id + " #manifeste_selected_talent_colleges li[data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
				} else if (keyTalentType == key_talents_manifeste_friend) {
					$("#" + talentsManifestePage.id + " #manifeste_selected_talent_friends li[data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
				} else if (keyTalentType == key_talents_manifeste_parent) {
					$("#" + talentsManifestePage.id + " #manifeste_selected_talent_parents li[data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
				} else if (keyTalentType == key_talents_manifeste_partner) {
					$("#" + talentsManifestePage.id + " #manifeste_selected_talent_partner li[data-talent-number='" + keyTalentPosition + "'] span").html(talentLabel);
				} else {
					console.log('Don\'t know what to do with this talent type');
				}
			}
		}
	});

	isTalentsManifesteValidated(function() {
		// hide all add talent button
		$('a[id^="talents_manifeste_add_talent_"]').hide();

		// hide validation button 1
		toggleVisibility('#talents_manifeste_talents_validation_1', false);

		// show bloc
		toggleVisibility("#talents_manifeste_bloc", true);

		// show add talent results button
		$('a[id="talents_manifeste_add_talent_result"]').show();
	}, function() {
		toggleVisibility("#talents_manifeste_bloc", false);

		getTalentsManifesteCount(function(number) {
			if (number == 11) {
				toggleEnabling("#talents_manifeste_talents_validation_1", false);
			} else {
				toggleEnabling("#talents_manifeste_talents_validation_1", true);
			}
		});
	});

	getAllTalentManifesteResults(function(talentIds) {
		// clear content
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_1").html('');
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_2").html('');
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_3").html('');

		// Set selected talents
		for (var i = 0; i < talentIds.length; i++) {
			$("#" + talentsManifestePage.id + " #talents_manifeste_talent_" + (i + 1)).html(getTalentLocalizedLabel(talentIds[i]));
		}

		if (talentIds.length == 3) {
			toggleEnabling("#talents_manifeste_talents_validation_2", false);
		} else {
			toggleEnabling("#talents_manifeste_talents_validation_2", true);
		}
	});

	// If the activity is finished, hide action buttons;
	getActivityStatus(talentsManifestePage.id, function(activityStatus) {
		console.log("status = " + activityStatus);
		if (activityStatus == SCREEN_STATUS_FINISHED) {
			$('[id^="talents_manifeste_add_talent_"]').hide();
			$('#talents_manifeste_talents_validation_1').hide();
			$('#talents_manifeste_talents_validation_2').hide();
		}
	});
});

// On popup open
$("#talents_manifeste_talent_popup").on("popupbeforeposition", function(e, ui) {
	console.log('manifesteTalentType = ' + manifesteTalentType);
	getTalentsManifeste(manifesteTalentType, function(talentMap) {

		// unckeck all radio button and enable it
		$("#talents_manifeste_talent_popup [type=radio]").each(function(i) {
			$(this).removeAttr("checked").prop("checked", false).checkboxradio("enable").checkboxradio("refresh");
		});

		for ( var talentPosition in talentMap) {
			if (talentPosition == manifesteTalentPosition) {
				$("#talents_manifeste_talent_popup [type='radio'][value='" + talentMap[talentPosition] + "']").prop("checked", true).checkboxradio("refresh");
			} else {
				// disable value for this talent type
				$("#talents_manifeste_talent_popup [type='radio'][value='" + talentMap[talentPosition] + "']").checkboxradio("disable").checkboxradio("refresh");
			}
		}
	});
});

// Add click event on validation button 1
$("#talents_manifeste_talents_validation_1").on("click", function(e) {
	valideTalentsManifeste(function() {
		// hide all add talent button
		$('a[id^="talents_manifeste_add_talent_"]').hide();

		// hide validation button 1
		toggleVisibility('#talents_manifeste_talents_validation_1', false);

		// show bloc
		toggleVisibility('#talents_manifeste_bloc', true);

		// show add talent results button
		$('a[id="talents_manifeste_add_talent_result"]').show();

		// disable validation button 2
		toggleEnabling("#talents_manifeste_talents_validation_2", true);
	});
});

// On result popup open
$("#talents_manifeste_talent_result_popup").on("popupbeforeposition", function(e, ui) {
	console.log('open');
	// Retrieve all talents selected in the tree
	currentClass = 'a';

	getAllTalentsManifeste(function(talentMap) {
		var talentSet = new Array();

		// Build a set of selected talent ids
		for (talentTypeKey in talentMap) {
			var talentMap2 = talentMap[talentTypeKey];

			for (talentPositionKey in talentMap2) {
				var talentId = talentMap2[talentPositionKey];

				if ($.inArray(talentId, talentSet) == -1) {
					talentSet.push(talentId);
				}
			}

		}
		// Clear listcontent
		$('#talents_manifeste_talent_result_list').html('');

		// Set popup content
		for (var i = 0; i < talentSet.length; i++) {
			var talentId = talentSet[i];
			var talentLabel = getTalentLocalizedLabel(talentId);

			var htmlCode = '<div class="ui-block-' + currentClass + '">';
			htmlCode += '<label for="talents_manifeste_checkbox_' + talentId + '">' + talentLabel + '</label>';
			htmlCode += '<input name="talents_manifeste_checkbox_' + talentId + '" id="talents_manifeste_checkbox_' + talentId + '" type="checkbox" data-mini="true" value="' + talentId + '"/>';
			htmlCode += '</div>';

			$('#talents_manifeste_talent_result_list').append(htmlCode);

			if (currentClass == aClass) {
				currentClass = bClass;
			} else if (currentClass == bClass) {
				currentClass = cClass;
			} else if (currentClass == cClass) {
				currentClass = dClass;
			} else if (currentClass == dClass) {
				currentClass = aClass;
			}
		}

		// add click event on each checkbox
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_result_popup [type='checkbox']").each(function(i) {
			$(this).checkboxradio().checkboxradio("refresh");

			$(this).on("click", function() {
				var isSelected = $(this).is(':checked');
				var talentId = parseInt($(this).attr("value"));

				if (isSelected) {
					addTalentManifestResult(talentId, function() {
						console.log('talent added');
					});
				} else if (!isSelected) {
					removeTalentManifestResult(talentId, function() {
						console.log('talent removed');
					});
				}

				getAllTalentManifesteResults(function(talentIds) {
					if (talentIds.length == 3) {
						talentManifest_LockCheckboxes();
					} else {
						talentManifest_unlockCheckboxes();
					}
				});
			});
		});

		// check checkboxes
		getAllTalentManifesteResults(function(talentIds) {
			for (var i = 0; i < talentIds.length; i++) {
				$("#" + talentsManifestePage.id + " #talents_manifeste_talent_result_popup [type='checkbox'][value='" + talentIds[i] + "']").prop("checked", true).checkboxradio("refresh");
			}

			if (talentIds.length == 3) {
				talentManifest_LockCheckboxes();
			} else {
				talentManifest_unlockCheckboxes();
			}
		});
	});
});

function talentManifest_LockCheckboxes() {
	console.log('talentManifest_LockCheckboxes entering');

	// Disabling all checkboxes
	$("#" + talentsManifestePage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', true);
		$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});

	// Enabling checked checkboxes
	$("#" + talentsManifestePage.id + " [type='checkbox']:checked").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

function talentManifest_unlockCheckboxes() {
	console.log('talentManifest_unlockCheckboxes entering');

	$("#" + talentsManifestePage.id + " [type='checkbox']").each(function(index, value) {
		$(this).attr('disabled', false);
		$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
		$(this).checkboxradio("refresh");
	});
}

// On result popup close
$("#talents_manifeste_talent_result_popup").on("popupafterclose", function(e, ui) {
	getAllTalentManifesteResults(function(talentIds) {
		// clear content
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_1").html('');
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_2").html('');
		$("#" + talentsManifestePage.id + " #talents_manifeste_talent_3").html('');

		// Set selected talents
		for (var i = 0; i < talentIds.length; i++) {
			$("#" + talentsManifestePage.id + " #talents_manifeste_talent_" + (i + 1)).html(getTalentLocalizedLabel(talentIds[i]));
		}

		if (talentIds.length == 3) {
			toggleEnabling("#talents_manifeste_talents_validation_2", false);
		} else {
			toggleEnabling("#talents_manifeste_talents_validation_2", true);
		}
	});
});

// Add click event on validation button 2
$("#talents_manifeste_talents_validation_2").on("click", function(e) {
	setActivityStatus(talentsManifestePage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 42, function(){
			console.log('activity 3 finished');
			setActivityStatus(talentsOtherRecognizePage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 4 is now accessible');
				$.mobile.changePage("#" + talentsOtherRecognizePage.id);
			});
		});
	});
});
