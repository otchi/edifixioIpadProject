
/* JavaScript content from js/talents/iRecognize.js in folder common */
// Load talents list
$fieldSet = $("#" + talentsIRecognizePage.id + " fieldset");

var aClass = 'a';
var bClass = 'b';
var cClass = 'c';
var dClass = 'd';
var currentClass = 'a';
createTalentMap();
for ( var key in talentMap) {
	var talentLabel = getTalentLocalizedLabel(key);

	var htmlCode = '<div class="ui-block-' + currentClass + '">';
	htmlCode += '<label for="talents_irecognize_checkbox_' + key + '">' + talentLabel + '</label>';
	htmlCode += '<input name="talents_irecognize_checkbox_' + key + '" id="talents_irecognize_checkbox_' + key + '" type="checkbox" data-mini="true" value="' + key + '"/>';
	htmlCode += '</div>';
	$fieldSet.append(htmlCode);

	if (currentClass == aClass) {
		currentClass = bClass;
	} else if (currentClass == bClass) {
		currentClass = cClass;
	} else if (currentClass == cClass) {
		currentClass = dClass;
	} else if (currentClass == dClass) {
		currentClass = aClass;
	}
}

// Add click event on each checkbox
$("#" + talentsIRecognizePage.id + " [type='checkbox']").on("click", function(e) {
	var talentId = parseInt($(this).attr("value"));
	var isSelected = $(this).is(':checked');

	if (isSelected) {
		addTalentIRecognize(talentId, function() {
			setActivityStatus(talentsIRecognizePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				console.log('talent added');
			});
		});
	} else if (!isSelected) {
		removeTalentIRecognize(talentId, function() {
			setActivityStatus(talentsIRecognizePage.id, SCREEN_STATUS_IN_PROGRESS, function() {
				console.log('talent removed');
			});
		});
	}

	var selectedTalentNumber = $("#" + talentsIRecognizePage.id + " [type='checkbox']:checked").length;
	toggleEnabling('#talents_irecognize_validation', selectedTalentNumber != 3);
});

// On page show check or uncheck checkboxes
$(document).on("pagebeforeshow", "#" + talentsIRecognizePage.id, function(event) {
	getAllTalentIRecognize(function(talentIds) {

		toggleEnabling('#talents_irecognize_validation', talentIds.length != 3);

		$("#" + talentsIRecognizePage.id + " [type='checkbox']").each(function(i) {
			var value = parseInt($(this).attr("value"));

			if ($.inArray(value, talentIds) != -1) {
				$(this).attr('checked', true);
			} else {
				$(this).attr('checked', false);
			}

			$(this).checkboxradio("refresh");
		});
	});

	// If the activity is locked, disabled all checkbox;
	getActivityStatus(talentsIRecognizePage.id, function(activityStatus) {
		console.log("status = " + activityStatus);
		if (activityStatus == SCREEN_STATUS_FINISHED) {

			$("#" + talentsIRecognizePage.id + " [type='checkbox']").each(function(i) {
				$(this).attr('disabled', true);
				$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
				$(this).checkboxradio("refresh");
			});

			$('#talents_irecognize_validation').hide();
		}
	});
});

// Add click event on button
$("#talents_irecognize_validation").on("click", function(e) {
	setActivityStatus(talentsIRecognizePage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 14, function(){
			console.log('activity 1 finished');
			setActivityStatus(talentsChildhoodPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 2 is now accessible');
				$.mobile.changePage("#" + talentsChildhoodPage.id);
			});
		});
	});
});