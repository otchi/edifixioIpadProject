
/* JavaScript content from js/talents/iSpot.js in folder common */
// on page show, hide checkboxes
$(document).on("pagebeforeshow", "#" + talentsISpotPage.id, function(event) {
	displayCheckBoxs(talentISpot_SetScreenState);
});

function getAllTalentsFromPreviousScreen(callback) {
	var talentSet = new Array();

	getAllTalentIRecognize(function(iRecognizeTalentIds) {
		// copy all talent ids from i recognize screen to talent set
		for (var i = 0; i < iRecognizeTalentIds.length; i++) {
			var iRecognizeTalentId = iRecognizeTalentIds[i];
			console.log('i spot : iSelected : added talentid : ' + iRecognizeTalentId);
			console.log('i spot : iSelected : added talentid type : ' + typeof iRecognizeTalentId);
			talentSet.push(iRecognizeTalentId);
		}

		// copy all talent ids from talent childhood screen to talent set
		getAllTalentChildhood(function(childhoodTalentIds) {
			for (var i = 0; i < childhoodTalentIds.length; i++) {
				var childhoodTalentId = childhoodTalentIds[i];

				if ($.inArray(childhoodTalentId, talentSet) == -1) {
					console.log('i spot : childhood : added talentid : ' + childhoodTalentId);
					talentSet.push(childhoodTalentId);
				}
			}

			getAllTalentManifesteResults(function(manifesteTalentIds) {
				for (var i = 0; i < manifesteTalentIds.length; i++) {
					var manifesteTalentId = manifesteTalentIds[i];
					console.log('I spot : manifesteTalentId = ' + manifesteTalentId);

					if ($.inArray(manifesteTalentId, talentSet) == -1) {
						console.log('i spot : manifeste : added talentid : ' + manifesteTalentId);
						talentSet.push(manifesteTalentId);
					}
				}

				getAllTalentOtherRecognizeResults(function(otherRecognizeTalentIds) {
					for (var i = 0; i < otherRecognizeTalentIds.length; i++) {
						var otherRecognizeTalentId = otherRecognizeTalentIds[i];
						console.log('I spot : otherRecognizeTalentId = ' + otherRecognizeTalentId);

						if ($.inArray(otherRecognizeTalentId, talentSet) == -1) {
							console.log('i spot : other recognize : added talentid : ' + otherRecognizeTalentId);
							talentSet.push(otherRecognizeTalentId);
						}
					}

					callback(talentSet);
				});
			});
		});
	});
}

function displayCheckBoxs(callback) {
	getAllTalentsFromPreviousScreen(function(talentSet) {

		var aClass = 'a';
		var bClass = 'b';
		var cClass = 'c';
		var dClass = 'd';

		var currentClass1 = 'a';
		var currentClass2 = 'a';

		// clear checkboxs list
		$('#talents_ispot_talent_list').html('');
		$('#talents_ispot_popup_talent_list').html('');

		var displaybloc = false;

		if (talentSet.length < 5) {
			displaybloc = true;
		}

		for ( var talentId in talentMap) {
			var talentLabel = getTalentLocalizedLabel(talentId);

			// add the checkbox in the principal list
			if ($.inArray(parseInt(talentId), talentSet) != -1) {
				var htmlCode = '<div class="ui-block-' + currentClass1 + '">';
				htmlCode += '<label for="talents_ispot_checkbox_' + talentId + '">' + talentLabel + '</label>';
				htmlCode += '<input name="talents_ispot_checkbox_' + talentId + '" id="talents_ispot_checkbox_' + talentId + '" type="checkbox" data-mini="true" value="' + talentId + '"/>';
				htmlCode += '</div>';

				if (currentClass1 == aClass) {
					currentClass1 = bClass;
				} else if (currentClass1 == bClass) {
					currentClass1 = aClass;
				}

				$('#talents_ispot_talent_list').append(htmlCode);
			}

			// add the checkbox in the popup list
			else if (displaybloc) {
				var htmlCode = '<div class="ui-block-' + currentClass2 + '">';
				htmlCode += '<label for="talents_ispot_checkbox_' + talentId + '">' + talentLabel + '</label>';
				htmlCode += '<input name="talents_ispot_checkbox_' + talentId + '" id="talents_ispot_checkbox_' + talentId + '" type="checkbox" data-mini="true" value="' + talentId + '"/>';
				htmlCode += '</div>';

				if (currentClass2 == aClass) {
					currentClass2 = bClass;
				} else if (currentClass2 == bClass) {
					currentClass2 = cClass;
				} else if (currentClass2 == cClass) {
					currentClass2 = dClass;
				} else if (currentClass2 == dClass) {
					currentClass2 = aClass;
				}

				$('#talents_ispot_popup_talent_list').append(htmlCode);
			}
		}

		// add click event on each checkbox
		$("#" + talentsISpotPage.id + " [type='checkbox']").each(function(i) {
			$(this).checkboxradio().checkboxradio("refresh");

			$(this).on("click", function() {
				setActivity5InProgress();

				var isSelected = $(this).is(':checked');
				var talentId = parseInt($(this).attr("value"));

				if (isSelected) {
					addTalentISpot(talentId, function() {
						callback(false, talentSet);
						console.log('talent added');
					});
				} else if (!isSelected) {
					removeTalentISpot(talentId, function() {
						callback(false, talentSet);
						console.log('talent removed');
					});
				}
			});
		});

		if (!displaybloc) {
			toggleVisibility('#talents_ispot_bloc', false);
		}

		callback(true, talentSet);
	});
}

function talentISpot_LockCheckboxes(talentSet, lockPrincipalCheckboxes, lockPopupCheckboxes) {
	console.log('talentISpot_LockCheckboxes entering');

	// Disabling unselected checkboxes
	$("#" + talentsISpotPage.id + " [type='checkbox']").each(function(index, value) {
		var isSelected = $(this).is(':checked');
		var talentId = parseInt($(this).attr("value"));

		if (!isSelected) {
			var mustBeLocked = false;

			// Lock all
			if (lockPrincipalCheckboxes && lockPopupCheckboxes) {
				mustBeLocked = true;
			} else {

				// Principal checkboxes
				if ($.inArray(talentId, talentSet) != -1) {

					if (lockPrincipalCheckboxes) {
						mustBeLocked = true;
					}
				}
				// Popup checkboxes
				else {

					if (lockPopupCheckboxes) {
						mustBeLocked = true;
					}
				}
			}

			if (mustBeLocked) {
				$(this).attr('disabled', true);
				$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
				$(this).checkboxradio("refresh");
			}
		}
	});
}

function talentISpot_unlockCheckboxes(talentSet, unlockPrincipalCheckboxes, unlockPopupCheckboxes) {
	console.log('talentISpot_unlockCheckboxes entering with ' + talentSet + ',' + unlockPrincipalCheckboxes + ',' + unlockPopupCheckboxes);

	$("#" + talentsISpotPage.id + " [type='checkbox']").each(function(index, value) {
		var talentId = parseInt($(this).attr("value"));
		console.log('talentISpot_unlockCheckboxes talent id = ' + talentId);
		var mustBeUnLocked = false;

		// unlock all
		if (unlockPrincipalCheckboxes && unlockPopupCheckboxes) {
			mustBeUnLocked = true;
		} else {

			// Principal checkboxes
			if ($.inArray(talentId, talentSet) != -1) {
				console.log('talentISpot_unlockCheckboxes talent id is in talentSet');
				if (unlockPrincipalCheckboxes) {
					mustBeUnLocked = true;
				}
			}
			// Popup checkboxes
			else {
				console.log('talentISpot_unlockCheckboxes talent id is NOT in talentSet');
				if (unlockPopupCheckboxes) {
					console.log('set to true');
					mustBeUnLocked = true;
				} else {
					console.log('set to nothing');
				}
			}
		}

		console.log('checkbox for talent id ' + talentId + ' must be unlocked ? ' + mustBeUnLocked);

		if (mustBeUnLocked) {
			$(this).attr('disabled', false);
			$(this).parent().removeClass(CSS_DISABLE_CLASSNAME);
			$(this).checkboxradio("refresh");
		}
	});
}

function talentISpot_SetScreenState(initState, talentSet) {

	if (initState) {

		// check checkboxs (from database)
		getAllTalentISpot(function(talentIds) {

			// check checkboxs (from database)
			for (var i = 0; i < talentIds.length; i++) {
				var talentId = talentIds[i];
				$("#" + talentsISpotPage.id + " #talents_ispot_checkbox_" + talentId).attr('checked', true);
				$("#" + talentsISpotPage.id + " #talents_ispot_checkbox_" + talentId).checkboxradio("refresh");
			}

			// if activity is finished, disable all checkbox
			getActivityStatus(talentsISpotPage.id, function(activityStatus) {
				if (activityStatus == SCREEN_STATUS_FINISHED) {
					$("#" + talentsISpotPage.id + " [type='checkbox']").each(function(i) {
						$(this).attr('disabled', true);
						$(this).parent().addClass(CSS_DISABLE_CLASSNAME);
						$(this).checkboxradio("refresh");

						// hide validation button & add talent button
						toggleVisibility('#talents_ispot_validation', false);
						toggleVisibility('#talents_ispot_add_talent', false);
					});
				}
			});
		});
	}

	getAllTalentISpot(function(talentIds) {
		var htmlCode = '';

		for ( var index in talentIds) {
			var talentIdDB = talentIds[index];

			if ($.inArray(parseInt(talentIdDB), talentSet) == -1) {
				htmlCode += '<li>' + getTalentLocalizedLabel(talentIdDB) + '</li>';
				selectedTalentNumberInPopup += 1;
			}
		}

		$('#talents_ispot_selected_popup_talent_list').html(htmlCode);

		if (talentIds.length == 5) {
			// Lock all unselected checkboxes
			talentISpot_LockCheckboxes(talentSet, true, true);
			toggleEnabling('#talents_ispot_validation', false);
		} else {
			toggleEnabling('#talents_ispot_validation', true);

			// unlock only principal checkboxes
			talentISpot_unlockCheckboxes(talentSet, true, false);

			console.log('click on checkbox in the popup');
			var selectedTalentNumberInPopup = 0;

			for ( var index in talentIds) {
				var talentIdDB = talentIds[index];

				if ($.inArray(parseInt(talentIdDB), talentSet) == -1) {
					selectedTalentNumberInPopup += 1;
				}
			}

			var selectableTalentNumberInPopup = 5 - talentSet.length;

			console.log('selectedTalentNumberInPopup = ' + selectedTalentNumberInPopup);
			console.log('selectableTalentNumberInPopup = ' + selectableTalentNumberInPopup);

			if (selectedTalentNumberInPopup == selectableTalentNumberInPopup) {
				// Lock popup checkboxes
				talentISpot_LockCheckboxes(talentSet, false, true);
			} else {
				// unLock popup checkboxes
				talentISpot_unlockCheckboxes(talentSet, false, true);
			}
		}
	});
}

function setActivity5InProgress() {
	setActivityStatus(talentsISpotPage.id, SCREEN_STATUS_IN_PROGRESS, function() {
		console.log("Activity 5 is now in progress");
	});
}

// Add click event on validation button
$("#talents_ispot_validation").on("click", function(e) {
	setActivityStatus(talentsISpotPage.id, SCREEN_STATUS_FINISHED, function() {
		set_Status_Progression("talent", 71, function(){
			console.log('activity 5 finished');
			setActivityStatus(talentsIPlayPage.id, SCREEN_STATUS_ACCESSIBLE, function() {
				console.log('activity 6 is now accessible');
				$.mobile.changePage("#" + talentsIPlayPage.id);
			});
		});
	});
});